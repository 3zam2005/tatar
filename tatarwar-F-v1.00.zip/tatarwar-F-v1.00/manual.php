<?php
#############################################################
##                             Tatar WaR V2.0              ##
## ------------------------------------------------------- ##
##  Project   :       TATAR WAR                            ##
##  Version   :       Beta                                 ##
##  Copyright :       AbDullH - 2012 - All rights reserved ##
##  email     :       o99g@hotmail.com                     ##
#############################################################

require( ".".DIRECTORY_SEPARATOR."o99g".DIRECTORY_SEPARATOR."boot.php" ); 
class GPage extends defaultpage
{

    public function GPage( )
    {
        parent::defaultpage( );
        $this->viewFile = "manual.phtml";
          $this->layoutViewFile = "layout".DIRECTORY_SEPARATOR."form.phtml";

    }

}


$p = new GPage( );
$p->run( );
?>