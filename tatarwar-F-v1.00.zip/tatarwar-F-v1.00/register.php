﻿<?php
include('F-v1.00/F-Core/con_ndc/s1.php');  // مسار خاص بملف الكونفق لسيرفرك
$db_connect = mysql_connect($AppConfig['db']['host'],$AppConfig['db']['user'],$AppConfig['db']['password']);
mysql_select_db($AppConfig['db']['database'], $db_connect);
$query = mysql_query("SELECT * FROM g_summary");
$data  = mysql_fetch_array($query);
$player = $data['players_count'];
$active = $data['active_players_count'];
?>
<html><h3 class="pop popgreen bold">مرحبا بك في حرب التتار !</h3>
<h3>يرجى إختيار سيرفر .</h3>
<br />
			<div class="greenbox serverListBox">
				<div class="greenbox-top"></div>
				<div class="greenbox-content">
		<div class="serverList">
	<div class="subContent" id="otherServers">
	<div class="serverList currentServer">
				<div class="clear"></div>
	</div>

	<div class="serverList currentServer">
					<div class="server serverEven serverSmall serverNormal serverSmallNormal ">
	<div class="name">السيرفر الأول</div>
		<div class="player">
		<img class="playerIcon" src="playerIcon.gif" />
				<span class="playerLabel">عدد اللاعبين : </span><?php echo $player; ?></div>
			<div class="start ">
		<img class="durationIcon" src="durationIcon-rtl.gif"></div>
					<a class="link" title="سجل الأن" href="F-v1.00/register.php" target="register"></a>
	</div>
	</div>
								<div class="clear"></div>
			</div>
		</div>
	</div>
				<div class="greenbox-bottom"></div>

	</div>
				<div class="clear"></div>
				</html>