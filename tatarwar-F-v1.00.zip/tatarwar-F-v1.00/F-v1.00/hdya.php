<?php

require( ".".DIRECTORY_SEPARATOR."F-Core".DIRECTORY_SEPARATOR."boot.php" );
require_once( MODEL_PATH."admin.php" );
class GPage extends SecureGamePage
{

    public $packageIndex = -1;
    public $plusTable = NULL;

    public function GPage( )
    {
        parent::securegamepage( );
        $this->viewFile = "hdya.phtml";
        $this->contentCssClass = "plus";

    }

    public function load( )
    {
        parent::load( );

    }



}

$p = new GPage( );
$p->run( );
?>

