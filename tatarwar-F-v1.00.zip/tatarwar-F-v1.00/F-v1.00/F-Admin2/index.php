<?php
ob_start();
session_start();


 if($_POST['submit'])
 {
 include_once('core/config.php');

 if($_POST['user'] !="" || $_POST['password'] !="")
 {
   $user = trim(mysql_real_escape_string($_POST['user']));
   $password = md5($_POST['password']);
   $sql = mysql_query('select `name`,`pwd`  from `p_players` where `id` = 1');
   $rowcount = mysql_num_rows($sql) ;
   if($rowcount ==1)
   {
   $row = mysql_fetch_array($sql) ;

        if($user== $row['name'] && $password == $row['pwd'])
        {
          $_SESSION['login'] = true ;
          header('location: main.php');
        }
        else
        {
          $_SESSION['login'] = false ;
          echo "<div id='error'>خطأ بأسم المستخدم أو كلمة المرور !!</div>";
        }
   }

 }
 else
 {
    echo"<div id='error'>جميع البينات مطلوبة</div>" ;
 }


 }
if($_SESSION['login'] === true)
{
      header('location: main.php');
}else{
?>
<!DOCTYPE HTML>

<html>

<head>
   <title>لوحه تحكم حرب التتار</title>

 <meta charset="utf-8" />
 <style>
 body{

   background: #DDDDDD;
   direction: rtl;
 }
 #login{
   background: #FFFFFF;
   width:300px;
   font-weight: bolder;
   color: #DDDDDD;
   border-radius:20px;
   padding: 30px;
   text-shadow: 0px 3px 2px #EEEEEE;
   box-shadow: 0px 10px 10px #AAAAAA;
   margin: 50px auto;
 }
 #login input{
   outline: none;
 }

 h3{
   color: #AAAAAA;
   text-align: right;
 }
 #error{
    background: #FFFFFF;
   width:300px;
   font-weight: bolder;
   color: #990000;
   border-radius:20px;
   padding: 30px;
   text-shadow: 0px 3px 2px #EEEEEE;
   box-shadow: 0px 10px 10px #AAAAAA;
   margin: 20px auto;
 }
 #submit{
   padding: 5px 10px;
   background: #990000;
   color: #FFF;
   border: none;
   border-radius: 5px;
   cursor:pointer;
 }
 #submit:hover{
   background: #000099;
 }

 </style>
</head>

<body>
<div id="holder">
<div id="login">
<h3>أدخل اسم الادمن وكلمة السر المسجل بها في اللعبة</h3>
<form action="" method="post">
<div style="text-align: center; background: #fff; border-radius: 5px;  ">
<p><input type="text" name="user" value="" placeholder="الاسم" /></p>
<p><input type="password" name="password" value="" placeholder="كلمه المرور" /> </p>
<p><input id="submit" type="submit" name="submit" value="دخول" /> </p>
</div>
</form>
</div>
</div>
</body>

</html>
<?
  }
?>

