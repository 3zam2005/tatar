<?php
  include_once('core/config.php');
  $id=(int)trim($_POST['id']);
$name=trim($_POST['name']);
$email=trim($_POST['email']);
if(!empty($id)){
  $sql = mysql_query("SELECT * FROM  `p_players` where `id`='$id'")or die(mysql_error()) ;
}elseif(!empty($name)){
  $sql = mysql_query("SELECT * FROM  `p_players` where `name`like '%$name%'")or die(mysql_error()) ;
}elseif(!empty($email)){
  $sql = mysql_query("SELECT * FROM  `p_players` where `email`='$email'")or die(mysql_error()) ;
}else{
  die("<div id='error'>من فضلك ادخل بيانا صحيحا</div>");
}
$num = mysql_num_rows($sql);
if($num > 0){
?>
<table id="show_smpil">
<tr>
<td>الرقم</td>
<td>اسم الاعب</td>
<td>البريد الاليكتروني</td>
<td>التفعيل</td>
<td>الذهب</td>
<td>حساب بلس</td>
<td>الحالة</td>
<td>خيارات</td>
</tr>


<?

while($row = mysql_fetch_assoc($sql)){
  $id = $row['id'];
$trible_id =  $row['tribe_id'];
switch($trible_id){
  case 1:
    $trible_name = "رومان";
  break;
  case 2:
    $trible_name = "جرمان";
  break;
  case 3:
    $trible_name = "أغريق";
  break;
  case 4:
    $trible_name = "وحوش";
  break;
  case 5:
    $trible_name = "تتار";
  break;
  case 6:
    $trible_name = "دبور";
  break;
  case 7:
    $trible_name = "العرب";
  break;
}

$name = $row['name'];
$email = $row['email'];
$is_active = $row['is_active'];
if($is_active == 0){
  $active = "غير مفعل";
}elseif($is_active == 1){
  $active = "مفعل";
}
$is_blocked = $row['is_blocked'];
if($is_blocked == 0){
  $blocked = "غير مطرود";
}elseif($is_blocked == 1){
  $blocked = "مطرود";
}
$player_type = $row['player_type'];
$active_plus_account = $row['active_plus_account'];
if($active_plus_account == 0){
  $plus = "غير مشترك";
}elseif($active_plus_account == 1){
  $plus = "مشترك";
}
$last_login_date = $row['last_login_date'];
$last_ip = $row['last_ip'];
$gold_num = $row['gold_num'];
$total_people_count = $row['total_people_count'];

///////////////////////////////عرض البيانات الاساسية////////////////////////////////////
?>
<tr>
<td><?= $id ?></td>
<td><?= $name ?></td>
<td><?= $email ?></td>
<td><?= $active ?></td>
<td><?= $gold_num ?></td>
<td><?= $plus ?></td>
<td><?= $blocked ?></td>
<td><a  id="edit"  onclick="edit_id(<?= $id ?>)" style="cursor:pointer;" >نعديل</a></td>

</tr>

<?
}
}else{
  ?>
  <div id="error">لا توجد نتائج</div>
  <?
}

?>
</table>
<script language="JavaScript" type="text/javascript">
function edit_id(id){
  $('#result').html('<img src="css/images/loading.gif" />جاري التحميل');
  $.post('edit.php',{id:id},function(data){
    $('#result').html(data);
  });

}

</script>
