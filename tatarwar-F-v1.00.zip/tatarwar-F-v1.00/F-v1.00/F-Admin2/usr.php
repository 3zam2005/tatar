<link rel="stylesheet" href="css/style.css" type="text/css" />
<div id="vlg_search">
<form id="p_form" action="" method="get" >
<p><label>بحث بالرقم</label> <input id="p_id" name="p_id" /></p>
<p><label>بحث بالاسم</label> <input id="p_name" name="p_name" /></p>
<p><label>بحث بالاميل</label> <input id="p_email" name="p_email" /></p>
<p><input id="p_submit" type="submit" name="p_search" value="بحث" /></p>
</form>
</div>
