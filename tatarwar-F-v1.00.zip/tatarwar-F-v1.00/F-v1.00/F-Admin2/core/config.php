﻿<?
$config='../F-Core/con_ndc/s1.php';
 if(file_exists($config)) {
              include_once($config) ;
              $localhost=$AppConfig["db"]["host"];
              $user=$AppConfig["db"]["user"];
              $pass=$AppConfig["db"]["password"];
              $db=$AppConfig["db"]["database"];
              $con = @mysql_connect($localhost,$user,$pass)or die(mysql_error());
              @mysql_select_db($db,$con)or die(mysql_error());
              }
 else{
   exit('تاكد من مسار ملف الكونفج');
 }
?>