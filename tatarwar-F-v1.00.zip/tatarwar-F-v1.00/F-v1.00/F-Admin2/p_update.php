<?php
   include_once('core/config.php');
/////////////////////////////////عرض التفاصيل////////////////////////////////

$id = $_POST['id'];
$name = $_POST['name'];
$email = $_POST['email'];
$gold_num = $_POST['gold_num'];
$plus = $_POST['plus'];
$blocked =$_POST['blocked'];
$active = $_POST['active'];
$type = $_POST['type'];

$sql23 = mysql_query("UPDATE `p_players` SET
                    `name` = '$name',
                    `email` = '$email',
                    `gold_num` = '$gold_num',
                    `active_plus_account` = '$plus',
                    `is_blocked` = '$blocked',
                    `is_active` = '$active',
                    `player_type` = '$type'
                    WHERE `id` = '$id'
                    ") or die("sdfghj");
if($sql23){
  echo "تم التعديل بنجاح";
}else{
  echo "فشل في التعديل برجاء لمحاولة مرة اخرى";
}



?>