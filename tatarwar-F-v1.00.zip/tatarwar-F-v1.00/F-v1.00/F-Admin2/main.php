﻿<?php
@session_start();
ob_start();
if($_SESSION['login'] === false) {
header('location: index.php');
}else if($_SESSION['login'] != true)
{
header('location: index.php');
}
 ?>
<!DOCTYPE HTML>

<html>

<head>
  <title>لوحه تحكم حرب التتار</title>
 <link rel="stylesheet" href="css/style.css" type="text/css" />
 <meta charset="utf-8" />
 <script src="jquery-1.6.js"></script>
 <script src="js/usr.js"></script>
 <script src="js/vlg.js"></script>
 <script>
 $(function(){
   $('#msg').live('click',function(){
     $('#search').load('msg.php');
   });
 });
 </script>
</head>
<body>
<div class="all">
<noscript><h1>قم بتفعيل الجافا</h1></noscript>
    <div class="right">
    <a id="logo" href="http://smartservs.com"><img src="logoadmin.png" alt="سمارت سيرفس" width="108" height="102" border="0"/></a>
       <ul>
       <li id="usr"><a href="#">الاعضاء</a></li>
       <li id="vlg"><a href="#">القرى</a></li>
       <li id="msg"><a href="#">الرسائل</a></li>
       </ul>
  </div>
    <div class="left">
       <div id="search">
       <h3>تم تعديله من قبل سمارت سيرفس</h3>
       <p>SkYPe: SmartServs</p>
       <p>&nbsp;</p>
       </div>
       <div id="result"></div>
    </div>
    <div id="clear"></div>

</div>

</body>

</html>