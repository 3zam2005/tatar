<link rel="stylesheet" href="css/style.css" type="text/css" />
<div id="vlg_search">
<form id="p_form" action="" method="post" >
<p><label>بحث بالرقم القرية</label> <input id="v_id" name="v_id" /></p>
<p><label>بحث بأسم القرية</label>  <input id="v_name" name="v_name" /></p>
<p><label>بحث بأسم الاعب</label> <input id="player_name" name="player_name" /></p>
<p><label>بحث بالأحداثيات</label>:&nbsp;&nbsp;X<input id="x" name="x" size="5" />Y<input id="y" name="y" size='5'/></p>
<input id="v_submit" type="submit" name="v_search" value="بحث" />
</form>
</div>
