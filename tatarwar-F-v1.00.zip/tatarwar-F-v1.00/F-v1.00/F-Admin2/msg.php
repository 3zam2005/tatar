<?
include_once('core/config.php');
$sql = mysql_query("select * from `p_msgs` order by `creation_date` desc limit 20") or die("fdgdfg");
$result="<table><tr><td>من</td><td>الى</td><td>العنوان</td><td>التاريخ</td>";
while($row = mysql_fetch_assoc($sql))
{
  $result .= "<tr><td>$row[from_player_name]</td>";
  $result .= "<td>$row[to_player_name]</td>";
  $result .= "<td class='msg_title'>$row[msg_title]</td>";
  $result .= "<td>$row[creation_date]</td></tr>";
  //$result .= "<tr class='msg_body'><td colspan='4'>$row[msg_body]</td></tr>";

}
$result .= "</table>";
$result = nl2br($result);

?>

<div id="vlg_search">
<form action="" method="post">
    <p><label>بحث الرسائل من :</label><input type="text" id="from"  /></p>
    <p><label>بحث الرسائل الي:</label><input type="text" id="to" /></p>
    <p><input type="submit" id="msgs" value="بحث"/></p>
</form>
</div>
 <script>

  var result = "<?=$result?>";
  $('#result').html(result);
  $('#msgs').live('click',function(){
    var to = $('#to').val();
    var from = $('#from').val();
    $('#result').html('<img src="css/images/loading.gif" />جاري التحميل');
    $.post('p_msg.php',{to : to , from : from},function(data){
      $('#result').html(data);
    });
    return false;
});

</script>
