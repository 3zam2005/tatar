<?php
   include_once('core/config.php');
/////////////////////////////////عرض التفاصيل////////////////////////////////

$id = $_POST['id'];
$name = $_POST['name'];
$special = $_POST['special'];
$cp = $_POST['cp'];

$sql23 = mysql_query("UPDATE `p_villages` SET
                    `village_name` = '$name',
                    `is_special_village` = '$special',
                    `cp` = '$cp'
                    WHERE `id` = '$id'
                    ") or die("sdfghj");
if($sql23){
  echo "تم التعديل بنجاح";
}else{
  echo "فشل في التعديل برجاء لمحاولة مرة اخرى";
}



?>