<?php
include_once('core/config.php');
$id = $_POST['id'];
$tribe_id = $_POST['tribe_id'];
$a = $_POST['a'] ;
$b= $_POST['b'] ;
$c = $_POST['c'] ;
$count = count($a);
if($tribe_id == 1){
   $troopid = 1;
 for($i =0 ; $i<$count ; $i++){
    $d .=  $troopid .' '.$a[$i] .' ' .$b[$i].' '.$c[$i].',';

    $troopid++;

   }
   $d .= '99 1 0 0';
 }
  if($tribe_id == 2){
   $troopid = 11;
for($i =0 ; $i<$count ; $i++){
    $d .=  $troopid .' '.$a[$i] .' ' .$b[$i].' '.$c[$i].',';

    $troopid++;

   }
   $d .= '99 1 0 0';
 }
 else if($tribe_id == 3){
  $troopid = 21;
   for($i =0 ; $i<$count ; $i++){
    $d .=  $troopid .' '.$a[$i] .' ' .$b[$i].' '.$c[$i].',';

    $troopid++;

   }
   $d .= '99 1 0 0';
 }
 else if($tribe_id == 4){
   $troopid = 31;
  for($i =0 ; $i<$count ; $i++){
    $d .=  $troopid .' '.$a[$i] .' ' .$b[$i].' '.$c[$i].',';

    $troopid++;

   }
   $d .= '99 1 0 0';
 }
 else if($tribe_id == 5){
   $troopid = 41;
  for($i =0 ; $i<$count ; $i++){
    $d .=  $troopid .' '.$a[$i] .' ' .$b[$i].' '.$c[$i].',';

    $troopid++;

   }
   $d .= '99 1 0 0';
 }
 else if($tribe_id == 6){
   $troopid = 51;
   for($i =0 ; $i<$count ; $i++){
    $d .=  $troopid .' '.$a[$i] .' ' .$b[$i].' '.$c[$i].',';

    $troopid++;

   }
   $d .= '99 1 0 0';
 }
 else if($tribe_id == 7){
   $troopid = 100;
 for($i =0 ; $i<$count ; $i++){
    $d .=  $troopid .' '.$a[$i] .' ' .$b[$i].' '.$c[$i].',';

    $troopid++;

   }
   $d .= '99 1 0 0';
 }


$sql23 = mysql_query("UPDATE `p_villages` SET
                    `troops_training` = '$d'
                    WHERE `id` = '$id'
                    ") or die("sdfghj");
if($sql23){
  echo "تم التعديل بنجاح";
}else{
  echo "فشل في التعديل برجاء لمحاولة مرة اخرى";
}

?>