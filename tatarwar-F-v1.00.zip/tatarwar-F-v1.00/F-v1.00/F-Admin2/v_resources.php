<?php
include_once('core/config.php');
$id = $_POST['id'];
$all_resources = $_POST['all_resources'] ;
$sql23 = mysql_query("UPDATE `p_villages` SET
                    `resources` = '$all_resources'
                    WHERE `id` = '$id'
                    ") or die("sdfghj");
if($sql23){
  echo "تم التعديل بنجاح";
}else{
  echo "فشل في التعديل برجاء لمحاولة مرة اخرى";
}

?>