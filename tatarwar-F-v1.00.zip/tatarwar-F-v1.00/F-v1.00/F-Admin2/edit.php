<style>
 #email , #ip , #last{
  width: 200px;
}
</style>
<?php
include_once('core/config.php');
/////////////////////////////////عرض التفاصيل////////////////////////////////

$id = $_POST[id];

$sql = mysql_query("SELECT * FROM  `p_players` where `id`='$id'")or die(mysql_error()) ;
$row =mysql_fetch_assoc($sql);
$trible_id =  $row['tribe_id'];
switch($trible_id){
  case 1:
    $trible_name = "رومان";
  break;
  case 2:
    $trible_name = "جرمان";
  break;
  case 3:
    $trible_name = "أغريق";
  break;
  case 4:
    $trible_name = "وحوش";
  break;
  case 5:
    $trible_name = "تتار";
  break;
  case 6:
    $trible_name = "دبور";
  break;
  case 7:
    $trible_name = "العرب";
  break;
}

$name = $row['name'];
$email = $row['email'];
$is_active = $row['is_active'];
if($is_active == 0){
  $active = "غير مفعل";
}elseif($is_active == 1){
  $active = "مفعل";
}
$is_blocked = $row['is_blocked'];
if($is_blocked == 0){
  $blocked = "غير مطرود";
}elseif($is_blocked == 1){
  $blocked = "مطرود";
}
$active_plus_account = $row['active_plus_account'];
if($active_plus_account == 0){
  $plus = "غير مشترك";
}elseif($active_plus_account == 1){
  $plus = "مشترك";
}
$last_login_date = $row['last_login_date'];
$last_ip = $row['last_ip'];
$gold_num = $row['gold_num'];
$total_people_count = $row['total_people_count'];
$player_type = $row['player_type'] ;


?>
<div id="form_update">
<form id="form_update" method="post" action="">
<table>
<tr>
<td>رقم الاعب</td>
<td><input id="id" name="id" value="<?= $id ?>"  /></td>
</tr>
<tr>
<td>اسم الاعب</td>
<td><input id="name" name="name" value="<?= $name ?>" /></td>
</tr>
<tr>
<td>البريد</td>
<td><input id="email" name="email" value="<?= $email ?>" /></td>
</tr>
<tr>
<td>القبيلة</td>
<td><input value="<?= $trible_name ?>" disabled /></td>
</tr>
<tr>
<td>الذهب</td>
<td><input id="gold_num" name="gold_num" value="<?= $gold_num ?>" /></td>
</tr>
<tr>
<td>حساب بلس</td>
<td>
<select id="plus" name="plus">
<option value="<?= $active_plus_account ?>"><?= $plus ?></option>
<option value="<?= $active_plus_account == 1? 0 : 1;?>"><?echo $plus == 'مشترك'? 'غير مشترك' : 'مشترك';?></option>
</select>
</td>
</tr>
<tr>
<td>الحالة</td>
<td>
<select id="blocked" name="blocked">
<option value="<?= $is_blocked ?>"><?= $blocked ?></option>
<option value="<?= $is_blocked == 1? 0 : 1;?>"><?echo $blocked == 'مطرود'? 'غير مطرود' : 'مطرود';?></option>
</select>
</td>
</tr>
<tr>
<td>التفعيل</td>
<td>
<select id="active" name="active">
<option value="<?= $is_active ?>"><?= $active ?></option>
<option value="<?= $is_active == 1? 0 : 1;?>"><?echo $active == 'مفعل'? 'غير مفعل' : 'مفعل';?></option>
</select>
</td>
</tr>
<tr>
<td>ip</td>
<td><input id="ip" value="<?= $last_ip ?>" disabled /></td>
</tr>
<tr>
<td>اخر دخول</td>
<td><input id="last" value="<?= $last_login_date ?>" disabled /></td>
</tr>
<tr>
<td>عدد السكان</td>
<td><input value="<?= $total_people_count ?>" /></td>
</tr>
<tr>
<td>مشرف</td>
<td>
<select id="type" name="type">
<option value="1" <?=($player_type == 1)? 'selected' : false ?>>لاعب</option>
<option value="2" <?=($player_type == 2)? 'selected' : false ?>>ادمن</option>
</select>
</td>
</tr>
<tr>
<td colspan="2"><input id ="edit_form" type="submit" name="submit" value="تعديل"></td>
</tr>



</table>
</form>
</div>
<script language="JavaScript" type="text/javascript">
$('#edit_form').click(function(){
 var id = $('#id').val();
 var name = $('#name').val();
 var email = $('#email').val();
 var gold_num = $('#gold_num').val();
 var plus = $('#plus').val();
 var blocked = $('#blocked').val();
 var active = $('#active').val();
 var type = $('#type').val();
 $('#result').html('<img src="css/images/loading.gif" />جاري التحميل');
$.post('p_update.php',{id:id,name:name,email:email,gold_num:gold_num,plus:plus,blocked:blocked,active:active,type:type},function(data){
    $('#result').html(data);
});
return false;
});

</script>