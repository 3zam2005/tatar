$(function(){
  $('#usr').live('click',function(){
  $('#search').load('usr.php');
  $('#result').html('');
  return false;
});

$('#p_submit').live('click',function(){
  var id = $('#p_id').val();
  var name = $('#p_name').val();
  var email = $('#p_email').val();
  $('#result').html('<img src="css/images/loading.gif" />جاري التحميل');
  $.post('view.php',{id:id,name:name,email:email},function(data){

      $('#result').html(data);
  });
  return false;
});



});


