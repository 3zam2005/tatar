$(function(){
  $('#vlg').live('click',function(){
  $('#search').load('vlg.php');
  $('#result').html('');
   return false;
});

$('#v_submit').live('click',function(){
  var id = $('#v_id').val();
  var v_name = $('#v_name').val();
  var player_name = $('#player_name').val();
  var x = $('#x').val();
  var y = $('#y').val();
  $('#result').html('<img src="css/images/loading.gif" />جاري التحميل');
  $.post('v_view.php',{v_id:id,v_name:v_name,player_name:player_name,x:x,y:y},function(data){

      $('#result').html(data);
  });
  return false;
});



});
