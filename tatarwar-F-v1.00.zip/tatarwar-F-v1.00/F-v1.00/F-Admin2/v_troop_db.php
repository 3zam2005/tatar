<?php
include_once('core/config.php');
$troop_db = $_POST['troop_db'];
$id = $_POST['id'];


$sql23 = mysql_query("UPDATE `p_villages` SET
                    `troops_num` = '$troop_db'
                    WHERE `id` = '$id'
                    ") or die("sdfghj");
if($sql23){
  echo "تم التعديل بنجاح";
}else{
  echo "فشل في التعديل برجاء لمحاولة مرة اخرى";
}
?>

