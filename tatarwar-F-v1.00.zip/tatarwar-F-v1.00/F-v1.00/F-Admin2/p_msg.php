<?php
include_once('core/config.php');
$to = $_POST[to];
$from = $_POST[from];
if($to)
{
  $from ='';
  $sql = mysql_query("select * from `p_msgs` where `to_player_name` = '$to' order by `creation_date` desc");
  $result="<table><tr><td>من</td><td>الى</td><td>العنوان</td><td>التاريخ</td>";
while($row = mysql_fetch_assoc($sql))
{
  $result .= "<tr><td>$row[from_player_name]</td>";
  $result .= "<td>$row[to_player_name]</td>";
  $result .= "<td class='msg_title'>$row[msg_title]</td>";
  $result .= "<td>$row[creation_date]</td></tr>";
  $result .= "<tr  class='msg_body'><td colspan='4'>$row[msg_body]</td></tr>";
}
$result .= "</table>";
$result = nl2br($result);
}
if($from)
{
  $to='';
  $sql = mysql_query("select * from `p_msgs` where `from_player_name` = '$from' order by `creation_date` desc");
  $result="<table><tr><td>من</td><td>الى</td><td>العنوان</td><td>التاريخ</td>";
while($row = mysql_fetch_assoc($sql))
{
  $result .= "<tr><td>$row[from_player_name]</td>";
  $result .= "<td>$row[to_player_name]</td>";
  $result .= "<td class='msg_title'>$row[msg_title]</td>";
  $result .= "<td>$row[creation_date]</td></tr>";
  $result .= "<tr  class='msg_body'><td colspan='4'>$row[msg_body]</td></tr>";
}
$result .= "</table>";
$result = nl2br($result);

}
echo $result;

?>
   <script>
$('.msg_body').hide();
$('.msg_title').click(function(){
  $(this).parent().next().slideToggle();
});
</script>