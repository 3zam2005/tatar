<?php
   include_once('core/config.php');
/////////////////////////////////عرض التفاصيل////////////////////////////////

$id = $_POST['id'];
$asd1 = $_POST['asd1'];
$bulid = 0;
$level = 1;
$pos = 2;
$asd1 = explode('&',$asd1);
$ii = 0;
foreach($asd1 as $val)
{
  $a = explode('=',$val);
  $asd[$ii] = $a[1];
  $ii++;
}

$count = count($asd);


for($i=0;$i<$count;$i++)
{
  $bulding .= $asd[$bulid]." ";
  $bulid +=3;

  $levels .= $asd[$level]." ";
  $level +=3;

  $position .= $asd[$pos]." ";
  $pos +=3;
}
$bulding = explode(' ',$bulding);
$levels = explode(' ',$levels) ;
$position = explode(' ',$position) ;

$x = 0 ;

for($count2= 1; $count2<=40 ; $count2++)
{
  if($position[$x] == $count2)
        {
            $mm .= $bulding[$x].' '.$levels[$x].' '.'0' ;
            $x++;
            if($count2!=40){
              $mm .=',';
            }
        }
        else
        {
          $mm .= '0 0 0' ;
          if($count2!=40){
              $mm .=',';
            }
        }
}


$sql23 = mysql_query("UPDATE `p_villages` SET
                    `buildings` = '$mm'
                    WHERE `id` = '$id'
                    ") or die("sdfghj");
if($sql23){
  echo "تم التعديل بنجاح";
}else{
  echo "فشل في التعديل برجاء لمحاولة مرة اخرى";
}



?>