<?php
include_once('core/config.php');
/////////////////////////////////عرض التفاصيل////////////////////////////////
$id = $_POST[id];
$sql = mysql_query("SELECT * FROM  `p_villages` where `id`='$id'")or die(mysql_error()) ;
$row =mysql_fetch_assoc($sql);
$id = $row['id'];
$tribe_id = $row['tribe_id'];
$village_name =  $row['village_name'];
$player_name  = $row['player_name'];
$is_capital = $row['is_capital'];
if($is_capital == 0){
  $capital = "قرية فرعية";
}elseif($is_capital == 1){
  $capital = "عاصمه";
}
$is_special_village  = $row['is_special_village'];
if($is_special_village  == 0){
  $special = "عادية";
}elseif($is_special_village  == 1){
  $special = "معجزة";
}
$cp = $row['cp'];
$cp = explode(' ',$cp);
$all_cp = $cp[0] ;
$v_cp = $cp[1] ;
$resources  = $row['resources'];
$resources =explode(',',$resources);
//
$lumber = $resources[0];
$lumber = explode(' ',$lumber);
//lumber = $lumber[0];
$lumber_resources = $lumber[1];
$lumber_store_max = $lumber[2];
$lumber_store_start = $lumber[3];
$lumber_production_rate = $lumber[4];
$lumber_percent = $lumber[5];

$clay = $resources[1];
$clay = explode(' ',$clay);
//clay = $clay[0];
$clay_resources = $clay[1];
$clay_store_max = $clay[2];
$clay_store_start = $clay[3];
$clay_production_rate = $clay[4];
$clay_percent = $clay[5];

$iron = $resources[2];
$iron = explode(' ',$iron);
//Iron = $lumber[0];
$iron_resources = $iron[1];
$iron_store_max = $iron[2];
$iron_store_start = $iron[3];
$iron_production_rate = $iron[4];
$iron_percent = $iron[5];

$crop = $resources[3];
$crop = explode(' ',$crop);
//lumber = $crop[0];
$crop_resources = $crop[1];
$crop_store_max = $crop[2];
$crop_store_start = $crop[3];
$crop_production_rate = $crop[4];
$crop_percent = $crop[5];

//
$buildings  = $row['buildings'];
$buildings = explode(',',$buildings);

// القوات
$troops = $row['troops_num'];
$all_troops = explode('|',$troops);
$own_troops = explode(':',$all_troops[0]);
$own_troops = explode(',',$own_troops[1]);
//
$troops_training = $row['troops_training'] ;
$troops_training =explode(',',$troops_training);

$reinforce_num = count($all_troops)-1;
if($reinforce_num >= 1){
  for($i=1;$i<=$reinforce_num;$i++)
  {
    $reinforce .= $all_troops[$i];
    if($i != $reinforce_num)
    {
       $reinforce.="|";
    }
  }
}
?>
  <table id="troops">
  <form action="" method="post">
  <tr>
 <?
////////////////////////// القوات
foreach($own_troops as $troops){
  $troop = explode(' ',$troops);
  switch ($troop[0]) {
     case 1:
      ?>
        <td>جندي أول</td>
      <?
    break ;
     case 2:
        ?>
        <td>حراس الأمبراطور</td>
      <?
    break ;
     case 3:
        ?>
        <td>جندي مهاجم</td>
      <?
    break;
     case 4:
        ?>
        <td>فرقة تجسس</td>
      <?
    break ;
     case 5:
        ?>
        <td>سلاح الفرسان</td>
      <?
    break ;
     case 6:
        ?>
        <td>فرسان قيصر</td>
      <?
    break ;
     case 7:
        ?>
        <td>كبش</td>
      <?
    break ;
     case 8:
        ?>
        <td>المقلاع الناري</td>
      <?
    break ;
     case 9:
        ?>
        <td>حكيم</td>
      <?
    break ;
     case 10:
        ?>
        <td>مستوطن</td>
      <?
    break ;
    case 11:
      ?>
        <td>مقاتل بهراوة</td>
      <?
    break ;
     case 12:
        ?>
        <td>مقاتل برمح</td>
      <?
    break ;
     case 13:
        ?>
        <td>مقاتل بفأس</td>
      <?
    break;
     case 14:
        ?>
        <td>الكشاف</td>
      <?
    break ;
     case 15:
        ?>
        <td>فرسان القيصر</td>
      <?
    break ;
     case 16:
        ?>
        <td>فرسان الجرمان</td>
      <?
    break ;
     case 17:
        ?>
        <td>محطمات الابواب</td>
      <?
    break ;
     case 18:
        ?>
        <td>مقاليع</td>
      <?
    break ;
     case 19:
        ?>
        <td>زعيم</td>
      <?
    break ;
     case 20:
        ?>
        <td>مستوطن</td>
      <?
    break ;
     case 21:
        ?>
          <td>الكتيبه</td>
        <?
    break  ;
     case 22:
        ?>
          <td>مبارز</td>
        <?
    break ;
     case 23:
        ?>
          <td>المستكشف</td>
        <?
    break;
     case 24:
        ?>
          <td>رعد الإغريق</td>
        <?
    break ;
     case 25:
       ?>
          <td>فرسان السلت</td>
        <?
    break  ;
     case 26:
       ?>
          <td>فرسان الهيدوانر</td>
        <?
    break  ;
     case 27:
       ?>
          <td>محطمة الابواب</td>
        <?
    break  ;
     case 28:
        ?>
          <td>المقلاع الحربي</td>
        <?
    break  ;
     case 29:
       ?>
          <td>رئيس</td>
        <?
    break ;
     case 30:
       ?>
          <td>مستوطن</td>
        <?
    break ;
     case 31:
        ?><td>الجرذ</td><?
    break ;
    case 32:
        ?><td>العنكبوت</td><?
    break ;
     case 33:
         ?><td>الأفعى</td><?
    break ;
     case 34:
         ?><td>خفاش</td><?
    break ;
     case 35:
        ?><td>الخنزير البري</td><?
    break ;
     case 36:
        ?><td>الذئب</td><?
    break ;
     case 37:
        ?><td>دب</td><?
    break ;
     case 38:
        ?><td>التمساح</td><?
    break ;
     case 39:
        ?><td>النمر</td><?
    break ;
     case 40:
         ?><td>الفيل</td><?
    break ;

     case 41:
         ?><td></td><?
    break  ;
     case 42:
        ?><td></td><?
    break ;
     case 43:
         ?><td></td><?
    break ;
     case 44:
        ?><td></td><?
    break ;
     case 45:
        ?><td></td><?
    break ;
     case 46:
        ?><td></td><?
    break ;
     case 47:
         ?><td></td><?
    break ;
     case 48:
        ?><td></td><?
    break ;
     case 49:
        ?><td></td><?
    break ;
     case 50:
        ?><td></td><?
    break ;
     case 51:
        ?><td>مقاتل النينجا</td><?
    break  ;
    case 52:
       ?><td>مقاتل السيف</td><?
    break   ;
     case 53:
         ?><td>المهاجم الشرس</td><?
    break     ;
     case 54:
         ?><td>الساحرة</td><?
    break      ;
     case 55:
      ?><td>الفارس الخناق</td><?
    break       ;
     case 56:
        ?><td>فارس السهام</td><?
    break        ;
     case 57:
         ?><td>محطمة الأسوار</td><?
    break;
     case 58:
          ?><td>المدفع الناري</td><?
    break ;
     case 59:
        ?><td>الملك</td><?
    break  ;
     case 60:
         ?><td>المستوطن</td><?
    break   ;
     case 100:
         ?><td>رامي السهام</td><?
    break    ;
     case 101:
          ?><td>محارب بشوكه</td><?
    break     ;
     case 102:
          ?><td>الحارس</td><?
    break      ;
     case 103:
          ?><td>طائر التجسس</td><?
    break       ;
     case 104:
          ?><td>فارس العرب</td><?
    break        ;
     case 105:
          ?><td>فارس الفؤوس</td><?
    break         ;
     case 106:
          ?><td>الكبش</td><?
    break    ;
     case 107:
          ?><td>المنجنيق الناري</td><?
    break    ;
     case 108:
           ?><td>الملك</td><?
    break   ;
    case 109:
           ?><td>مستوطن</td><?
    break   ;

  }
}
?>

  </tr>

  <tr>

  <?
   foreach($own_troops as $troops_num){
     $troop_num = explode(' ',$troops_num);
     if($troop_num[0]== "99"){
       break;
     }
     ?>

     <td><input class="troops_input" name="troops[]" value="<?= $troop_num[1] ?>" /></td>
     <?

   }
$id_player = $row['player_id'] ;
$sql2 = mysql_query("SELECT `hero_name` , `hero_in_village_id` FROM  `p_players` where `id`='$id_player'")or die(mysql_error()) ;
$row2 =mysql_fetch_assoc($sql2);
$hero_name = $row2['hero_name'];
$hero_in_village_id = $row2['hero_in_village_id'];
$sql2 = mysql_query("SELECT `village_name`  FROM  `p_villages` where `id`='$hero_in_village_id'")or die(mysql_error()) ;
$row2 =mysql_fetch_assoc($sql2);
$village_hero =  $row2['village_name'];

  ?>
  </tr>
  <tr>
  <td colspan="10">اسم البطل <?= $hero_name ?> &nbsp; متواجد فى القرية &nbsp; <?= $village_hero ?> </td>
    </tr>


   <tr>
   <td colspan="10">
    <input id="edit_troops" type="submit" name="troop_submit" value="تعديل" />
   </td>
   </tr>

  </form>
  </table>
<!--
/////////////////////////////////////////////////////////////////////////////
نهايه القوات
 -->

 <!--
/////////////////////////////////////////////////////////////////////////////
بدايه تسليح القوات
 -->

  <table id="troops_training">
  <form method="post">
  <tr>
    <th>القوات</th>
<?
foreach($troops_training as $training){
  $troop_train = explode(' ',$training);
  switch ($troop_train[0]) {
     case 1:
      ?>
        <th>جندي أول</th>
      <?
    break ;
     case 2:
        ?>
        <th>حراس الأمبراطور</th>
      <?
    break ;
     case 3:
        ?>
        <th>جندي مهاجم</th>
      <?
    break;
     case 4:
        ?>
        <th>فرقة تجسس</th>
      <?
    break ;
     case 5:
        ?>
        <th>سلاح الفرسان</th>
      <?
    break ;
     case 6:
        ?>
        <th>فرسان قيصر</th>
      <?
    break ;
     case 7:
        ?>
        <th>كبش</th>
      <?
    break ;
     case 8:
        ?>
        <th>المقلاع الناري</th>
      <?
    break ;
     case 9:
        ?>
        <th>حكيم</th>
      <?
    break ;
     case 10:
        ?>
        <th>مستوطن</th>
      <?
    break ;
    case 11:
      ?>
        <th>مقاتل بهراوة</th>
      <?
    break ;
     case 12:
        ?>
        <th>مقاتل برمح</th>
      <?
    break ;
     case 13:
        ?>
        <th>مقاتل بفأس</th>
      <?
    break;
     case 14:
        ?>
        <th>الكشاف</th>
      <?
    break ;
     case 15:
        ?>
        <th>فرسان القيصر</th>
      <?
    break ;
     case 16:
        ?>
        <th>فرسان الجرمان</th>
      <?
    break ;
     case 17:
        ?>
        <th>محطمات الابواب</th>
      <?
    break ;
     case 18:
        ?>
        <th>مقاليع</th>
      <?
    break ;
     case 19:
        ?>
        <th>زعيم</th>
      <?
    break ;
     case 20:
        ?>
        <th>مستوطن</th>
      <?
    break ;
     case 21:
        ?>
          <th>الكتيبه</th>
        <?
    break  ;
     case 22:
        ?>
          <th>مبارز</th>
        <?
    break ;
     case 23:
        ?>
          <th>المستكشف</th>
        <?
    break;
     case 24:
        ?>
          <th>رعد الإغريق</th>
        <?
    break ;
     case 25:
       ?>
          <th>فرسان السلت</th>
        <?
    break  ;
     case 26:
       ?>
          <th>فرسان الهيدوانر</th>
        <?
    break  ;
     case 27:
       ?>
          <th>محطمة الابواب</th>
        <?
    break  ;
     case 28:
        ?>
          <th>المقلاع الحربي</th>
        <?
    break  ;
     case 29:
       ?>
          <th>رئيس</th>
        <?
    break ;
     case 30:
       ?>
          <th>مستوطن</th>
        <?
    break ;
     case 31:
        ?><th>الجرذ</th><?
    break ;
    case 32:
        ?><th>العنكبوت</th><?
    break ;
     case 33:
         ?><th>الأفعى</th><?
    break ;
     case 34:
         ?><th>خفاش</th><?
    break ;
     case 35:
        ?><th>الخنزير البري</th><?
    break ;
     case 36:
        ?><th>الذئب</th><?
    break ;
     case 37:
        ?><th>دب</th><?
    break ;
     case 38:
        ?><th>التمساح</th><?
    break ;
     case 39:
        ?><th>النمر</th><?
    break ;
     case 40:
         ?><th>الفيل</th><?
    break ;

     case 41:
         ?><th></th><?
    break  ;
     case 42:
        ?><th></th><?
    break ;
     case 43:
         ?><th></th><?
    break ;
     case 44:
        ?><th></th><?
    break ;
     case 45:
        ?><th></th><?
    break ;
     case 46:
        ?><th></th><?
    break ;
     case 47:
         ?><th></th><?
    break ;
     case 48:
        ?><th></th><?
    break ;
     case 49:
        ?><th></th><?
    break ;
     case 50:
        ?><th></th><?
    break ;
     case 51:
        ?><th>مقاتل النينجا</th><?
    break  ;
    case 52:
       ?><th>مقاتل السيف</th><?
    break   ;
     case 53:
         ?><th>المهاجم الشرس</th><?
    break     ;
     case 54:
         ?><th>الساحرة</th><?
    break      ;
     case 55:
      ?><th>الفارس الخناق</th><?
    break       ;
     case 56:
        ?><th>فارس السهام</th><?
    break        ;
     case 57:
         ?><th>محطمة الأسوار</th><?
    break;
     case 58:
          ?><th>المدفع الناري</th><?
    break ;
     case 59:
        ?><th>الملك</th><?
    break  ;
     case 60:
         ?><th>المستوطن</th><?
    break   ;
     case 100:
         ?><th>رامي السهام</th><?
    break    ;
     case 101:
          ?><th>محارب بشوكه</th><?
    break     ;
     case 102:
          ?><th>الحارس</th><?
    break      ;
     case 103:
          ?><th>طائر التجسس</th><?
    break       ;
     case 104:
          ?><th>فارس العرب</th><?
    break        ;
     case 105:
          ?><th>فارس الفؤوس</th><?
    break         ;
     case 106:
          ?><th>الكبش</th><?
    break    ;
     case 107:
          ?><th>المنجنيق الناري</th><?
    break    ;
     case 108:
           ?><th>الملك</th><?
    break   ;
    case 109:
           ?><th>مستوطن</th><?
    break   ;

  }
}
?>

  </tr>

  <tr>
  <th>الاكادمية</th>
  <?
  foreach($troops_training as $training){
  $troop_train = explode(' ',$training);
  if($troop_train[0]== "99"){
    break;
  }



   ?>
  <td>

  <select class="t_train">
        <option value="1" <?=$troop_train[1] ==1? 'selected' : false;?>>نعم</option>
        <option value="0" <?=$troop_train[1] ==0? 'selected' : false;?>>لا</option>

      </select>
      </td>
    <?
  }
  ?>
  </tr>
  <!--
 الحداد
   -->
  <tr>
  <th>مستودع الاسلحة</th>
   <?
  foreach($troops_training as $training){
  $troop_train = explode(' ',$training);
  if($troop_train[0]== "99"){
       break;
     }
   ?>
  <td>

  <input class="t_train_d" value="<?=$troop_train[2]?>" /></td>
    <?
  }
  ?>
  </tr>

  <tr>
  <th>الحداد</th>
   <?
  foreach($troops_training as $training){
  $troop_train = explode(' ',$training);
  if($troop_train[0]== "99"){
       break;
     }
   ?>
  <td>

    <input class="t_train_a" value="<?=$troop_train[3]?>" />
    </td>
    <?
  }
  ?>
  </tr>
  <tr>
  <td colspan="11"><input id="tasleeh" type="button"  value="تعديل" /></td>
  </tr>
   </form>
  </table>





<?
////////////////////////////////////////////////////////////////////////////
$a=0 ;
?>

  <table id="location">
  <form id="frm_loca"  action="" method="post">
  <tr>
    <td>المبنى</td>
    <td>المستوى</td>
    <td>البقعة</td>
  </tr>
<?
foreach ($buildings as $value) {
  $a++;

$val = explode(' ',$value) ;

switch ($val[0]) {
  case 1:
  ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="1" />الحطاب</td>
    <td><input class="building"  type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td class="building_id"><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break;
  case 2:
 ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="2" />الطين</td>
    <td><input class="building" type="text" name="a" value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break ;
  case 3:
  ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="3" />الحديد</td>
    <td><input class="building" type="text" name="a" value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break;
  case 4:
 ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="4" />القمح</td>
    <td><input class="building" type="text" name="a" value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break ;
  case 5:
   ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="5" />معمل النجارة</td>
    <td><input class="building" type="text" name="a" value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break;
  case 6:
  ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="6" />مصنع الطوب</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break ;
  case 7:
   ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="7" />مصنع الحديد</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break;
  case 8:
  ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="8" />المطاحن</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break ;
  case 9:
   ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="9" />المخابز</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break;
  case 10:
  ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="10" />المخزن</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break ;
  case 11:
?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="11" />مخزن الحبوب</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?  break ;
  case 12:
?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="12" />الحداد</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?  break ;
  case 13:
?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="13" />مستودع الاسلحة</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?  break ;
  case 14:
?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="14" />ساحة البطولة</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?  break ;
  case 15:
?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="15" />البيت الرئيسي</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?  break ;
    case 16:
  ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="16" />نقطة التجمع</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break;
  case 17:
 ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="17" />السوق</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break ;
  case 18:
  ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="18" />السفارة</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break;
  case 19:
 ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="19" />الثكنة</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break ;
  case 21:
   ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="21" />المصانع الحربية</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break;
  case 22:
  ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="22" />الاكاديميه</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break ;
  case 23:
   ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="23" />المخبأ</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break;
  case 24:
  ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="24" />البلدية</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break ;
  case 25:
   ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="25" />السكن</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break;
  case 26:
  ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="26" />المخزن</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break ;
  case 27:
?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="27" />القصر</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?  break ;
  case 28:
?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="28" />المكتب التجاري</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?  break ;
  case 29:
?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="29" />ثكنة كبيرة</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?  break ;
  case 30:
?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="30" />إسطبل كبير</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?  break ;
  case 31:
?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="31" />الحائط الأرضي</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?  break ;
    case 34:
  ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="34" />الحجار</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break;
  case 35:
 ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="35" />المعصرة</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break ;
  case 36:
  ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="36" />الصياد</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break;
  case 37:
 ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="37" />قصر الأبطال</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break ;
  case 38:
   ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="38" />مخزن كبير</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break;
  case 39:
  ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="39" />مخزن حبوب كبير</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break ;
  case 40:
   ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="40" />معجزه العالم</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break;
  case 41:
  ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="41" />ساقية الخيول</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<?= $a ?>" /><?= $a ?></td>
  </tr>
  <?
  break ;
  case 42:
   ?>
    <tr>
    <td><input class="building" name="a" type="hidden" value="42" />سوق المحاربين</td>
    <td><input class="building" type="text" name="a"  value="<?= $val[1] ?>" /></td>
    <td><input class="building" name="a" type="hidden" value="<input class="building" name="a" type="hidden" value="<?= $a ?>" />" /></td>
  </tr>
  <?
  break;
 }


}
 ?>
 <tr>
 <td colspan="3"><input id="loca" type="button" value="تعديل"  /></td>
 </tr>
 </form>
 </table>

<form id="form_update" method="post" action="">
<table id="basic">
<tr>
<td>رقم القرية</td>
<td><input id="id" name="id" value="<?= $id ?>" disabled /></td>
</tr>
<tr>
<td>اسم القرية</td>
<td><input id="village_name" name="village_name" value="<?= $village_name ?>" /></td>
</tr>
<tr>
<td>مالك القرية</td>
<td><input id="player_name" name="player_name" value="<?= $player_name ?>" disabled /></td>
</tr>
<tr>
<td>عاصمة</td>
<td><input value="<?= $capital ?>"  disabled  /></td>
</tr>
<tr>
<td>قريه معجزة</td>
<td><input id="special" name="special" value="<?= $special ?>" disabled/></td>
</tr>
<tr>
<td>النقط الحضارية</td>
<td><input id="v_cp" name="v_cp" value="<?= $v_cp ?>" /></td>
</tr>
<tr>

<input type="hidden" id="all_cp" name="all_cp" value="<?= $all_cp ?>" />
</tr>


<tr>
<td colspan="2"><input id ="edit_form" type="submit" name="submit" value="تعديل"></td>
</tr>
</table>
</form>

<form action="" method="post">
<table id="resources">
<tr>
<td colspan="5" >الموارد</td>
</tr>
<tr>
<td>خيارت</td>
<td>الخشب</td>
<td>طين</td>
<td>حديد</td>
<td>قمح</td>
</tr>
<tr>
<td>الانتاج بالمخازن</td>
<td><input id="lumber_resources" type="text" value="<?= $lumber_resources ?>" /></td>
<td><input id="clay_resources" type="text" value="<?= $clay_resources ?>" /></td>
<td><input id="iron_resources" type="text" value="<?= $iron_resources ?>" /></td>
<td><input id="crop_resources" type="text" value="<?= $crop_resources ?>" /></td>
</tr>
<tr>
<td>اقصى سعه للمخزن</td>
<td><input id="lumber_store_max" type="text" value="<?= $lumber_store_max ?>" /></td>
<td><input id="clay_store_max" type="text" value="<?= $clay_store_max ?>" /></td>
<td><input id="iron_store_max" type="text" value="<?= $iron_store_max ?>" /></td>
<td><input id="crop_store_max" type="text" value="<?= $crop_store_max ?>" /></td>
</tr>
<tr>
<td>بدايه المخزن</td>
<td><input id="lumber_store_start" type="text" value="<?= $lumber_store_start ?>" /></td>
<td><input id="clay_store_start" type="text" value="<?= $clay_store_start ?>" /></td>
<td><input id="iron_store_start" type="text" value="<?= $iron_store_start ?>" /></td>
<td><input id="crop_store_start" type="text" value="<?= $crop_store_start ?>" /></td>
</tr>
<tr>
<td>الانتاج فى الساعة</td>
<td><input id="lumber_production_rate" type="text" value="<?= $lumber_production_rate ?>" /></td>
<td><input id="clay_production_rate" type="text" value="<?= $clay_production_rate ?>" /></td>
<td><input id="iron_production_rate" type="text" value="<?= $iron_production_rate ?>" /></td>
<td><input id="crop_production_rate" type="text" value="<?= $crop_production_rate ?>" /></td>
</tr>
<tr>
<td>نسبه الزياده %</td>
<td><input id="lumber_percent" type="text" value="<?= $lumber_percent ?>" /></td>
<td><input id="clay_percent" type="text" value="<?= $clay_percent ?>" /></td>
<td><input id="iron_percent" type="text" value="<?= $iron_percent ?>" /></td>
<td><input id="crop_percent" type="text" value="<?= $crop_percent ?>" /></td>
</tr>
<tr>
<td colspan="10">
<input id="edit_resources" type="button" name="troop_submit" value="تعديل" />
</td>
</tr>
</table>
</form>

<script type="text/javascript">
$('#edit_form').click(function(){
 var id = $('#id').val();
 var name = $('#village_name').val();
 var special = $('#special').val();
 if (special=='معجزة')
 {
  special = 1 ;
 }
 else if(special=='عادية')
 {
  special = 0  ;
 }
 var v_cp = $('#v_cp').val();
 var all_cp = $('#all_cp').val();
 var cp = all_cp + ' ' + v_cp ;
 $('#result').html('<img src="css/images/loading.gif" />جاري التحميل');
$.post('v_update.php',{id:id,name:name,special:special,cp:cp},function(data){
    $('#result').html(data);
});
return false;
});

</script>

<script>
$('#basic').hide();
$('#troops').hide();
$('#troops_training').hide();
$('#resources').hide();
$('#location').hide();
</script>

<script>
$('#edit_troops').click(function(){
 var id = $('#id').val();
 var tribe_id = "<?=$tribe_id?>" ;
 var reinforce = "<?= $reinforce ?>";
  troop_db = "-1:";
  if(tribe_id == 1){
   var troopid = 1;
   $('.troops_input').each(function(){
   var a = $(this).val();
   troop_db = troop_db + troopid+" "+a+",";
   troopid++;

 });
 }
  if(tribe_id == 2){
   var troopid = 11;
   $('.troops_input').each(function(){
   var a = $(this).val();
   troop_db = troop_db + troopid+" "+a+",";
   troopid++;

 });
 }
 else if(tribe_id == 3){
   var troopid = 21;
   $('.troops_input').each(function(){
   var a = $(this).val();
   troop_db = troop_db + troopid+" "+a+",";
   troopid++;

 });
 }
 else if(tribe_id == 4){
   var troopid = 31;
   $('.troops_input').each(function(){
   var a = $(this).val();
   troop_db = troop_db + troopid+" "+a+",";
   troopid++;

 });
 }
 else if(tribe_id == 5){
   var troopid = 41;
   $('.troops_input').each(function(){
   var a = $(this).val();
   troop_db = troop_db + troopid+" "+a+",";
   troopid++;

 });
 }
 else if(tribe_id == 6){
   var troopid = 51;
   $('.troops_input').each(function(){
   var a = $(this).val();
   troop_db = troop_db + troopid+" "+a+",";
   troopid++;

 });
 }
 else if(tribe_id == 7){
   var troopid = 100;
   $('.troops_input').each(function(){
   var a = $(this).val();
   troop_db = troop_db + troopid+" "+a+",";
   troopid++;

 });

  }
  if(reinforce == ''){
  troop_db = troop_db + "99 0";
  }else
  {
   troop_db = troop_db + "99 0"+"|"+reinforce;
  }
   $('#result').html('<img src="css/images/loading.gif" />جاري التحميل');
$.post('v_troop_db.php',{id : id ,troop_db:troop_db},function(data){
    $('#result').html(data);
});
return false;
});
</script>

<script>
$('#edit_resources').click(function(){

var id = $('#id').val();
var lumber_resources = $('#lumber_resources').val();
var lumber_store_max = $('#lumber_store_max').val();
var lumber_store_start = $('#lumber_store_start').val();
var lumber_production_rate = $('#lumber_production_rate').val();
var lumber_percent = $('#lumber_percent').val();

var clay_resources = $('#clay_resources').val();
var clay_store_max = $('#clay_store_max').val();
var clay_store_start = $('#clay_store_start').val();
var clay_production_rate = $('#clay_production_rate').val();
var clay_percent = $('#clay_percent').val();


var iron_resources = $('#iron_resources').val();
var iron_store_max = $('#iron_store_max').val();
var iron_store_start = $('#iron_store_start').val();
var iron_production_rate = $('#iron_production_rate').val();
var iron_percent = $('#iron_percent').val();


var crop_resources = $('#crop_resources').val();
var crop_store_max = $('#crop_store_max').val();
var crop_store_start = $('#crop_store_start').val();
var crop_production_rate = $('#crop_production_rate').val();
var crop_percent = $('#crop_percent').val();
var all_resources =
 1 + ' ' + lumber_resources + ' ' + lumber_store_max + ' ' + lumber_store_start + ' ' +
          lumber_production_rate + ' ' + lumber_percent + ',' +
 2 + ' ' + clay_resources + ' ' + clay_store_max + ' ' + clay_store_start + ' ' + clay_production_rate  + ' ' +
          clay_percent + ',' +
 3 + ' ' + iron_resources + ' ' + iron_store_max + ' ' + iron_store_start + ' ' + iron_production_rate + ' ' +
          iron_percent  + ',' +
 4 + ' ' + crop_resources + ' ' + crop_store_max + ' ' + crop_store_start + ' ' + crop_production_rate  + ' ' +
          crop_percent  ;
    $('#result').html('<img src="css/images/loading.gif" />جاري التحميل');
$.post('v_resources.php',{id : id , all_resources : all_resources},function(data){
    $('#result').html(data);
});
});
</script>


<script>
$('#tasleeh').click(function(){
  var id = $('#id').val();
  var tribe_id = "<?=$tribe_id?>" ;
  var a = new Array();
  var i =0;
    $('.t_train').each(function(){
        a[i] = $(this).val();
        i++;
    });

 var i =0;
 var b = new Array();
   $('.t_train_d').each(function(){
   b[i] = $(this).val();
   i++;
    });

  var i = 0 ;
  var c = new Array() ;
  $('.t_train_a').each(function(){
     c[i] = $(this).val();
     i++;
  });
  $('#result').html('<img src="css/images/loading.gif" />جاري التحميل');
 $.post('v_t_train.php',{id : id , tribe_id : tribe_id , a :a , b : b, c : c},function(data){
  $('#result').html(data);
 });



    return false;
});
</script>

<script type="text/javascript">
  var id = $('#id').val();
   var i = 0 ;
  $("#loca").click(function(){

    asd1=$("#frm_loca").serialize();
     $('#result').html('<img src="css/images/loading.gif" />جاري التحميل');
    $.post('v_location.php',{id : id , asd1 : asd1},function(data){
      $('#result').html(data);
    });
  });

</script>
