<?php
  include_once('core/config.php');
  $id=(int)trim($_POST['v_id']);
$village_name=trim($_POST['v_name']);
$player_name=trim($_POST['player_name']);
$x= ($_POST['x']);
$y= ($_POST['y']);

if(!empty($id)){
  $sql = mysql_query("SELECT * FROM  `p_villages` where `id`='$id' &&`is_oasis` !='1' ")or die(mysql_error()) ;
}elseif(!empty($village_name)){
  $sql = mysql_query("SELECT * FROM  `p_villages` where `village_name` like '%$village_name%'  &&`is_oasis` !='1'")or die(mysql_error()) ;
}elseif(!empty($player_name)){
  $sql = mysql_query("SELECT * FROM  `p_villages` where `player_name` like '%$player_name%'  &&`is_oasis` !='1'")or die(mysql_error()) ;
}elseif($x != ""&& $y!="" ){
  $sql = mysql_query("SELECT * FROM  `p_villages` where rel_x='$x' && rel_y = '$y'  &&`is_oasis` !='1'")or die(mysql_error()) ;
}else{
  die("<div id='error'>من فضلك ادخل بيانا صحيحا</div>");
}
$num = mysql_num_rows($sql);
if($num > 0){
?>
<div id="show_smpil">
<table>
<tr>
<th>الرقم</th>
<th>اسم القرية</th>
<th>المالك</th>
<th>عاصمة</th>
<th>قريه معجزة</th>
<th>النقط الحضارية</th>
</tr>


<?

while($row = mysql_fetch_assoc($sql)){
  $id = $row['id'];
$village_name =  $row['village_name'];
$player_name  = $row['player_name'];
$is_capital = $row['is_capital'];
if($is_capital == 0){
  $capital = "قرية فرعية";
}elseif($is_capital == 1){
  $capital = "عاصمه";
}
$is_special_village  = $row['is_special_village'];
if($is_special_village  == 0){
  $special = "عادية";
}elseif($is_special_village  == 1){
  $special = "معجزة";
}
$cp = $row['cp'];
$cp = explode(' ',$cp);
$all_cp = $cp[0] ;
$v_cp = $cp[1] ;

///////////////////////////////عرض البيانات الاساسية////////////////////////////////////

?>
<tr>
<td><?= $id ?></td>
<td><?= $village_name ?></td>
<td><?= $player_name ?></td>
<td><?= $capital ?></td>
<td><?= $special ?></td>
<td><?= $v_cp ?></td>
</tr>
<tr>
<td id ="edit_more" colspan="2"><a  id="edit"  onclick="edit_id(<?= $id ?> ,1)">معلومات القريه الاساسية</a></td>
<td id ="edit_more" ><a id="edit" onclick="edit_id(<?= $id ?>,2)">الانتاج</a></td>
<td id ="edit_more" ><a id="edit" onclick="edit_id(<?= $id ?>,3)">المبانى</a></td>
<td id ="edit_more" ><a id="edit" onclick="edit_id(<?= $id ?>,4)">القوات</a></td>
<td id ="edit_more" ><a id="edit" onclick="edit_id(<?= $id ?>,5)">تسليح القوات</a></td>
</tr>
<?
}
}else{
  ?>
  <div id="error">لا توجد نتائج</div>
  <?
}

?>
</table>
</div>
<script type="text/javascript">
function edit_id(id,ab){
 $.post('v_edit.php',{id:id},function(data){
 $('#result').fadeIn('5000',function(){
 $('#result').html(data);
  if (ab==1)
  {
   $('#basic').show() ;
  }
  else if(ab==2)
  {
   $('#resources').show();
  }
  else if(ab==3)
  {
   $('#location').show();
  }
  else if(ab==4)
  {
   $('#troops').show() ;
  }
  else if(ab==5)
  {
   $('#troops_training').show();
  }
    });
 });

}

</script>