<?php
//config
$num = 1;
$title = 'حرب التتار - لعبة الانترنت - الرومان, الاغريق, الجرمان';
$sitename = 'حرب التتار';
for ($ns=1; $ns<=$num; $ns++) {
$config = "F-Core/con_ndc/s".$ns.".php";
include( $config );
$c[$ns]=($AppConfig['Game']['RegisterOver']);
$s[$ns]=($AppConfig['Game']['speed']);
$link = mysql_connect($AppConfig['db']['host'],$AppConfig['db']['user'],$AppConfig['db']['password']);
mysql_select_db($AppConfig['db']['database'],$link);
$q[$ns] = mysql_query ("SELECT * FROM g_summary");
$r[$ns] = mysql_fetch_assoc ($q[$ns]);
}

$player = array('',$r[1]['players_count'],$r[2]['players_count'],$r[3]['players_count'],$r[4]['players_count'],$r[5]['players_count']);
$dayEnd = array('',$c[1],$c[2],$c[3],$c[4],$c[5]);
$speed  = array('',$s[1],$s[2],$s[3],$s[4],$s[5]);
$day = array('',$r[1]['server_start_time'],$r[2]['server_start_time'],$r[3]['server_start_time'],$r[4]['server_start_time'],$r[5]['server_start_time']);
$allp = $player[1]+$player[2]+$player[3]+$player[4]+$player[5];
 function o99g($diff_in_unix){
  if ($diff_in_unix > 3600){
  $diff .= intval($diff_in_unix/3600);
  $diff_in_unix = $diff_in_unix%3600;
  }else{ $diff .= '0'; }
  return $diff;
  }
?>