<?php
include('c.php');
?><html><meta http-equiv="content-type" content="text/html; charset=UTF-8;charset=utf-8" />
<style type="text/css">
.alignright {
	border:3px solid #C2C2C2;
	border-radius: 10px;
     -moz-border-radius: 10px;
     -webkit-border-radius: 10px;
}
.alignright:hover {
	border:3px solid #FF8000;
	border-radius: 10px;
     -moz-border-radius: 10px;
     -webkit-border-radius: 10px;
}
td{
	border:1px solid #C2C2C2;
	padding-right:0px;
	opacity: 0.8;
}
h1{
	color:#662504;
}
</style>
<span class="close"><!--Close--></span>
<center>
<h1>اختر السيرفر الذي تلعب فيه</h1><div>
            <?php
for ($x=1; $x<=$num; $x++){
          $dayz =  ceil(o99g(time()-$day[$x])/24); 
if ($dayz > $dayEnd[$x] ) {
continue;
}

                                  ?>

<a href="register?s<?php echo $x; ?>" style="color: #000000;font-weight: bold;text-decoration: none;">
<table class="alignright" cellspacing="0" cellpadding="0" dir="rtl">
<tbody>
<tr>
	<td valign="top" width="290" align="center">
		<center><table border="0" cellspacing="0" cellpadding="0" style="padding:8px;font-weight:bold;background-image:url('img/banner.jpg');">
			<tbody>
				<tr>
					<td style="padding:5px;width:180;font-weight:bold;"><img src="img/player.jpg"> عدد اللاعبين:</td>
					<td style="padding:5px;width:98;font-weight:bold;"><?php echo $player[$x]; ?></td>
				</tr>
				<tr>
					<td style="padding:5px;width:180;font-weight:bold;"><img src="img/online.jpg" > اللاعبيون الموجودون حالياً:</td>
					<td style="padding:5px;width:98;font-weight:bold;"><?php echo $player[$x]; ?></td>
				</tr>
				<tr>
					<td style="padding:5px;width:180;font-weight:bold;">بدأ قبل :</td>
					<td style="padding:5px;width:98;font-weight:bold;"> <?php 
echo $dayz;
?> أيام</td>
				</tr>
			</tbody>
		</table></center>
	</td>
</tr>
</tbody>
</table>
</a>
</div>
<?php if ($num > 1 && 0!=($num-$x)) {
?><div style="border-bottom:5px solid #71D000;margin-top:10px;margin-bottom:10px;"></div>
<?php
}
}
?>
</center>