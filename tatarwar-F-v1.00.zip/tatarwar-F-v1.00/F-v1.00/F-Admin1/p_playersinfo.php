<?php

// Global variable for table object
$p_players = NULL;

//
// Table class for p_players
//
class cp_players {
	var $TableVar = 'p_players';
	var $TableName = 'p_players';
	var $TableType = 'TABLE';
	var $id;
	var $tribe_id;
	var $alliance_id;
	var $alliance_name;
	var $alliance_roles;
	var $invites_alliance_ids;
	var $name;
	var $pwd;
	var $zemail;
	var $is_active;
	var $is_blocked;
	var $player_type;
	var $active_plus_account;
	var $activation_code;
	var $last_login_date;
	var $last_ip;
	var $birth_date;
	var $gender;
	var $description1;
	var $description2;
	var $house_name;
	var $registration_date;
	var $gold_num;
	var $agent_for_players;
	var $my_agent_players;
	var $custom_links;
	var $medals;
	var $total_people_count;
	var $selected_village_id;
	var $villages_count;
	var $villages_id;
	var $villages_data;
	var $friend_players;
	var $notes;
	var $hero_troop_id;
	var $hero_level;
	var $hero_points;
	var $hero_name;
	var $hero_in_village_id;
	var $attack_points;
	var $defense_points;
	var $week_attack_points;
	var $week_defense_points;
	var $week_dev_points;
	var $week_thief_points;
	var $new_report_count;
	var $new_mail_count;
	var $guide_quiz;
	var $fields = array();
	var $UseTokenInUrl = EW_USE_TOKEN_IN_URL;
	var $Export; // Export
	var $ExportOriginalValue = EW_EXPORT_ORIGINAL_VALUE;
	var $ExportAll = TRUE;
	var $SendEmail; // Send email
	var $TableCustomInnerHtml; // Custom inner HTML
	var $BasicSearchKeyword; // Basic search keyword
	var $BasicSearchType; // Basic search type
	var $CurrentFilter; // Current filter
	var $CurrentOrder; // Current order
	var $CurrentOrderType; // Current order type
	var $RowType; // Row type
	var $CssClass; // CSS class
	var $CssStyle; // CSS style
	var $RowAttrs = array(); // Row custom attributes
	var $TableFilter = "";
	var $CurrentAction; // Current action
	var $UpdateConflict; // Update conflict
	var $EventName; // Event name
	var $EventCancelled; // Event cancelled
	var $CancelMessage; // Cancel message

	//
	// Table class constructor
	//
	function cp_players() {
		global $Language;

		// id
		$this->id = new cField('p_players', 'p_players', 'x_id', 'id', '`id`', 20, -1, FALSE, '`id`', FALSE);
		$this->id->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['id'] =& $this->id;

		// tribe_id
		$this->tribe_id = new cField('p_players', 'p_players', 'x_tribe_id', 'tribe_id', '`tribe_id`', 16, -1, FALSE, '`tribe_id`', FALSE);
		$this->tribe_id->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['tribe_id'] =& $this->tribe_id;

		// alliance_id
		$this->alliance_id = new cField('p_players', 'p_players', 'x_alliance_id', 'alliance_id', '`alliance_id`', 20, -1, FALSE, '`alliance_id`', FALSE);
		$this->alliance_id->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['alliance_id'] =& $this->alliance_id;

		// alliance_name
		$this->alliance_name = new cField('p_players', 'p_players', 'x_alliance_name', 'alliance_name', '`alliance_name`', 200, -1, FALSE, '`alliance_name`', FALSE);
		$this->fields['alliance_name'] =& $this->alliance_name;

		// alliance_roles
		$this->alliance_roles = new cField('p_players', 'p_players', 'x_alliance_roles', 'alliance_roles', '`alliance_roles`', 201, -1, FALSE, '`alliance_roles`', FALSE);
		$this->fields['alliance_roles'] =& $this->alliance_roles;

		// invites_alliance_ids
		$this->invites_alliance_ids = new cField('p_players', 'p_players', 'x_invites_alliance_ids', 'invites_alliance_ids', '`invites_alliance_ids`', 201, -1, FALSE, '`invites_alliance_ids`', FALSE);
		$this->fields['invites_alliance_ids'] =& $this->invites_alliance_ids;

		// name
		$this->name = new cField('p_players', 'p_players', 'x_name', 'name', '`name`', 200, -1, FALSE, '`name`', FALSE);
		$this->fields['name'] =& $this->name;

		// pwd
		$this->pwd = new cField('p_players', 'p_players', 'x_pwd', 'pwd', '`pwd`', 200, -1, FALSE, '`pwd`', FALSE);
		$this->fields['pwd'] =& $this->pwd;

		// email
		$this->zemail = new cField('p_players', 'p_players', 'x_zemail', 'email', '`email`', 200, -1, FALSE, '`email`', FALSE);
		$this->fields['email'] =& $this->zemail;

		// is_active
		$this->is_active = new cField('p_players', 'p_players', 'x_is_active', 'is_active', '`is_active`', 16, -1, FALSE, '`is_active`', FALSE);
		$this->is_active->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['is_active'] =& $this->is_active;

		// is_blocked
		$this->is_blocked = new cField('p_players', 'p_players', 'x_is_blocked', 'is_blocked', '`is_blocked`', 16, -1, FALSE, '`is_blocked`', FALSE);
		$this->is_blocked->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['is_blocked'] =& $this->is_blocked;

		// player_type
		$this->player_type = new cField('p_players', 'p_players', 'x_player_type', 'player_type', '`player_type`', 16, -1, FALSE, '`player_type`', FALSE);
		$this->player_type->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['player_type'] =& $this->player_type;

		// active_plus_account
		$this->active_plus_account = new cField('p_players', 'p_players', 'x_active_plus_account', 'active_plus_account', '`active_plus_account`', 16, -1, FALSE, '`active_plus_account`', FALSE);
		$this->active_plus_account->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['active_plus_account'] =& $this->active_plus_account;

		// activation_code
		$this->activation_code = new cField('p_players', 'p_players', 'x_activation_code', 'activation_code', '`activation_code`', 200, -1, FALSE, '`activation_code`', FALSE);
		$this->fields['activation_code'] =& $this->activation_code;

		// last_login_date
		$this->last_login_date = new cField('p_players', 'p_players', 'x_last_login_date', 'last_login_date', '`last_login_date`', 135, 5, FALSE, '`last_login_date`', FALSE);
		$this->last_login_date->FldDefaultErrMsg = str_replace("%s", "/", $Language->Phrase("IncorrectDateYMD"));
		$this->fields['last_login_date'] =& $this->last_login_date;

		// last_ip
		$this->last_ip = new cField('p_players', 'p_players', 'x_last_ip', 'last_ip', '`last_ip`', 200, -1, FALSE, '`last_ip`', FALSE);
		$this->fields['last_ip'] =& $this->last_ip;

		// birth_date
		$this->birth_date = new cField('p_players', 'p_players', 'x_birth_date', 'birth_date', '`birth_date`', 133, 5, FALSE, '`birth_date`', FALSE);
		$this->birth_date->FldDefaultErrMsg = str_replace("%s", "/", $Language->Phrase("IncorrectDateYMD"));
		$this->fields['birth_date'] =& $this->birth_date;

		// gender
		$this->gender = new cField('p_players', 'p_players', 'x_gender', 'gender', '`gender`', 16, -1, FALSE, '`gender`', FALSE);
		$this->gender->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['gender'] =& $this->gender;

		// description1
		$this->description1 = new cField('p_players', 'p_players', 'x_description1', 'description1', '`description1`', 201, -1, FALSE, '`description1`', FALSE);
		$this->fields['description1'] =& $this->description1;

		// description2
		$this->description2 = new cField('p_players', 'p_players', 'x_description2', 'description2', '`description2`', 201, -1, FALSE, '`description2`', FALSE);
		$this->fields['description2'] =& $this->description2;

		// house_name
		$this->house_name = new cField('p_players', 'p_players', 'x_house_name', 'house_name', '`house_name`', 200, -1, FALSE, '`house_name`', FALSE);
		$this->fields['house_name'] =& $this->house_name;

		// registration_date
		$this->registration_date = new cField('p_players', 'p_players', 'x_registration_date', 'registration_date', '`registration_date`', 135, 5, FALSE, '`registration_date`', FALSE);
		$this->registration_date->FldDefaultErrMsg = str_replace("%s", "/", $Language->Phrase("IncorrectDateYMD"));
		$this->fields['registration_date'] =& $this->registration_date;

		// gold_num
		$this->gold_num = new cField('p_players', 'p_players', 'x_gold_num', 'gold_num', '`gold_num`', 3, -1, FALSE, '`gold_num`', FALSE);
		$this->gold_num->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['gold_num'] =& $this->gold_num;

		// agent_for_players
		$this->agent_for_players = new cField('p_players', 'p_players', 'x_agent_for_players', 'agent_for_players', '`agent_for_players`', 200, -1, FALSE, '`agent_for_players`', FALSE);
		$this->fields['agent_for_players'] =& $this->agent_for_players;

		// my_agent_players
		$this->my_agent_players = new cField('p_players', 'p_players', 'x_my_agent_players', 'my_agent_players', '`my_agent_players`', 200, -1, FALSE, '`my_agent_players`', FALSE);
		$this->fields['my_agent_players'] =& $this->my_agent_players;

		// custom_links
		$this->custom_links = new cField('p_players', 'p_players', 'x_custom_links', 'custom_links', '`custom_links`', 201, -1, FALSE, '`custom_links`', FALSE);
		$this->fields['custom_links'] =& $this->custom_links;

		// medals
		$this->medals = new cField('p_players', 'p_players', 'x_medals', 'medals', '`medals`', 201, -1, FALSE, '`medals`', FALSE);
		$this->fields['medals'] =& $this->medals;

		// total_people_count
		$this->total_people_count = new cField('p_players', 'p_players', 'x_total_people_count', 'total_people_count', '`total_people_count`', 20, -1, FALSE, '`total_people_count`', FALSE);
		$this->total_people_count->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['total_people_count'] =& $this->total_people_count;

		// selected_village_id
		$this->selected_village_id = new cField('p_players', 'p_players', 'x_selected_village_id', 'selected_village_id', '`selected_village_id`', 20, -1, FALSE, '`selected_village_id`', FALSE);
		$this->selected_village_id->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['selected_village_id'] =& $this->selected_village_id;

		// villages_count
		$this->villages_count = new cField('p_players', 'p_players', 'x_villages_count', 'villages_count', '`villages_count`', 16, -1, FALSE, '`villages_count`', FALSE);
		$this->villages_count->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['villages_count'] =& $this->villages_count;

		// villages_id
		$this->villages_id = new cField('p_players', 'p_players', 'x_villages_id', 'villages_id', '`villages_id`', 201, -1, FALSE, '`villages_id`', FALSE);
		$this->fields['villages_id'] =& $this->villages_id;

		// villages_data
		$this->villages_data = new cField('p_players', 'p_players', 'x_villages_data', 'villages_data', '`villages_data`', 201, -1, FALSE, '`villages_data`', FALSE);
		$this->fields['villages_data'] =& $this->villages_data;

		// friend_players
		$this->friend_players = new cField('p_players', 'p_players', 'x_friend_players', 'friend_players', '`friend_players`', 201, -1, FALSE, '`friend_players`', FALSE);
		$this->fields['friend_players'] =& $this->friend_players;

		// notes
		$this->notes = new cField('p_players', 'p_players', 'x_notes', 'notes', '`notes`', 201, -1, FALSE, '`notes`', FALSE);
		$this->fields['notes'] =& $this->notes;

		// hero_troop_id
		$this->hero_troop_id = new cField('p_players', 'p_players', 'x_hero_troop_id', 'hero_troop_id', '`hero_troop_id`', 16, -1, FALSE, '`hero_troop_id`', FALSE);
		$this->hero_troop_id->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['hero_troop_id'] =& $this->hero_troop_id;

		// hero_level
		$this->hero_level = new cField('p_players', 'p_players', 'x_hero_level', 'hero_level', '`hero_level`', 16, -1, FALSE, '`hero_level`', FALSE);
		$this->hero_level->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['hero_level'] =& $this->hero_level;

		// hero_points
		$this->hero_points = new cField('p_players', 'p_players', 'x_hero_points', 'hero_points', '`hero_points`', 20, -1, FALSE, '`hero_points`', FALSE);
		$this->hero_points->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['hero_points'] =& $this->hero_points;

		// hero_name
		$this->hero_name = new cField('p_players', 'p_players', 'x_hero_name', 'hero_name', '`hero_name`', 201, -1, FALSE, '`hero_name`', FALSE);
		$this->fields['hero_name'] =& $this->hero_name;

		// hero_in_village_id
		$this->hero_in_village_id = new cField('p_players', 'p_players', 'x_hero_in_village_id', 'hero_in_village_id', '`hero_in_village_id`', 20, -1, FALSE, '`hero_in_village_id`', FALSE);
		$this->hero_in_village_id->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['hero_in_village_id'] =& $this->hero_in_village_id;

		// attack_points
		$this->attack_points = new cField('p_players', 'p_players', 'x_attack_points', 'attack_points', '`attack_points`', 20, -1, FALSE, '`attack_points`', FALSE);
		$this->attack_points->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['attack_points'] =& $this->attack_points;

		// defense_points
		$this->defense_points = new cField('p_players', 'p_players', 'x_defense_points', 'defense_points', '`defense_points`', 20, -1, FALSE, '`defense_points`', FALSE);
		$this->defense_points->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['defense_points'] =& $this->defense_points;

		// week_attack_points
		$this->week_attack_points = new cField('p_players', 'p_players', 'x_week_attack_points', 'week_attack_points', '`week_attack_points`', 20, -1, FALSE, '`week_attack_points`', FALSE);
		$this->week_attack_points->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['week_attack_points'] =& $this->week_attack_points;

		// week_defense_points
		$this->week_defense_points = new cField('p_players', 'p_players', 'x_week_defense_points', 'week_defense_points', '`week_defense_points`', 20, -1, FALSE, '`week_defense_points`', FALSE);
		$this->week_defense_points->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['week_defense_points'] =& $this->week_defense_points;

		// week_dev_points
		$this->week_dev_points = new cField('p_players', 'p_players', 'x_week_dev_points', 'week_dev_points', '`week_dev_points`', 20, -1, FALSE, '`week_dev_points`', FALSE);
		$this->week_dev_points->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['week_dev_points'] =& $this->week_dev_points;

		// week_thief_points
		$this->week_thief_points = new cField('p_players', 'p_players', 'x_week_thief_points', 'week_thief_points', '`week_thief_points`', 20, -1, FALSE, '`week_thief_points`', FALSE);
		$this->week_thief_points->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['week_thief_points'] =& $this->week_thief_points;

		// new_report_count
		$this->new_report_count = new cField('p_players', 'p_players', 'x_new_report_count', 'new_report_count', '`new_report_count`', 2, -1, FALSE, '`new_report_count`', FALSE);
		$this->new_report_count->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['new_report_count'] =& $this->new_report_count;

		// new_mail_count
		$this->new_mail_count = new cField('p_players', 'p_players', 'x_new_mail_count', 'new_mail_count', '`new_mail_count`', 2, -1, FALSE, '`new_mail_count`', FALSE);
		$this->new_mail_count->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['new_mail_count'] =& $this->new_mail_count;

		// guide_quiz
		$this->guide_quiz = new cField('p_players', 'p_players', 'x_guide_quiz', 'guide_quiz', '`guide_quiz`', 200, -1, FALSE, '`guide_quiz`', FALSE);
		$this->fields['guide_quiz'] =& $this->guide_quiz;
	}

	// Table caption
	function TableCaption() {
		global $Language;
		return $Language->TablePhrase($this->TableVar, "TblCaption");
	}

	// Page caption
	function PageCaption($Page) {
		global $Language;
		$Caption = $Language->TablePhrase($this->TableVar, "TblPageCaption" . $Page);
		if ($Caption == "") $Caption = "Page " . $Page;
		return $Caption;
	}

	// Export return page
	function ExportReturnUrl() {
		$url = @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_EXPORT_RETURN_URL];
		return ($url <> "") ? $url : ew_CurrentPage();
	}

	function setExportReturnUrl($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_EXPORT_RETURN_URL] = $v;
	}

	// Records per page
	function getRecordsPerPage() {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_REC_PER_PAGE];
	}

	function setRecordsPerPage($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_REC_PER_PAGE] = $v;
	}

	// Start record number
	function getStartRecordNumber() {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_START_REC];
	}

	function setStartRecordNumber($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_START_REC] = $v;
	}

	// Search highlight name
	function HighlightName() {
		return "p_players_Highlight";
	}

	// Advanced search
	function getAdvancedSearch($fld) {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_ADVANCED_SEARCH . "_" . $fld];
	}

	function setAdvancedSearch($fld, $v) {
		if (@$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_ADVANCED_SEARCH . "_" . $fld] <> $v) {
			$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_ADVANCED_SEARCH . "_" . $fld] = $v;
		}
	}

	// Basic search keyword
	function getSessionBasicSearchKeyword() {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_BASIC_SEARCH];
	}

	function setSessionBasicSearchKeyword($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_BASIC_SEARCH] = $v;
	}

	// Basic search type
	function getSessionBasicSearchType() {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_BASIC_SEARCH_TYPE];
	}

	function setSessionBasicSearchType($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_BASIC_SEARCH_TYPE] = $v;
	}

	// Search WHERE clause
	function getSearchWhere() {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_SEARCH_WHERE];
	}

	function setSearchWhere($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_SEARCH_WHERE] = $v;
	}

	// Single column sort
	function UpdateSort(&$ofld) {
		if ($this->CurrentOrder == $ofld->FldName) {
			$sSortField = $ofld->FldExpression;
			$sLastSort = $ofld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$sThisSort = $this->CurrentOrderType;
			} else {
				$sThisSort = ($sLastSort == "ASC") ? "DESC" : "ASC";
			}
			$ofld->setSort($sThisSort);
			$this->setSessionOrderBy($sSortField . " " . $sThisSort); // Save to Session
		} else {
			$ofld->setSort("");
		}
	}

	// Session WHERE clause
	function getSessionWhere() {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_WHERE];
	}

	function setSessionWhere($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_WHERE] = $v;
	}

	// Session ORDER BY
	function getSessionOrderBy() {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_ORDER_BY];
	}

	function setSessionOrderBy($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_ORDER_BY] = $v;
	}

	// Session key
	function getKey($fld) {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_KEY . "_" . $fld];
	}

	function setKey($fld, $v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_KEY . "_" . $fld] = $v;
	}

	// Table level SQL
	function SqlFrom() { // From
		return "`p_players`";
	}

	function SqlSelect() { // Select
		return "SELECT * FROM " . $this->SqlFrom();
	}

	function SqlWhere() { // Where
		$sWhere = "";
		$this->TableFilter = "";
		if ($this->TableFilter <> "") {
			if ($sWhere <> "") $sWhere .= "(" . $sWhere . ") AND (";
			$sWhere .= "(" . $this->TableFilter . ")";
		}
		return $sWhere;
	}

	function SqlGroupBy() { // Group By
		return "";
	}

	function SqlHaving() { // Having
		return "";
	}

	function SqlOrderBy() { // Order By
		return "";
	}

	// Check if Anonymous User is allowed
	function AllowAnonymousUser() {
		switch (EW_PAGE_ID) {
			case "add":
			case "register":
			case "addopt":
				return FALSE;
			case "edit":
			case "update":
				return FALSE;
			case "delete":
				return FALSE;
			case "view":
				return FALSE;
			case "search":
				return FALSE;
			default:
				return FALSE;
		}
	}

	// Apply User ID filters
	function ApplyUserIDFilters($sFilter) {
		return $sFilter;
	}

	// Get SQL
	function GetSQL($where, $orderby) {
		return ew_BuildSelectSql($this->SqlSelect(), $this->SqlWhere(),
			$this->SqlGroupBy(), $this->SqlHaving(), $this->SqlOrderBy(),
			$where, $orderby);
	}

	// Table SQL
	function SQL() {
		$sFilter = $this->CurrentFilter;
		$sFilter = $this->ApplyUserIDFilters($sFilter);
		$sSort = $this->getSessionOrderBy();
		return ew_BuildSelectSql($this->SqlSelect(), $this->SqlWhere(),
			$this->SqlGroupBy(), $this->SqlHaving(), $this->SqlOrderBy(),
			$sFilter, $sSort);
	}

	// Table SQL with List page filter
	function SelectSQL() {
		$sFilter = $this->getSessionWhere();
		if ($this->CurrentFilter <> "") {
			if ($sFilter <> "") $sFilter = "(" . $sFilter . ") AND ";
			$sFilter .= "(" . $this->CurrentFilter . ")";
		}
		$sFilter = $this->ApplyUserIDFilters($sFilter);
		$sSort = $this->getSessionOrderBy();
		return ew_BuildSelectSql($this->SqlSelect(), $this->SqlWhere(), $this->SqlGroupBy(),
			$this->SqlHaving(), $this->SqlOrderBy(), $sFilter, $sSort);
	}

	// Try to get record count
	function TryGetRecordCount($sSql) {
		global $conn;
		$cnt = -1;
		if ($this->TableType == 'TABLE' || $this->TableType == 'VIEW') {
			$sSql = "SELECT COUNT(*) FROM" . substr($sSql, 13);
		} else {
			$sSql = "SELECT COUNT(*) FROM (" . $sSql . ") EW_COUNT_TABLE";
		}
		if ($rs = $conn->Execute($sSql)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->Close();
			}
		}
		return intval($cnt);
	}

	// Get record count based on filter (for detail record count in master table pages)
	function LoadRecordCount($sFilter) {
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $sFilter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$sSql = $this->SQL();
		$cnt = $this->TryGetRecordCount($sSql);
		if ($cnt == -1) {
			if ($rs = $this->LoadRs($this->CurrentFilter)) {
				$cnt = $rs->RecordCount();
				$rs->Close();
			}
		}
		$this->CurrentFilter = $origFilter;
		return intval($cnt);
	}

	// Get record count (for current List page)
	function SelectRecordCount() {
		global $conn;
		$origFilter = $this->CurrentFilter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$sSql = $this->SelectSQL();
		$cnt = $this->TryGetRecordCount($sSql);
		if ($cnt == -1) {
			if ($rs = $conn->Execute($this->SelectSQL())) {
				$cnt = $rs->RecordCount();
				$rs->Close();
			}
		}
		$this->CurrentFilter = $origFilter;
		return intval($cnt);
	}

	// INSERT statement
	function InsertSQL(&$rs) {
		global $conn;
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			$names .= $this->fields[$name]->FldExpression . ",";
			$values .= ew_QuotedValue($value, $this->fields[$name]->FldDataType) . ",";
		}
		if (substr($names, -1) == ",") $names = substr($names, 0, strlen($names)-1);
		if (substr($values, -1) == ",") $values = substr($values, 0, strlen($values)-1);
		return "INSERT INTO `p_players` ($names) VALUES ($values)";
	}

	// UPDATE statement
	function UpdateSQL(&$rs) {
		global $conn;
		$SQL = "UPDATE `p_players` SET ";
		foreach ($rs as $name => $value) {
			$SQL .= $this->fields[$name]->FldExpression . "=";
			$SQL .= ew_QuotedValue($value, $this->fields[$name]->FldDataType) . ",";
		}
		if (substr($SQL, -1) == ",") $SQL = substr($SQL, 0, strlen($SQL)-1);
		if ($this->CurrentFilter <> "")	$SQL .= " WHERE " . $this->CurrentFilter;
		return $SQL;
	}

	// DELETE statement
	function DeleteSQL(&$rs) {
		$SQL = "DELETE FROM `p_players` WHERE ";
		$SQL .= ew_QuotedName('id') . '=' . ew_QuotedValue($rs['id'], $this->id->FldDataType) . ' AND ';
		if (substr($SQL, -5) == " AND ") $SQL = substr($SQL, 0, strlen($SQL)-5);
		if ($this->CurrentFilter <> "")	$SQL .= " AND " . $this->CurrentFilter;
		return $SQL;
	}

	// Key filter WHERE clause
	function SqlKeyFilter() {
		return "`id` = @id@";
	}

	// Key filter
	function KeyFilter() {
		$sKeyFilter = $this->SqlKeyFilter();
		if (!is_numeric($this->id->CurrentValue))
			$sKeyFilter = "0=1"; // Invalid key
		$sKeyFilter = str_replace("@id@", ew_AdjustSql($this->id->CurrentValue), $sKeyFilter); // Replace key value
		return $sKeyFilter;
	}

	// Return page URL
	function getReturnUrl() {
		$name = EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_RETURN_URL;

		// Get referer URL automatically
		if (ew_ServerVar("HTTP_REFERER") <> "" && ew_ReferPage() <> ew_CurrentPage() && ew_ReferPage() <> "login.php") // Referer not same page or login page
			$_SESSION[$name] = ew_ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] <> "") {
			return $_SESSION[$name];
		} else {
			return "p_playerslist.php";
		}
	}

	function setReturnUrl($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_RETURN_URL] = $v;
	}

	// List URL
	function ListUrl() {
		return "p_playerslist.php";
	}

	// View URL
	function ViewUrl() {
		return $this->KeyUrl("p_playersview.php", $this->UrlParm());
	}

	// Add URL
	function AddUrl() {
		$AddUrl = "p_playersadd.php";
		$sUrlParm = $this->UrlParm();
		if ($sUrlParm <> "")
			$AddUrl .= "?" . $sUrlParm;
		return $AddUrl;
	}

	// Edit URL
	function EditUrl() {
		return $this->KeyUrl("p_playersedit.php", $this->UrlParm());
	}

	// Inline edit URL
	function InlineEditUrl() {
		return $this->KeyUrl(ew_CurrentPage(), $this->UrlParm("a=edit"));
	}

	// Copy URL
	function CopyUrl() {
		return $this->KeyUrl("p_playersadd.php", $this->UrlParm());
	}

	// Inline copy URL
	function InlineCopyUrl() {
		return $this->KeyUrl(ew_CurrentPage(), $this->UrlParm("a=copy"));
	}

	// Delete URL
	function DeleteUrl() {
		return $this->KeyUrl("p_playersdelete.php", $this->UrlParm());
	}

	// Add key value to URL
	function KeyUrl($url, $parm = "") {
		$sUrl = $url . "?";
		if ($parm <> "") $sUrl .= $parm . "&";
		if (!is_null($this->id->CurrentValue)) {
			$sUrl .= "id=" . urlencode($this->id->CurrentValue);
		} else {
			return "javascript:alert(ewLanguage.Phrase(\"InvalidRecord\"));";
		}
		return $sUrl;
	}

	// Sort URL
	function SortUrl(&$fld) {
		if ($this->CurrentAction <> "" || $this->Export <> "" ||
			in_array($fld->FldType, array(128, 204, 205))) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$sUrlParm = $this->UrlParm("order=" . urlencode($fld->FldName) . "&ordertype=" . $fld->ReverseSort());
			return ew_CurrentPage() . "?" . $sUrlParm;
		} else {
			return "";
		}
	}

	// Add URL parameter
	function UrlParm($parm = "") {
		$UrlParm = ($this->UseTokenInUrl) ? "t=p_players" : "";
		if ($parm <> "") {
			if ($UrlParm <> "")
				$UrlParm .= "&";
			$UrlParm .= $parm;
		}
		return $UrlParm;
	}

	// Load rows based on filter
	function &LoadRs($sFilter) {
		global $conn;

		// Set up filter (SQL WHERE clause) and get return SQL
		$this->CurrentFilter = $sFilter;
		$sSql = $this->SQL();
		return $conn->Execute($sSql);
	}

	// Load row values from recordset
	function LoadListRowValues(&$rs) {
		$this->id->setDbValue($rs->fields('id'));
		$this->tribe_id->setDbValue($rs->fields('tribe_id'));
		$this->alliance_id->setDbValue($rs->fields('alliance_id'));
		$this->alliance_name->setDbValue($rs->fields('alliance_name'));
		$this->alliance_roles->setDbValue($rs->fields('alliance_roles'));
		$this->invites_alliance_ids->setDbValue($rs->fields('invites_alliance_ids'));
		$this->name->setDbValue($rs->fields('name'));
		$this->pwd->setDbValue($rs->fields('pwd'));
		$this->zemail->setDbValue($rs->fields('email'));
		$this->is_active->setDbValue($rs->fields('is_active'));
		$this->is_blocked->setDbValue($rs->fields('is_blocked'));
		$this->player_type->setDbValue($rs->fields('player_type'));
		$this->active_plus_account->setDbValue($rs->fields('active_plus_account'));
		$this->activation_code->setDbValue($rs->fields('activation_code'));
		$this->last_login_date->setDbValue($rs->fields('last_login_date'));
		$this->last_ip->setDbValue($rs->fields('last_ip'));
		$this->birth_date->setDbValue($rs->fields('birth_date'));
		$this->gender->setDbValue($rs->fields('gender'));
		$this->description1->setDbValue($rs->fields('description1'));
		$this->description2->setDbValue($rs->fields('description2'));
		$this->house_name->setDbValue($rs->fields('house_name'));
		$this->registration_date->setDbValue($rs->fields('registration_date'));
		$this->gold_num->setDbValue($rs->fields('gold_num'));
		$this->agent_for_players->setDbValue($rs->fields('agent_for_players'));
		$this->my_agent_players->setDbValue($rs->fields('my_agent_players'));
		$this->custom_links->setDbValue($rs->fields('custom_links'));
		$this->medals->setDbValue($rs->fields('medals'));
		$this->total_people_count->setDbValue($rs->fields('total_people_count'));
		$this->selected_village_id->setDbValue($rs->fields('selected_village_id'));
		$this->villages_count->setDbValue($rs->fields('villages_count'));
		$this->villages_id->setDbValue($rs->fields('villages_id'));
		$this->villages_data->setDbValue($rs->fields('villages_data'));
		$this->friend_players->setDbValue($rs->fields('friend_players'));
		$this->notes->setDbValue($rs->fields('notes'));
		$this->hero_troop_id->setDbValue($rs->fields('hero_troop_id'));
		$this->hero_level->setDbValue($rs->fields('hero_level'));
		$this->hero_points->setDbValue($rs->fields('hero_points'));
		$this->hero_name->setDbValue($rs->fields('hero_name'));
		$this->hero_in_village_id->setDbValue($rs->fields('hero_in_village_id'));
		$this->attack_points->setDbValue($rs->fields('attack_points'));
		$this->defense_points->setDbValue($rs->fields('defense_points'));
		$this->week_attack_points->setDbValue($rs->fields('week_attack_points'));
		$this->week_defense_points->setDbValue($rs->fields('week_defense_points'));
		$this->week_dev_points->setDbValue($rs->fields('week_dev_points'));
		$this->week_thief_points->setDbValue($rs->fields('week_thief_points'));
		$this->new_report_count->setDbValue($rs->fields('new_report_count'));
		$this->new_mail_count->setDbValue($rs->fields('new_mail_count'));
		$this->guide_quiz->setDbValue($rs->fields('guide_quiz'));
	}

	// Render list row values
	function RenderListRow() {
		global $conn, $Security;

		// Call Row Rendering event
		$this->Row_Rendering();

   // Common render codes
		// id

		$this->id->CellCssStyle = ""; $this->id->CellCssClass = "";
		$this->id->CellAttrs = array(); $this->id->ViewAttrs = array(); $this->id->EditAttrs = array();

		// name
		$this->name->CellCssStyle = ""; $this->name->CellCssClass = "";
		$this->name->CellAttrs = array(); $this->name->ViewAttrs = array(); $this->name->EditAttrs = array();

		// email
		$this->zemail->CellCssStyle = ""; $this->zemail->CellCssClass = "";
		$this->zemail->CellAttrs = array(); $this->zemail->ViewAttrs = array(); $this->zemail->EditAttrs = array();

		// is_active
		$this->is_active->CellCssStyle = ""; $this->is_active->CellCssClass = "";
		$this->is_active->CellAttrs = array(); $this->is_active->ViewAttrs = array(); $this->is_active->EditAttrs = array();

		// active_plus_account
		$this->active_plus_account->CellCssStyle = ""; $this->active_plus_account->CellCssClass = "";
		$this->active_plus_account->CellAttrs = array(); $this->active_plus_account->ViewAttrs = array(); $this->active_plus_account->EditAttrs = array();

		// last_ip
		$this->last_ip->CellCssStyle = ""; $this->last_ip->CellCssClass = "";
		$this->last_ip->CellAttrs = array(); $this->last_ip->ViewAttrs = array(); $this->last_ip->EditAttrs = array();

		// gold_num
		$this->gold_num->CellCssStyle = ""; $this->gold_num->CellCssClass = "";
		$this->gold_num->CellAttrs = array(); $this->gold_num->ViewAttrs = array(); $this->gold_num->EditAttrs = array();

		// total_people_count
		$this->total_people_count->CellCssStyle = ""; $this->total_people_count->CellCssClass = "";
		$this->total_people_count->CellAttrs = array(); $this->total_people_count->ViewAttrs = array(); $this->total_people_count->EditAttrs = array();

		// id
		$this->id->ViewValue = $this->id->CurrentValue;
		$this->id->CssStyle = "";
		$this->id->CssClass = "";
		$this->id->ViewCustomAttributes = "";

		// name
		$this->name->ViewValue = $this->name->CurrentValue;
		$this->name->CssStyle = "";
		$this->name->CssClass = "";
		$this->name->ViewCustomAttributes = "";

		// email
		$this->zemail->ViewValue = $this->zemail->CurrentValue;
		$this->zemail->CssStyle = "";
		$this->zemail->CssClass = "";
		$this->zemail->ViewCustomAttributes = "";

		// is_active
		$this->is_active->ViewValue = $this->is_active->CurrentValue;
		$this->is_active->CssStyle = "";
		$this->is_active->CssClass = "";
		$this->is_active->ViewCustomAttributes = "";

		// active_plus_account
		$this->active_plus_account->ViewValue = $this->active_plus_account->CurrentValue;
		$this->active_plus_account->CssStyle = "";
		$this->active_plus_account->CssClass = "";
		$this->active_plus_account->ViewCustomAttributes = "";

		// last_ip
		$this->last_ip->ViewValue = $this->last_ip->CurrentValue;
		$this->last_ip->CssStyle = "";
		$this->last_ip->CssClass = "";
		$this->last_ip->ViewCustomAttributes = "";

		// gold_num
		$this->gold_num->ViewValue = $this->gold_num->CurrentValue;
		$this->gold_num->CssStyle = "";
		$this->gold_num->CssClass = "";
		$this->gold_num->ViewCustomAttributes = "";

		// total_people_count
		$this->total_people_count->ViewValue = $this->total_people_count->CurrentValue;
		$this->total_people_count->CssStyle = "";
		$this->total_people_count->CssClass = "";
		$this->total_people_count->ViewCustomAttributes = "";

		// id
		$this->id->HrefValue = "";
		$this->id->TooltipValue = "";

		// name
		$this->name->HrefValue = "";
		$this->name->TooltipValue = "";

		// email
		$this->zemail->HrefValue = "";
		$this->zemail->TooltipValue = "";

		// is_active
		$this->is_active->HrefValue = "";
		$this->is_active->TooltipValue = "";

		// active_plus_account
		$this->active_plus_account->HrefValue = "";
		$this->active_plus_account->TooltipValue = "";

		// last_ip
		$this->last_ip->HrefValue = "";
		$this->last_ip->TooltipValue = "";

		// gold_num
		$this->gold_num->HrefValue = "";
		$this->gold_num->TooltipValue = "";

		// total_people_count
		$this->total_people_count->HrefValue = "";
		$this->total_people_count->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	function AggregateListRowValues() {
	}

	// Aggregate list row (for rendering)
	function AggregateListRow() {
	}

	// Row styles
	function RowStyles() {
		$sAtt = "";
		$sStyle = trim($this->CssStyle);
		if (@$this->RowAttrs["style"] <> "")
			$sStyle .= " " . $this->RowAttrs["style"];
		$sClass = trim($this->CssClass);
		if (@$this->RowAttrs["class"] <> "")
			$sClass .= " " . $this->RowAttrs["class"];
		if (trim($sStyle) <> "")
			$sAtt .= " style=\"" . trim($sStyle) . "\"";
		if (trim($sClass) <> "")
			$sAtt .= " class=\"" . trim($sClass) . "\"";
		return $sAtt;
	}

	// Row attributes
	function RowAttributes() {
		$sAtt = $this->RowStyles();
		if ($this->Export == "") {
			foreach ($this->RowAttrs as $k => $v) {
				if ($k <> "class" && $k <> "style" && trim($v) <> "")
					$sAtt .= " " . $k . "=\"" . trim($v) . "\"";
			}
		}
		return $sAtt;
	}

	// Field object by name
	function fields($fldname) {
		return $this->fields[$fldname];
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here	
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//global $MyTable;
		//$MyTable->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here	
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here	
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here	
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>); 

	}

	// Row Inserting event
	function Row_Inserting(&$rs) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted(&$rs) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating(&$rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated(&$rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict(&$rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending(&$Email, &$Args) {

		//var_dump($Email); var_dump($Args); exit();
		return TRUE;
	}
}
?>
