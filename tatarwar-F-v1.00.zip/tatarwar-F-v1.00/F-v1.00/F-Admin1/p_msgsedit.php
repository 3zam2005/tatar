<?php
session_start(); // Initialize Session data
ob_start(); // Turn on output buffering
?>
<?php include "ewcfg7.php" ?>
<?php include "ewmysql7.php" ?>
<?php include "phpfn7.php" ?>
<?php include "p_msgsinfo.php" ?>
<?php include "userfn7.php" ?>
<?php

// Create page object
$p_msgs_edit = new cp_msgs_edit();
$Page =& $p_msgs_edit;

// Page init
$p_msgs_edit->Page_Init();

// Page main
$p_msgs_edit->Page_Main();
?>
<?php include "header.php" ?>
<script type="text/javascript">
<!--

// Create page object
var p_msgs_edit = new ew_Page("p_msgs_edit");

// page properties
p_msgs_edit.PageID = "edit"; // page ID
p_msgs_edit.FormID = "fp_msgsedit"; // form ID
var EW_PAGE_ID = p_msgs_edit.PageID; // for backward compatibility

// extend page with ValidateForm function
p_msgs_edit.ValidateForm = function(fobj) {
	ew_PostAutoSuggest(fobj);
	if (!this.ValidateRequired)
		return true; // ignore validation
	if (fobj.a_confirm && fobj.a_confirm.value == "F")
		return true;
	var i, elm, aelm, infix;
	var rowcnt = (fobj.key_count) ? Number(fobj.key_count.value) : 1;
	for (i=0; i<rowcnt; i++) {
		infix = (fobj.key_count) ? String(i+1) : "";

		// Call Form Custom Validate event
		if (!this.Form_CustomValidate(fobj)) return false;
	}
	return true;
}

// extend page with Form_CustomValidate function
p_msgs_edit.Form_CustomValidate =  
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }
<?php if (EW_CLIENT_VALIDATE) { ?>
p_msgs_edit.ValidateRequired = true; // uses JavaScript validation
<?php } else { ?>
p_msgs_edit.ValidateRequired = false; // no JavaScript validation
<?php } ?>

//-->
</script>
<script type="text/javascript">
<!--
var ew_DHTMLEditors = [];

//-->
</script>
<script language="JavaScript" type="text/javascript">
<!--

// Write your client script here, no need to add script tags.
// To include another .js script, use:
// ew_ClientScriptInclude("my_javascript.js"); 
//-->

</script>
<p><span class="phpmaker"><?php echo $Language->Phrase("Edit") ?>&nbsp;<?php echo $Language->Phrase("TblTypeTABLE") ?><?php echo $p_msgs->TableCaption() ?><br><br>
<a href="<?php echo $p_msgs->getReturnUrl() ?>"><?php echo $Language->Phrase("GoBack") ?></a></span></p>
<?php
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
$p_msgs_edit->ShowMessage();
?>
<form name="fp_msgsedit" id="fp_msgsedit" action="<?php echo ew_CurrentPage() ?>" method="post" onsubmit="return p_msgs_edit.ValidateForm(this);">
<p>
<input type="hidden" name="a_table" id="a_table" value="p_msgs">
<input type="hidden" name="a_edit" id="a_edit" value="U">
<table cellspacing="0" class="ewGrid"><tr><td class="ewGridContent">
<div class="ewGridMiddlePanel">
<table cellspacing="0" class="ewTable">
<?php if ($p_msgs->from_player_name->Visible) { // from_player_name ?>
	<tr<?php echo $p_msgs->from_player_name->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_msgs->from_player_name->FldCaption() ?></td>
		<td<?php echo $p_msgs->from_player_name->CellAttributes() ?>><span id="el_from_player_name">
<textarea name="x_from_player_name" id="x_from_player_name" title="<?php echo $p_msgs->from_player_name->FldTitle() ?>" cols="35" rows="4"<?php echo $p_msgs->from_player_name->EditAttributes() ?>><?php echo $p_msgs->from_player_name->EditValue ?></textarea>
</span><?php echo $p_msgs->from_player_name->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_msgs->to_player_name->Visible) { // to_player_name ?>
	<tr<?php echo $p_msgs->to_player_name->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_msgs->to_player_name->FldCaption() ?></td>
		<td<?php echo $p_msgs->to_player_name->CellAttributes() ?>><span id="el_to_player_name">
<textarea name="x_to_player_name" id="x_to_player_name" title="<?php echo $p_msgs->to_player_name->FldTitle() ?>" cols="35" rows="4"<?php echo $p_msgs->to_player_name->EditAttributes() ?>><?php echo $p_msgs->to_player_name->EditValue ?></textarea>
</span><?php echo $p_msgs->to_player_name->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_msgs->msg_title->Visible) { // msg_title ?>
	<tr<?php echo $p_msgs->msg_title->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_msgs->msg_title->FldCaption() ?></td>
		<td<?php echo $p_msgs->msg_title->CellAttributes() ?>><span id="el_msg_title">
<input type="text" name="x_msg_title" id="x_msg_title" title="<?php echo $p_msgs->msg_title->FldTitle() ?>" size="30" maxlength="255" value="<?php echo $p_msgs->msg_title->EditValue ?>"<?php echo $p_msgs->msg_title->EditAttributes() ?>>
</span><?php echo $p_msgs->msg_title->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_msgs->msg_body->Visible) { // msg_body ?>
	<tr<?php echo $p_msgs->msg_body->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_msgs->msg_body->FldCaption() ?></td>
		<td<?php echo $p_msgs->msg_body->CellAttributes() ?>><span id="el_msg_body">
<textarea name="x_msg_body" id="x_msg_body" title="<?php echo $p_msgs->msg_body->FldTitle() ?>" cols="35" rows="4"<?php echo $p_msgs->msg_body->EditAttributes() ?>><?php echo $p_msgs->msg_body->EditValue ?></textarea>
</span><?php echo $p_msgs->msg_body->CustomMsg ?></td>
	</tr>
<?php } ?>
</table>
</div>
</td></tr></table>
<input type="hidden" name="x_id" id="x_id" value="<?php echo ew_HtmlEncode($p_msgs->id->CurrentValue) ?>">
<p>
<input type="submit" name="btnAction" id="btnAction" value="<?php echo ew_BtnCaption($Language->Phrase("EditBtn")) ?>">
</form>
<script language="JavaScript" type="text/javascript">
<!--

// Write your table-specific startup script here
// document.write("page loaded");
//-->

</script>
<?php include "footer.php" ?>
<?php
$p_msgs_edit->Page_Terminate();
?>
<?php

//
// Page class
//
class cp_msgs_edit {

	// Page ID
	var $PageID = 'edit';

	// Table name
	var $TableName = 'p_msgs';

	// Page object name
	var $PageObjName = 'p_msgs_edit';

	// Page name
	function PageName() {
		return ew_CurrentPage();
	}

	// Page URL
	function PageUrl() {
		$PageUrl = ew_CurrentPage() . "?";
		global $p_msgs;
		if ($p_msgs->UseTokenInUrl) $PageUrl .= "t=" . $p_msgs->TableVar . "&"; // Add page token
		return $PageUrl;
	}

	// Page URLs
	var $AddUrl;
	var $EditUrl;
	var $CopyUrl;
	var $DeleteUrl;
	var $ViewUrl;
	var $ListUrl;

	// Export URLs
	var $ExportPrintUrl;
	var $ExportHtmlUrl;
	var $ExportExcelUrl;
	var $ExportWordUrl;
	var $ExportXmlUrl;
	var $ExportCsvUrl;

	// Update URLs
	var $InlineAddUrl;
	var $InlineCopyUrl;
	var $InlineEditUrl;
	var $GridAddUrl;
	var $GridEditUrl;
	var $MultiDeleteUrl;
	var $MultiUpdateUrl;

	// Message
	function getMessage() {
		return @$_SESSION[EW_SESSION_MESSAGE];
	}

	function setMessage($v) {
		if (@$_SESSION[EW_SESSION_MESSAGE] <> "") { // Append
			$_SESSION[EW_SESSION_MESSAGE] .= "<br>" . $v;
		} else {
			$_SESSION[EW_SESSION_MESSAGE] = $v;
		}
	}

	// Show message
	function ShowMessage() {
		$sMessage = $this->getMessage();
		$this->Message_Showing($sMessage);
		if ($sMessage <> "") { // Message in Session, display
			echo "<p><span class=\"ewMessage\">" . $sMessage . "</span></p>";
			$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message in Session
		}
	}

	// Validate page request
	function IsPageRequest() {
		global $objForm, $p_msgs;
		if ($p_msgs->UseTokenInUrl) {
			if ($objForm)
				return ($p_msgs->TableVar == $objForm->GetValue("t"));
			if (@$_GET["t"] <> "")
				return ($p_msgs->TableVar == $_GET["t"]);
		} else {
			return TRUE;
		}
	}

	//
	// Page class constructor
	//
	function cp_msgs_edit() {
		global $conn, $Language;

		// Language object
		$Language = new cLanguage();

		// Table object (p_msgs)
		$GLOBALS["p_msgs"] = new cp_msgs();

		// Page ID
		if (!defined("EW_PAGE_ID"))
			define("EW_PAGE_ID", 'edit', TRUE);

		// Table name (for backward compatibility)
		if (!defined("EW_TABLE_NAME"))
			define("EW_TABLE_NAME", 'p_msgs', TRUE);

		// Start timer
		$GLOBALS["gsTimer"] = new cTimer();

		// Open connection
		$conn = ew_Connect();
	}

	// 
	//  Page_Init
	//
	function Page_Init() {
		global $gsExport, $gsExportFile, $UserProfile, $Language, $Security, $objForm;
		global $p_msgs;

		// Security
		$Security = new cAdvancedSecurity();
		if (!$Security->IsLoggedIn()) $Security->AutoLogin();
		if (!$Security->IsLoggedIn()) {
			$Security->SaveLastUrl();
			$this->Page_Terminate("login.php");
		}

		// Create form object
		$objForm = new cFormObj();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();
	}

	//
	// Page_Terminate
	//
	function Page_Terminate($url = "") {
		global $conn;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		 // Close connection
		$conn->Close();

		// Go to URL if specified
		$this->Page_Redirecting($url);
		if ($url <> "") {
			if (!EW_DEBUG_ENABLED && ob_get_length())
				ob_end_clean();
			header("Location: " . $url);
		}
		exit();
	}
	var $sDbMasterFilter;
	var $sDbDetailFilter;

	// 
	// Page main
	//
	function Page_Main() {
		global $objForm, $Language, $gsFormError, $p_msgs;

		// Load key from QueryString
		if (@$_GET["id"] <> "")
			$p_msgs->id->setQueryStringValue($_GET["id"]);
		if (@$_POST["a_edit"] <> "") {
			$p_msgs->CurrentAction = $_POST["a_edit"]; // Get action code
			$this->LoadFormValues(); // Get form values

			// Validate form
			if (!$this->ValidateForm()) {
				$p_msgs->CurrentAction = ""; // Form error, reset action
				$this->setMessage($gsFormError);
				$p_msgs->EventCancelled = TRUE; // Event cancelled
				$this->RestoreFormValues();
			}
		} else {
			$p_msgs->CurrentAction = "I"; // Default action is display
		}

		// Check if valid key
		if ($p_msgs->id->CurrentValue == "")
			$this->Page_Terminate("p_msgslist.php"); // Invalid key, return to list
		switch ($p_msgs->CurrentAction) {
			case "I": // Get a record to display
				if (!$this->LoadRow()) { // Load record based on key
					$this->setMessage($Language->Phrase("NoRecord")); // No record found
					$this->Page_Terminate("p_msgslist.php"); // No matching record, return to list
				}
				break;
			Case "U": // Update
				$p_msgs->SendEmail = TRUE; // Send email on update success
				if ($this->EditRow()) { // Update record based on key
					$this->setMessage($Language->Phrase("UpdateSuccess")); // Update success
					$sReturnUrl = $p_msgs->getReturnUrl();
					$this->Page_Terminate($sReturnUrl); // Return to caller
				} else {
					$p_msgs->EventCancelled = TRUE; // Event cancelled
					$this->RestoreFormValues(); // Restore form values if update failed
				}
		}

		// Render the record
		$p_msgs->RowType = EW_ROWTYPE_EDIT; // Render as Edit
		$this->RenderRow();
	}

	// Get upload files
	function GetUploadFiles() {
		global $objForm, $p_msgs;

		// Get upload data
	}

	// Load form values
	function LoadFormValues() {

		// Load from form
		global $objForm, $p_msgs;
		$p_msgs->from_player_name->setFormValue($objForm->GetValue("x_from_player_name"));
		$p_msgs->to_player_name->setFormValue($objForm->GetValue("x_to_player_name"));
		$p_msgs->msg_title->setFormValue($objForm->GetValue("x_msg_title"));
		$p_msgs->msg_body->setFormValue($objForm->GetValue("x_msg_body"));
		$p_msgs->id->setFormValue($objForm->GetValue("x_id"));
	}

	// Restore form values
	function RestoreFormValues() {
		global $objForm, $p_msgs;
		$p_msgs->id->CurrentValue = $p_msgs->id->FormValue;
		$this->LoadRow();
		$p_msgs->from_player_name->CurrentValue = $p_msgs->from_player_name->FormValue;
		$p_msgs->to_player_name->CurrentValue = $p_msgs->to_player_name->FormValue;
		$p_msgs->msg_title->CurrentValue = $p_msgs->msg_title->FormValue;
		$p_msgs->msg_body->CurrentValue = $p_msgs->msg_body->FormValue;
	}

	// Load row based on key values
	function LoadRow() {
		global $conn, $Security, $p_msgs;
		$sFilter = $p_msgs->KeyFilter();

		// Call Row Selecting event
		$p_msgs->Row_Selecting($sFilter);

		// Load SQL based on filter
		$p_msgs->CurrentFilter = $sFilter;
		$sSql = $p_msgs->SQL();
		$res = FALSE;
		$rs = ew_LoadRecordset($sSql);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->LoadRowValues($rs); // Load row values

			// Call Row Selected event
			$p_msgs->Row_Selected($rs);
			$rs->Close();
		}
		return $res;
	}

	// Load row values from recordset
	function LoadRowValues(&$rs) {
		global $conn, $p_msgs;
		$p_msgs->id->setDbValue($rs->fields('id'));
		$p_msgs->from_player_id->setDbValue($rs->fields('from_player_id'));
		$p_msgs->to_player_id->setDbValue($rs->fields('to_player_id'));
		$p_msgs->from_player_name->setDbValue($rs->fields('from_player_name'));
		$p_msgs->to_player_name->setDbValue($rs->fields('to_player_name'));
		$p_msgs->msg_title->setDbValue($rs->fields('msg_title'));
		$p_msgs->msg_body->setDbValue($rs->fields('msg_body'));
		$p_msgs->creation_date->setDbValue($rs->fields('creation_date'));
		$p_msgs->is_readed->setDbValue($rs->fields('is_readed'));
		$p_msgs->delete_status->setDbValue($rs->fields('delete_status'));
	}

	// Render row values based on field settings
	function RenderRow() {
		global $conn, $Security, $Language, $p_msgs;

		// Initialize URLs
		// Call Row_Rendering event

		$p_msgs->Row_Rendering();

		// Common render codes for all row types
		// from_player_name

		$p_msgs->from_player_name->CellCssStyle = ""; $p_msgs->from_player_name->CellCssClass = "";
		$p_msgs->from_player_name->CellAttrs = array(); $p_msgs->from_player_name->ViewAttrs = array(); $p_msgs->from_player_name->EditAttrs = array();

		// to_player_name
		$p_msgs->to_player_name->CellCssStyle = ""; $p_msgs->to_player_name->CellCssClass = "";
		$p_msgs->to_player_name->CellAttrs = array(); $p_msgs->to_player_name->ViewAttrs = array(); $p_msgs->to_player_name->EditAttrs = array();

		// msg_title
		$p_msgs->msg_title->CellCssStyle = ""; $p_msgs->msg_title->CellCssClass = "";
		$p_msgs->msg_title->CellAttrs = array(); $p_msgs->msg_title->ViewAttrs = array(); $p_msgs->msg_title->EditAttrs = array();

		// msg_body
		$p_msgs->msg_body->CellCssStyle = ""; $p_msgs->msg_body->CellCssClass = "";
		$p_msgs->msg_body->CellAttrs = array(); $p_msgs->msg_body->ViewAttrs = array(); $p_msgs->msg_body->EditAttrs = array();
		if ($p_msgs->RowType == EW_ROWTYPE_VIEW) { // View row

			// id
			$p_msgs->id->ViewValue = $p_msgs->id->CurrentValue;
			$p_msgs->id->CssStyle = "";
			$p_msgs->id->CssClass = "";
			$p_msgs->id->ViewCustomAttributes = "";

			// from_player_id
			$p_msgs->from_player_id->ViewValue = $p_msgs->from_player_id->CurrentValue;
			$p_msgs->from_player_id->CssStyle = "";
			$p_msgs->from_player_id->CssClass = "";
			$p_msgs->from_player_id->ViewCustomAttributes = "";

			// to_player_id
			$p_msgs->to_player_id->ViewValue = $p_msgs->to_player_id->CurrentValue;
			$p_msgs->to_player_id->CssStyle = "";
			$p_msgs->to_player_id->CssClass = "";
			$p_msgs->to_player_id->ViewCustomAttributes = "";

			// from_player_name
			$p_msgs->from_player_name->ViewValue = $p_msgs->from_player_name->CurrentValue;
			$p_msgs->from_player_name->CssStyle = "";
			$p_msgs->from_player_name->CssClass = "";
			$p_msgs->from_player_name->ViewCustomAttributes = "";

			// to_player_name
			$p_msgs->to_player_name->ViewValue = $p_msgs->to_player_name->CurrentValue;
			$p_msgs->to_player_name->CssStyle = "";
			$p_msgs->to_player_name->CssClass = "";
			$p_msgs->to_player_name->ViewCustomAttributes = "";

			// msg_title
			$p_msgs->msg_title->ViewValue = $p_msgs->msg_title->CurrentValue;
			$p_msgs->msg_title->CssStyle = "";
			$p_msgs->msg_title->CssClass = "";
			$p_msgs->msg_title->ViewCustomAttributes = "";

			// msg_body
			$p_msgs->msg_body->ViewValue = $p_msgs->msg_body->CurrentValue;
			$p_msgs->msg_body->CssStyle = "";
			$p_msgs->msg_body->CssClass = "";
			$p_msgs->msg_body->ViewCustomAttributes = "";

			// from_player_name
			$p_msgs->from_player_name->HrefValue = "";
			$p_msgs->from_player_name->TooltipValue = "";

			// to_player_name
			$p_msgs->to_player_name->HrefValue = "";
			$p_msgs->to_player_name->TooltipValue = "";

			// msg_title
			$p_msgs->msg_title->HrefValue = "";
			$p_msgs->msg_title->TooltipValue = "";

			// msg_body
			$p_msgs->msg_body->HrefValue = "";
			$p_msgs->msg_body->TooltipValue = "";
		} elseif ($p_msgs->RowType == EW_ROWTYPE_EDIT) { // Edit row

			// from_player_name
			$p_msgs->from_player_name->EditCustomAttributes = "";
			$p_msgs->from_player_name->EditValue = ew_HtmlEncode($p_msgs->from_player_name->CurrentValue);

			// to_player_name
			$p_msgs->to_player_name->EditCustomAttributes = "";
			$p_msgs->to_player_name->EditValue = ew_HtmlEncode($p_msgs->to_player_name->CurrentValue);

			// msg_title
			$p_msgs->msg_title->EditCustomAttributes = "";
			$p_msgs->msg_title->EditValue = ew_HtmlEncode($p_msgs->msg_title->CurrentValue);

			// msg_body
			$p_msgs->msg_body->EditCustomAttributes = "";
			$p_msgs->msg_body->EditValue = ew_HtmlEncode($p_msgs->msg_body->CurrentValue);

			// Edit refer script
			// from_player_name

			$p_msgs->from_player_name->HrefValue = "";

			// to_player_name
			$p_msgs->to_player_name->HrefValue = "";

			// msg_title
			$p_msgs->msg_title->HrefValue = "";

			// msg_body
			$p_msgs->msg_body->HrefValue = "";
		}

		// Call Row Rendered event
		if ($p_msgs->RowType <> EW_ROWTYPE_AGGREGATEINIT)
			$p_msgs->Row_Rendered();
	}

	// Validate form
	function ValidateForm() {
		global $Language, $gsFormError, $p_msgs;

		// Initialize form error message
		$gsFormError = "";

		// Check if validation required
		if (!EW_SERVER_VALIDATE)
			return ($gsFormError == "");

		// Return validate result
		$ValidateForm = ($gsFormError == "");

		// Call Form_CustomValidate event
		$sFormCustomError = "";
		$ValidateForm = $ValidateForm && $this->Form_CustomValidate($sFormCustomError);
		if ($sFormCustomError <> "") {
			$gsFormError .= ($gsFormError <> "") ? "<br>" : "";
			$gsFormError .= $sFormCustomError;
		}
		return $ValidateForm;
	}

	// Update record based on key values
	function EditRow() {
		global $conn, $Security, $Language, $p_msgs;
		$sFilter = $p_msgs->KeyFilter();
		$p_msgs->CurrentFilter = $sFilter;
		$sSql = $p_msgs->SQL();
		$conn->raiseErrorFn = 'ew_ErrorFn';
		$rs = $conn->Execute($sSql);
		$conn->raiseErrorFn = '';
		if ($rs === FALSE)
			return FALSE;
		if ($rs->EOF) {
			$EditRow = FALSE; // Update Failed
		} else {

			// Save old values
			$rsold =& $rs->fields;
			$rsnew = array();

			// from_player_name
			$p_msgs->from_player_name->SetDbValueDef($rsnew, $p_msgs->from_player_name->CurrentValue, NULL, FALSE);

			// to_player_name
			$p_msgs->to_player_name->SetDbValueDef($rsnew, $p_msgs->to_player_name->CurrentValue, NULL, FALSE);

			// msg_title
			$p_msgs->msg_title->SetDbValueDef($rsnew, $p_msgs->msg_title->CurrentValue, NULL, FALSE);

			// msg_body
			$p_msgs->msg_body->SetDbValueDef($rsnew, $p_msgs->msg_body->CurrentValue, NULL, FALSE);

			// Call Row Updating event
			$bUpdateRow = $p_msgs->Row_Updating($rsold, $rsnew);
			if ($bUpdateRow) {
				$conn->raiseErrorFn = 'ew_ErrorFn';
				$EditRow = $conn->Execute($p_msgs->UpdateSQL($rsnew));
				$conn->raiseErrorFn = '';
			} else {
				if ($p_msgs->CancelMessage <> "") {
					$this->setMessage($p_msgs->CancelMessage);
					$p_msgs->CancelMessage = "";
				} else {
					$this->setMessage($Language->Phrase("UpdateCancelled"));
				}
				$EditRow = FALSE;
			}
		}

		// Call Row_Updated event
		if ($EditRow)
			$p_msgs->Row_Updated($rsold, $rsnew);
		$rs->Close();
		return $EditRow;
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	function Message_Showing(&$msg) {

		// Example:
		//$msg = "your new message";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$CustomError) {

		// Return error message in CustomError
		return TRUE;
	}
}
?>
