<?php
session_start(); // Initialize Session data
ob_start(); // Turn on output buffering
?>
<?php include "ewcfg7.php" ?>
<?php include "ewmysql7.php" ?>
<?php include "phpfn7.php" ?>
<?php include "p_villagesinfo.php" ?>
<?php include "userfn7.php" ?>
<?php

// Create page object
$p_villages_edit = new cp_villages_edit();
$Page =& $p_villages_edit;

// Page init
$p_villages_edit->Page_Init();

// Page main
$p_villages_edit->Page_Main();
?>
<?php include "header.php" ?>
<script type="text/javascript">
<!--

// Create page object
var p_villages_edit = new ew_Page("p_villages_edit");

// page properties
p_villages_edit.PageID = "edit"; // page ID
p_villages_edit.FormID = "fp_villagesedit"; // form ID
var EW_PAGE_ID = p_villages_edit.PageID; // for backward compatibility

// extend page with ValidateForm function
p_villages_edit.ValidateForm = function(fobj) {
	ew_PostAutoSuggest(fobj);
	if (!this.ValidateRequired)
		return true; // ignore validation
	if (fobj.a_confirm && fobj.a_confirm.value == "F")
		return true;
	var i, elm, aelm, infix;
	var rowcnt = (fobj.key_count) ? Number(fobj.key_count.value) : 1;
	for (i=0; i<rowcnt; i++) {
		infix = (fobj.key_count) ? String(i+1) : "";
		elm = fobj.elements["x" + infix + "_is_capital"];
		if (elm && !ew_CheckInteger(elm.value))
			return ew_OnError(this, elm, "<?php echo ew_JsEncode2($p_villages->is_capital->FldErrMsg()) ?>");
		elm = fobj.elements["x" + infix + "_is_special_village"];
		if (elm && !ew_CheckInteger(elm.value))
			return ew_OnError(this, elm, "<?php echo ew_JsEncode2($p_villages->is_special_village->FldErrMsg()) ?>");
		elm = fobj.elements["x" + infix + "_people_count"];
		if (elm && !ew_CheckInteger(elm.value))
			return ew_OnError(this, elm, "<?php echo ew_JsEncode2($p_villages->people_count->FldErrMsg()) ?>");
		elm = fobj.elements["x" + infix + "_crop_consumption"];
		if (elm && !ew_CheckInteger(elm.value))
			return ew_OnError(this, elm, "<?php echo ew_JsEncode2($p_villages->crop_consumption->FldErrMsg()) ?>");

		// Call Form Custom Validate event
		if (!this.Form_CustomValidate(fobj)) return false;
	}
	return true;
}

// extend page with Form_CustomValidate function
p_villages_edit.Form_CustomValidate =  
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }
<?php if (EW_CLIENT_VALIDATE) { ?>
p_villages_edit.ValidateRequired = true; // uses JavaScript validation
<?php } else { ?>
p_villages_edit.ValidateRequired = false; // no JavaScript validation
<?php } ?>

//-->
</script>
<script type="text/javascript">
<!--
var ew_DHTMLEditors = [];

//-->
</script>
<script language="JavaScript" type="text/javascript">
<!--

// Write your client script here, no need to add script tags.
// To include another .js script, use:
// ew_ClientScriptInclude("my_javascript.js"); 
//-->

</script>
<p><span class="phpmaker"><?php echo $Language->Phrase("Edit") ?>&nbsp;<?php echo $Language->Phrase("TblTypeTABLE") ?><?php echo $p_villages->TableCaption() ?><br><br>
<a href="<?php echo $p_villages->getReturnUrl() ?>"><?php echo $Language->Phrase("GoBack") ?></a></span></p>
<?php
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
$p_villages_edit->ShowMessage();
?>
<form name="fp_villagesedit" id="fp_villagesedit" action="<?php echo ew_CurrentPage() ?>" method="post" onsubmit="return p_villages_edit.ValidateForm(this);">
<p>
<input type="hidden" name="a_table" id="a_table" value="p_villages">
<input type="hidden" name="a_edit" id="a_edit" value="U">
<table cellspacing="0" class="ewGrid"><tr><td class="ewGridContent">
<div class="ewGridMiddlePanel">
<table cellspacing="0" class="ewTable">
<?php if ($p_villages->player_name->Visible) { // player_name ?>
	<tr<?php echo $p_villages->player_name->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_villages->player_name->FldCaption() ?></td>
		<td<?php echo $p_villages->player_name->CellAttributes() ?>><span id="el_player_name">
<textarea name="x_player_name" id="x_player_name" title="<?php echo $p_villages->player_name->FldTitle() ?>" cols="35" rows="4"<?php echo $p_villages->player_name->EditAttributes() ?>><?php echo $p_villages->player_name->EditValue ?></textarea>
</span><?php echo $p_villages->player_name->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_villages->village_name->Visible) { // village_name ?>
	<tr<?php echo $p_villages->village_name->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_villages->village_name->FldCaption() ?></td>
		<td<?php echo $p_villages->village_name->CellAttributes() ?>><span id="el_village_name">
<input type="text" name="x_village_name" id="x_village_name" title="<?php echo $p_villages->village_name->FldTitle() ?>" size="30" maxlength="255" value="<?php echo $p_villages->village_name->EditValue ?>"<?php echo $p_villages->village_name->EditAttributes() ?>>
</span><?php echo $p_villages->village_name->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_villages->is_capital->Visible) { // is_capital ?>
	<tr<?php echo $p_villages->is_capital->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_villages->is_capital->FldCaption() ?></td>
		<td<?php echo $p_villages->is_capital->CellAttributes() ?>><span id="el_is_capital">
<input type="text" name="x_is_capital" id="x_is_capital" title="<?php echo $p_villages->is_capital->FldTitle() ?>" size="30" value="<?php echo $p_villages->is_capital->EditValue ?>"<?php echo $p_villages->is_capital->EditAttributes() ?>>
</span><?php echo $p_villages->is_capital->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_villages->is_special_village->Visible) { // is_special_village ?>
	<tr<?php echo $p_villages->is_special_village->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_villages->is_special_village->FldCaption() ?></td>
		<td<?php echo $p_villages->is_special_village->CellAttributes() ?>><span id="el_is_special_village">
<input type="text" name="x_is_special_village" id="x_is_special_village" title="<?php echo $p_villages->is_special_village->FldTitle() ?>" size="30" value="<?php echo $p_villages->is_special_village->EditValue ?>"<?php echo $p_villages->is_special_village->EditAttributes() ?>>
</span><?php echo $p_villages->is_special_village->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_villages->people_count->Visible) { // people_count ?>
	<tr<?php echo $p_villages->people_count->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_villages->people_count->FldCaption() ?></td>
		<td<?php echo $p_villages->people_count->CellAttributes() ?>><span id="el_people_count">
<input type="text" name="x_people_count" id="x_people_count" title="<?php echo $p_villages->people_count->FldTitle() ?>" size="30" value="<?php echo $p_villages->people_count->EditValue ?>"<?php echo $p_villages->people_count->EditAttributes() ?>>
</span><?php echo $p_villages->people_count->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_villages->crop_consumption->Visible) { // crop_consumption ?>
	<tr<?php echo $p_villages->crop_consumption->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_villages->crop_consumption->FldCaption() ?></td>
		<td<?php echo $p_villages->crop_consumption->CellAttributes() ?>><span id="el_crop_consumption">
<input type="text" name="x_crop_consumption" id="x_crop_consumption" title="<?php echo $p_villages->crop_consumption->FldTitle() ?>" size="30" value="<?php echo $p_villages->crop_consumption->EditValue ?>"<?php echo $p_villages->crop_consumption->EditAttributes() ?>>
</span><?php echo $p_villages->crop_consumption->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_villages->resources->Visible) { // resources ?>
	<tr<?php echo $p_villages->resources->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_villages->resources->FldCaption() ?></td>
		<td<?php echo $p_villages->resources->CellAttributes() ?>><span id="el_resources">
<textarea name="x_resources" id="x_resources" title="<?php echo $p_villages->resources->FldTitle() ?>" cols="35" rows="4"<?php echo $p_villages->resources->EditAttributes() ?>><?php echo $p_villages->resources->EditValue ?></textarea>
</span><?php echo $p_villages->resources->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_villages->cp->Visible) { // cp ?>
	<tr<?php echo $p_villages->cp->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_villages->cp->FldCaption() ?></td>
		<td<?php echo $p_villages->cp->CellAttributes() ?>><span id="el_cp">
<textarea name="x_cp" id="x_cp" title="<?php echo $p_villages->cp->FldTitle() ?>" cols="35" rows="4"<?php echo $p_villages->cp->EditAttributes() ?>><?php echo $p_villages->cp->EditValue ?></textarea>
</span><?php echo $p_villages->cp->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_villages->buildings->Visible) { // buildings ?>
	<tr<?php echo $p_villages->buildings->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_villages->buildings->FldCaption() ?></td>
		<td<?php echo $p_villages->buildings->CellAttributes() ?>><span id="el_buildings">
<textarea name="x_buildings" id="x_buildings" title="<?php echo $p_villages->buildings->FldTitle() ?>" cols="35" rows="4"<?php echo $p_villages->buildings->EditAttributes() ?>><?php echo $p_villages->buildings->EditValue ?></textarea>
</span><?php echo $p_villages->buildings->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_villages->troops_num->Visible) { // troops_num ?>
	<tr<?php echo $p_villages->troops_num->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_villages->troops_num->FldCaption() ?></td>
		<td<?php echo $p_villages->troops_num->CellAttributes() ?>><span id="el_troops_num">
<textarea name="x_troops_num" id="x_troops_num" title="<?php echo $p_villages->troops_num->FldTitle() ?>" cols="35" rows="4"<?php echo $p_villages->troops_num->EditAttributes() ?>><?php echo $p_villages->troops_num->EditValue ?></textarea>
</span><?php echo $p_villages->troops_num->CustomMsg ?></td>
	</tr>
<?php } ?>
</table>
</div>
</td></tr></table>
<input type="hidden" name="x_id" id="x_id" value="<?php echo ew_HtmlEncode($p_villages->id->CurrentValue) ?>">
<p>
<input type="submit" name="btnAction" id="btnAction" value="<?php echo ew_BtnCaption($Language->Phrase("EditBtn")) ?>">
</form>
<script language="JavaScript" type="text/javascript">
<!--

// Write your table-specific startup script here
// document.write("page loaded");
//-->

</script>
<?php include "footer.php" ?>
<?php
$p_villages_edit->Page_Terminate();
?>
<?php

//
// Page class
//
class cp_villages_edit {

	// Page ID
	var $PageID = 'edit';

	// Table name
	var $TableName = 'p_villages';

	// Page object name
	var $PageObjName = 'p_villages_edit';

	// Page name
	function PageName() {
		return ew_CurrentPage();
	}

	// Page URL
	function PageUrl() {
		$PageUrl = ew_CurrentPage() . "?";
		global $p_villages;
		if ($p_villages->UseTokenInUrl) $PageUrl .= "t=" . $p_villages->TableVar . "&"; // Add page token
		return $PageUrl;
	}

	// Page URLs
	var $AddUrl;
	var $EditUrl;
	var $CopyUrl;
	var $DeleteUrl;
	var $ViewUrl;
	var $ListUrl;

	// Export URLs
	var $ExportPrintUrl;
	var $ExportHtmlUrl;
	var $ExportExcelUrl;
	var $ExportWordUrl;
	var $ExportXmlUrl;
	var $ExportCsvUrl;

	// Update URLs
	var $InlineAddUrl;
	var $InlineCopyUrl;
	var $InlineEditUrl;
	var $GridAddUrl;
	var $GridEditUrl;
	var $MultiDeleteUrl;
	var $MultiUpdateUrl;

	// Message
	function getMessage() {
		return @$_SESSION[EW_SESSION_MESSAGE];
	}

	function setMessage($v) {
		if (@$_SESSION[EW_SESSION_MESSAGE] <> "") { // Append
			$_SESSION[EW_SESSION_MESSAGE] .= "<br>" . $v;
		} else {
			$_SESSION[EW_SESSION_MESSAGE] = $v;
		}
	}

	// Show message
	function ShowMessage() {
		$sMessage = $this->getMessage();
		$this->Message_Showing($sMessage);
		if ($sMessage <> "") { // Message in Session, display
			echo "<p><span class=\"ewMessage\">" . $sMessage . "</span></p>";
			$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message in Session
		}
	}

	// Validate page request
	function IsPageRequest() {
		global $objForm, $p_villages;
		if ($p_villages->UseTokenInUrl) {
			if ($objForm)
				return ($p_villages->TableVar == $objForm->GetValue("t"));
			if (@$_GET["t"] <> "")
				return ($p_villages->TableVar == $_GET["t"]);
		} else {
			return TRUE;
		}
	}

	//
	// Page class constructor
	//
	function cp_villages_edit() {
		global $conn, $Language;

		// Language object
		$Language = new cLanguage();

		// Table object (p_villages)
		$GLOBALS["p_villages"] = new cp_villages();

		// Page ID
		if (!defined("EW_PAGE_ID"))
			define("EW_PAGE_ID", 'edit', TRUE);

		// Table name (for backward compatibility)
		if (!defined("EW_TABLE_NAME"))
			define("EW_TABLE_NAME", 'p_villages', TRUE);

		// Start timer
		$GLOBALS["gsTimer"] = new cTimer();

		// Open connection
		$conn = ew_Connect();
	}

	// 
	//  Page_Init
	//
	function Page_Init() {
		global $gsExport, $gsExportFile, $UserProfile, $Language, $Security, $objForm;
		global $p_villages;

		// Security
		$Security = new cAdvancedSecurity();
		if (!$Security->IsLoggedIn()) $Security->AutoLogin();
		if (!$Security->IsLoggedIn()) {
			$Security->SaveLastUrl();
			$this->Page_Terminate("login.php");
		}

		// Create form object
		$objForm = new cFormObj();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();
	}

	//
	// Page_Terminate
	//
	function Page_Terminate($url = "") {
		global $conn;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		 // Close connection
		$conn->Close();

		// Go to URL if specified
		$this->Page_Redirecting($url);
		if ($url <> "") {
			if (!EW_DEBUG_ENABLED && ob_get_length())
				ob_end_clean();
			header("Location: " . $url);
		}
		exit();
	}
	var $sDbMasterFilter;
	var $sDbDetailFilter;

	// 
	// Page main
	//
	function Page_Main() {
		global $objForm, $Language, $gsFormError, $p_villages;

		// Load key from QueryString
		if (@$_GET["id"] <> "")
			$p_villages->id->setQueryStringValue($_GET["id"]);
		if (@$_POST["a_edit"] <> "") {
			$p_villages->CurrentAction = $_POST["a_edit"]; // Get action code
			$this->LoadFormValues(); // Get form values

			// Validate form
			if (!$this->ValidateForm()) {
				$p_villages->CurrentAction = ""; // Form error, reset action
				$this->setMessage($gsFormError);
				$p_villages->EventCancelled = TRUE; // Event cancelled
				$this->RestoreFormValues();
			}
		} else {
			$p_villages->CurrentAction = "I"; // Default action is display
		}

		// Check if valid key
		if ($p_villages->id->CurrentValue == "")
			$this->Page_Terminate("p_villageslist.php"); // Invalid key, return to list
		switch ($p_villages->CurrentAction) {
			case "I": // Get a record to display
				if (!$this->LoadRow()) { // Load record based on key
					$this->setMessage($Language->Phrase("NoRecord")); // No record found
					$this->Page_Terminate("p_villageslist.php"); // No matching record, return to list
				}
				break;
			Case "U": // Update
				$p_villages->SendEmail = TRUE; // Send email on update success
				if ($this->EditRow()) { // Update record based on key
					$this->setMessage($Language->Phrase("UpdateSuccess")); // Update success
					$sReturnUrl = $p_villages->getReturnUrl();
					$this->Page_Terminate($sReturnUrl); // Return to caller
				} else {
					$p_villages->EventCancelled = TRUE; // Event cancelled
					$this->RestoreFormValues(); // Restore form values if update failed
				}
		}

		// Render the record
		$p_villages->RowType = EW_ROWTYPE_EDIT; // Render as Edit
		$this->RenderRow();
	}

	// Get upload files
	function GetUploadFiles() {
		global $objForm, $p_villages;

		// Get upload data
	}

	// Load form values
	function LoadFormValues() {

		// Load from form
		global $objForm, $p_villages;
		$p_villages->player_name->setFormValue($objForm->GetValue("x_player_name"));
		$p_villages->village_name->setFormValue($objForm->GetValue("x_village_name"));
		$p_villages->is_capital->setFormValue($objForm->GetValue("x_is_capital"));
		$p_villages->is_special_village->setFormValue($objForm->GetValue("x_is_special_village"));
		$p_villages->people_count->setFormValue($objForm->GetValue("x_people_count"));
		$p_villages->crop_consumption->setFormValue($objForm->GetValue("x_crop_consumption"));
		$p_villages->resources->setFormValue($objForm->GetValue("x_resources"));
		$p_villages->cp->setFormValue($objForm->GetValue("x_cp"));
		$p_villages->buildings->setFormValue($objForm->GetValue("x_buildings"));
		$p_villages->troops_num->setFormValue($objForm->GetValue("x_troops_num"));
		$p_villages->id->setFormValue($objForm->GetValue("x_id"));
	}

	// Restore form values
	function RestoreFormValues() {
		global $objForm, $p_villages;
		$p_villages->id->CurrentValue = $p_villages->id->FormValue;
		$this->LoadRow();
		$p_villages->player_name->CurrentValue = $p_villages->player_name->FormValue;
		$p_villages->village_name->CurrentValue = $p_villages->village_name->FormValue;
		$p_villages->is_capital->CurrentValue = $p_villages->is_capital->FormValue;
		$p_villages->is_special_village->CurrentValue = $p_villages->is_special_village->FormValue;
		$p_villages->people_count->CurrentValue = $p_villages->people_count->FormValue;
		$p_villages->crop_consumption->CurrentValue = $p_villages->crop_consumption->FormValue;
		$p_villages->resources->CurrentValue = $p_villages->resources->FormValue;
		$p_villages->cp->CurrentValue = $p_villages->cp->FormValue;
		$p_villages->buildings->CurrentValue = $p_villages->buildings->FormValue;
		$p_villages->troops_num->CurrentValue = $p_villages->troops_num->FormValue;
	}

	// Load row based on key values
	function LoadRow() {
		global $conn, $Security, $p_villages;
		$sFilter = $p_villages->KeyFilter();

		// Call Row Selecting event
		$p_villages->Row_Selecting($sFilter);

		// Load SQL based on filter
		$p_villages->CurrentFilter = $sFilter;
		$sSql = $p_villages->SQL();
		$res = FALSE;
		$rs = ew_LoadRecordset($sSql);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->LoadRowValues($rs); // Load row values

			// Call Row Selected event
			$p_villages->Row_Selected($rs);
			$rs->Close();
		}
		return $res;
	}

	// Load row values from recordset
	function LoadRowValues(&$rs) {
		global $conn, $p_villages;
		$p_villages->id->setDbValue($rs->fields('id'));
		$p_villages->rel_x->setDbValue($rs->fields('rel_x'));
		$p_villages->rel_y->setDbValue($rs->fields('rel_y'));
		$p_villages->field_maps_id->setDbValue($rs->fields('field_maps_id'));
		$p_villages->image_num->setDbValue($rs->fields('image_num'));
		$p_villages->rand_num->setDbValue($rs->fields('rand_num'));
		$p_villages->parent_id->setDbValue($rs->fields('parent_id'));
		$p_villages->tribe_id->setDbValue($rs->fields('tribe_id'));
		$p_villages->player_id->setDbValue($rs->fields('player_id'));
		$p_villages->alliance_id->setDbValue($rs->fields('alliance_id'));
		$p_villages->player_name->setDbValue($rs->fields('player_name'));
		$p_villages->village_name->setDbValue($rs->fields('village_name'));
		$p_villages->alliance_name->setDbValue($rs->fields('alliance_name'));
		$p_villages->is_capital->setDbValue($rs->fields('is_capital'));
		$p_villages->is_special_village->setDbValue($rs->fields('is_special_village'));
		$p_villages->is_oasis->setDbValue($rs->fields('is_oasis'));
		$p_villages->people_count->setDbValue($rs->fields('people_count'));
		$p_villages->crop_consumption->setDbValue($rs->fields('crop_consumption'));
		$p_villages->time_consume_percent->setDbValue($rs->fields('time_consume_percent'));
		$p_villages->offer_merchants_count->setDbValue($rs->fields('offer_merchants_count'));
		$p_villages->resources->setDbValue($rs->fields('resources'));
		$p_villages->cp->setDbValue($rs->fields('cp'));
		$p_villages->buildings->setDbValue($rs->fields('buildings'));
		$p_villages->troops_training->setDbValue($rs->fields('troops_training'));
		$p_villages->troops_num->setDbValue($rs->fields('troops_num'));
		$p_villages->troops_out_num->setDbValue($rs->fields('troops_out_num'));
		$p_villages->troops_intrap_num->setDbValue($rs->fields('troops_intrap_num'));
		$p_villages->troops_out_intrap_num->setDbValue($rs->fields('troops_out_intrap_num'));
		$p_villages->troops_trapped_num->setDbValue($rs->fields('troops_trapped_num'));
		$p_villages->allegiance_percent->setDbValue($rs->fields('allegiance_percent'));
		$p_villages->child_villages_id->setDbValue($rs->fields('child_villages_id'));
		$p_villages->village_oases_id->setDbValue($rs->fields('village_oases_id'));
		$p_villages->creation_date->setDbValue($rs->fields('creation_date'));
		$p_villages->update_key->setDbValue($rs->fields('update_key'));
		$p_villages->last_update_date->setDbValue($rs->fields('last_update_date'));
	}

	// Render row values based on field settings
	function RenderRow() {
		global $conn, $Security, $Language, $p_villages;

		// Initialize URLs
		// Call Row_Rendering event

		$p_villages->Row_Rendering();

		// Common render codes for all row types
		// player_name

		$p_villages->player_name->CellCssStyle = ""; $p_villages->player_name->CellCssClass = "";
		$p_villages->player_name->CellAttrs = array(); $p_villages->player_name->ViewAttrs = array(); $p_villages->player_name->EditAttrs = array();

		// village_name
		$p_villages->village_name->CellCssStyle = ""; $p_villages->village_name->CellCssClass = "";
		$p_villages->village_name->CellAttrs = array(); $p_villages->village_name->ViewAttrs = array(); $p_villages->village_name->EditAttrs = array();

		// is_capital
		$p_villages->is_capital->CellCssStyle = ""; $p_villages->is_capital->CellCssClass = "";
		$p_villages->is_capital->CellAttrs = array(); $p_villages->is_capital->ViewAttrs = array(); $p_villages->is_capital->EditAttrs = array();

		// is_special_village
		$p_villages->is_special_village->CellCssStyle = ""; $p_villages->is_special_village->CellCssClass = "";
		$p_villages->is_special_village->CellAttrs = array(); $p_villages->is_special_village->ViewAttrs = array(); $p_villages->is_special_village->EditAttrs = array();

		// people_count
		$p_villages->people_count->CellCssStyle = ""; $p_villages->people_count->CellCssClass = "";
		$p_villages->people_count->CellAttrs = array(); $p_villages->people_count->ViewAttrs = array(); $p_villages->people_count->EditAttrs = array();

		// crop_consumption
		$p_villages->crop_consumption->CellCssStyle = ""; $p_villages->crop_consumption->CellCssClass = "";
		$p_villages->crop_consumption->CellAttrs = array(); $p_villages->crop_consumption->ViewAttrs = array(); $p_villages->crop_consumption->EditAttrs = array();

		// resources
		$p_villages->resources->CellCssStyle = ""; $p_villages->resources->CellCssClass = "";
		$p_villages->resources->CellAttrs = array(); $p_villages->resources->ViewAttrs = array(); $p_villages->resources->EditAttrs = array();

		// cp
		$p_villages->cp->CellCssStyle = ""; $p_villages->cp->CellCssClass = "";
		$p_villages->cp->CellAttrs = array(); $p_villages->cp->ViewAttrs = array(); $p_villages->cp->EditAttrs = array();

		// buildings
		$p_villages->buildings->CellCssStyle = ""; $p_villages->buildings->CellCssClass = "";
		$p_villages->buildings->CellAttrs = array(); $p_villages->buildings->ViewAttrs = array(); $p_villages->buildings->EditAttrs = array();

		// troops_num
		$p_villages->troops_num->CellCssStyle = ""; $p_villages->troops_num->CellCssClass = "";
		$p_villages->troops_num->CellAttrs = array(); $p_villages->troops_num->ViewAttrs = array(); $p_villages->troops_num->EditAttrs = array();
		if ($p_villages->RowType == EW_ROWTYPE_VIEW) { // View row

			// id
			$p_villages->id->ViewValue = $p_villages->id->CurrentValue;
			$p_villages->id->CssStyle = "";
			$p_villages->id->CssClass = "";
			$p_villages->id->ViewCustomAttributes = "";

			// player_name
			$p_villages->player_name->ViewValue = $p_villages->player_name->CurrentValue;
			$p_villages->player_name->CssStyle = "";
			$p_villages->player_name->CssClass = "";
			$p_villages->player_name->ViewCustomAttributes = "";

			// village_name
			$p_villages->village_name->ViewValue = $p_villages->village_name->CurrentValue;
			$p_villages->village_name->CssStyle = "";
			$p_villages->village_name->CssClass = "";
			$p_villages->village_name->ViewCustomAttributes = "";

			// is_capital
			$p_villages->is_capital->ViewValue = $p_villages->is_capital->CurrentValue;
			$p_villages->is_capital->CssStyle = "";
			$p_villages->is_capital->CssClass = "";
			$p_villages->is_capital->ViewCustomAttributes = "";

			// is_special_village
			$p_villages->is_special_village->ViewValue = $p_villages->is_special_village->CurrentValue;
			$p_villages->is_special_village->CssStyle = "";
			$p_villages->is_special_village->CssClass = "";
			$p_villages->is_special_village->ViewCustomAttributes = "";

			// people_count
			$p_villages->people_count->ViewValue = $p_villages->people_count->CurrentValue;
			$p_villages->people_count->CssStyle = "";
			$p_villages->people_count->CssClass = "";
			$p_villages->people_count->ViewCustomAttributes = "";

			// crop_consumption
			$p_villages->crop_consumption->ViewValue = $p_villages->crop_consumption->CurrentValue;
			$p_villages->crop_consumption->CssStyle = "";
			$p_villages->crop_consumption->CssClass = "";
			$p_villages->crop_consumption->ViewCustomAttributes = "";

			// resources
			$p_villages->resources->ViewValue = $p_villages->resources->CurrentValue;
			$p_villages->resources->CssStyle = "";
			$p_villages->resources->CssClass = "";
			$p_villages->resources->ViewCustomAttributes = "";

			// cp
			$p_villages->cp->ViewValue = $p_villages->cp->CurrentValue;
			$p_villages->cp->CssStyle = "";
			$p_villages->cp->CssClass = "";
			$p_villages->cp->ViewCustomAttributes = "";

			// buildings
			$p_villages->buildings->ViewValue = $p_villages->buildings->CurrentValue;
			$p_villages->buildings->CssStyle = "";
			$p_villages->buildings->CssClass = "";
			$p_villages->buildings->ViewCustomAttributes = "";

			// troops_num
			$p_villages->troops_num->ViewValue = $p_villages->troops_num->CurrentValue;
			$p_villages->troops_num->CssStyle = "";
			$p_villages->troops_num->CssClass = "";
			$p_villages->troops_num->ViewCustomAttributes = "";

			// player_name
			$p_villages->player_name->HrefValue = "";
			$p_villages->player_name->TooltipValue = "";

			// village_name
			$p_villages->village_name->HrefValue = "";
			$p_villages->village_name->TooltipValue = "";

			// is_capital
			$p_villages->is_capital->HrefValue = "";
			$p_villages->is_capital->TooltipValue = "";

			// is_special_village
			$p_villages->is_special_village->HrefValue = "";
			$p_villages->is_special_village->TooltipValue = "";

			// people_count
			$p_villages->people_count->HrefValue = "";
			$p_villages->people_count->TooltipValue = "";

			// crop_consumption
			$p_villages->crop_consumption->HrefValue = "";
			$p_villages->crop_consumption->TooltipValue = "";

			// resources
			$p_villages->resources->HrefValue = "";
			$p_villages->resources->TooltipValue = "";

			// cp
			$p_villages->cp->HrefValue = "";
			$p_villages->cp->TooltipValue = "";

			// buildings
			$p_villages->buildings->HrefValue = "";
			$p_villages->buildings->TooltipValue = "";

			// troops_num
			$p_villages->troops_num->HrefValue = "";
			$p_villages->troops_num->TooltipValue = "";
		} elseif ($p_villages->RowType == EW_ROWTYPE_EDIT) { // Edit row

			// player_name
			$p_villages->player_name->EditCustomAttributes = "";
			$p_villages->player_name->EditValue = ew_HtmlEncode($p_villages->player_name->CurrentValue);

			// village_name
			$p_villages->village_name->EditCustomAttributes = "";
			$p_villages->village_name->EditValue = ew_HtmlEncode($p_villages->village_name->CurrentValue);

			// is_capital
			$p_villages->is_capital->EditCustomAttributes = "";
			$p_villages->is_capital->EditValue = ew_HtmlEncode($p_villages->is_capital->CurrentValue);

			// is_special_village
			$p_villages->is_special_village->EditCustomAttributes = "";
			$p_villages->is_special_village->EditValue = ew_HtmlEncode($p_villages->is_special_village->CurrentValue);

			// people_count
			$p_villages->people_count->EditCustomAttributes = "";
			$p_villages->people_count->EditValue = ew_HtmlEncode($p_villages->people_count->CurrentValue);

			// crop_consumption
			$p_villages->crop_consumption->EditCustomAttributes = "";
			$p_villages->crop_consumption->EditValue = ew_HtmlEncode($p_villages->crop_consumption->CurrentValue);

			// resources
			$p_villages->resources->EditCustomAttributes = "";
			$p_villages->resources->EditValue = ew_HtmlEncode($p_villages->resources->CurrentValue);

			// cp
			$p_villages->cp->EditCustomAttributes = "";
			$p_villages->cp->EditValue = ew_HtmlEncode($p_villages->cp->CurrentValue);

			// buildings
			$p_villages->buildings->EditCustomAttributes = "";
			$p_villages->buildings->EditValue = ew_HtmlEncode($p_villages->buildings->CurrentValue);

			// troops_num
			$p_villages->troops_num->EditCustomAttributes = "";
			$p_villages->troops_num->EditValue = ew_HtmlEncode($p_villages->troops_num->CurrentValue);

			// Edit refer script
			// player_name

			$p_villages->player_name->HrefValue = "";

			// village_name
			$p_villages->village_name->HrefValue = "";

			// is_capital
			$p_villages->is_capital->HrefValue = "";

			// is_special_village
			$p_villages->is_special_village->HrefValue = "";

			// people_count
			$p_villages->people_count->HrefValue = "";

			// crop_consumption
			$p_villages->crop_consumption->HrefValue = "";

			// resources
			$p_villages->resources->HrefValue = "";

			// cp
			$p_villages->cp->HrefValue = "";

			// buildings
			$p_villages->buildings->HrefValue = "";

			// troops_num
			$p_villages->troops_num->HrefValue = "";
		}

		// Call Row Rendered event
		if ($p_villages->RowType <> EW_ROWTYPE_AGGREGATEINIT)
			$p_villages->Row_Rendered();
	}

	// Validate form
	function ValidateForm() {
		global $Language, $gsFormError, $p_villages;

		// Initialize form error message
		$gsFormError = "";

		// Check if validation required
		if (!EW_SERVER_VALIDATE)
			return ($gsFormError == "");
		if (!ew_CheckInteger($p_villages->is_capital->FormValue)) {
			if ($gsFormError <> "") $gsFormError .= "<br>";
			$gsFormError .= $p_villages->is_capital->FldErrMsg();
		}
		if (!ew_CheckInteger($p_villages->is_special_village->FormValue)) {
			if ($gsFormError <> "") $gsFormError .= "<br>";
			$gsFormError .= $p_villages->is_special_village->FldErrMsg();
		}
		if (!ew_CheckInteger($p_villages->people_count->FormValue)) {
			if ($gsFormError <> "") $gsFormError .= "<br>";
			$gsFormError .= $p_villages->people_count->FldErrMsg();
		}
		if (!ew_CheckInteger($p_villages->crop_consumption->FormValue)) {
			if ($gsFormError <> "") $gsFormError .= "<br>";
			$gsFormError .= $p_villages->crop_consumption->FldErrMsg();
		}

		// Return validate result
		$ValidateForm = ($gsFormError == "");

		// Call Form_CustomValidate event
		$sFormCustomError = "";
		$ValidateForm = $ValidateForm && $this->Form_CustomValidate($sFormCustomError);
		if ($sFormCustomError <> "") {
			$gsFormError .= ($gsFormError <> "") ? "<br>" : "";
			$gsFormError .= $sFormCustomError;
		}
		return $ValidateForm;
	}

	// Update record based on key values
	function EditRow() {
		global $conn, $Security, $Language, $p_villages;
		$sFilter = $p_villages->KeyFilter();
		$p_villages->CurrentFilter = $sFilter;
		$sSql = $p_villages->SQL();
		$conn->raiseErrorFn = 'ew_ErrorFn';
		$rs = $conn->Execute($sSql);
		$conn->raiseErrorFn = '';
		if ($rs === FALSE)
			return FALSE;
		if ($rs->EOF) {
			$EditRow = FALSE; // Update Failed
		} else {

			// Save old values
			$rsold =& $rs->fields;
			$rsnew = array();

			// player_name
			$p_villages->player_name->SetDbValueDef($rsnew, $p_villages->player_name->CurrentValue, NULL, FALSE);

			// village_name
			$p_villages->village_name->SetDbValueDef($rsnew, $p_villages->village_name->CurrentValue, NULL, FALSE);

			// is_capital
			$p_villages->is_capital->SetDbValueDef($rsnew, $p_villages->is_capital->CurrentValue, NULL, FALSE);

			// is_special_village
			$p_villages->is_special_village->SetDbValueDef($rsnew, $p_villages->is_special_village->CurrentValue, NULL, FALSE);

			// people_count
			$p_villages->people_count->SetDbValueDef($rsnew, $p_villages->people_count->CurrentValue, NULL, FALSE);

			// crop_consumption
			$p_villages->crop_consumption->SetDbValueDef($rsnew, $p_villages->crop_consumption->CurrentValue, NULL, FALSE);

			// resources
			$p_villages->resources->SetDbValueDef($rsnew, $p_villages->resources->CurrentValue, NULL, FALSE);

			// cp
			$p_villages->cp->SetDbValueDef($rsnew, $p_villages->cp->CurrentValue, NULL, FALSE);

			// buildings
			$p_villages->buildings->SetDbValueDef($rsnew, $p_villages->buildings->CurrentValue, NULL, FALSE);

			// troops_num
			$p_villages->troops_num->SetDbValueDef($rsnew, $p_villages->troops_num->CurrentValue, NULL, FALSE);

			// Call Row Updating event
			$bUpdateRow = $p_villages->Row_Updating($rsold, $rsnew);
			if ($bUpdateRow) {
				$conn->raiseErrorFn = 'ew_ErrorFn';
				$EditRow = $conn->Execute($p_villages->UpdateSQL($rsnew));
				$conn->raiseErrorFn = '';
			} else {
				if ($p_villages->CancelMessage <> "") {
					$this->setMessage($p_villages->CancelMessage);
					$p_villages->CancelMessage = "";
				} else {
					$this->setMessage($Language->Phrase("UpdateCancelled"));
				}
				$EditRow = FALSE;
			}
		}

		// Call Row_Updated event
		if ($EditRow)
			$p_villages->Row_Updated($rsold, $rsnew);
		$rs->Close();
		return $EditRow;
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	function Message_Showing(&$msg) {

		// Example:
		//$msg = "your new message";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$CustomError) {

		// Return error message in CustomError
		return TRUE;
	}
}
?>
