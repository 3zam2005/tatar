<?php

// Global variable for table object
$p_villages = NULL;

//
// Table class for p_villages
//
class cp_villages {
	var $TableVar = 'p_villages';
	var $TableName = 'p_villages';
	var $TableType = 'TABLE';
	var $id;
	var $rel_x;
	var $rel_y;
	var $field_maps_id;
	var $image_num;
	var $rand_num;
	var $parent_id;
	var $tribe_id;
	var $player_id;
	var $alliance_id;
	var $player_name;
	var $village_name;
	var $alliance_name;
	var $is_capital;
	var $is_special_village;
	var $is_oasis;
	var $people_count;
	var $crop_consumption;
	var $time_consume_percent;
	var $offer_merchants_count;
	var $resources;
	var $cp;
	var $buildings;
	var $troops_training;
	var $troops_num;
	var $troops_out_num;
	var $troops_intrap_num;
	var $troops_out_intrap_num;
	var $troops_trapped_num;
	var $allegiance_percent;
	var $child_villages_id;
	var $village_oases_id;
	var $creation_date;
	var $update_key;
	var $last_update_date;
	var $fields = array();
	var $UseTokenInUrl = EW_USE_TOKEN_IN_URL;
	var $Export; // Export
	var $ExportOriginalValue = EW_EXPORT_ORIGINAL_VALUE;
	var $ExportAll = TRUE;
	var $SendEmail; // Send email
	var $TableCustomInnerHtml; // Custom inner HTML
	var $BasicSearchKeyword; // Basic search keyword
	var $BasicSearchType; // Basic search type
	var $CurrentFilter; // Current filter
	var $CurrentOrder; // Current order
	var $CurrentOrderType; // Current order type
	var $RowType; // Row type
	var $CssClass; // CSS class
	var $CssStyle; // CSS style
	var $RowAttrs = array(); // Row custom attributes
	var $TableFilter = "";
	var $CurrentAction; // Current action
	var $UpdateConflict; // Update conflict
	var $EventName; // Event name
	var $EventCancelled; // Event cancelled
	var $CancelMessage; // Cancel message

	//
	// Table class constructor
	//
	function cp_villages() {
		global $Language;

		// id
		$this->id = new cField('p_villages', 'p_villages', 'x_id', 'id', '`id`', 20, -1, FALSE, '`id`', FALSE);
		$this->id->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['id'] =& $this->id;

		// rel_x
		$this->rel_x = new cField('p_villages', 'p_villages', 'x_rel_x', 'rel_x', '`rel_x`', 2, -1, FALSE, '`rel_x`', FALSE);
		$this->rel_x->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['rel_x'] =& $this->rel_x;

		// rel_y
		$this->rel_y = new cField('p_villages', 'p_villages', 'x_rel_y', 'rel_y', '`rel_y`', 2, -1, FALSE, '`rel_y`', FALSE);
		$this->rel_y->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['rel_y'] =& $this->rel_y;

		// field_maps_id
		$this->field_maps_id = new cField('p_villages', 'p_villages', 'x_field_maps_id', 'field_maps_id', '`field_maps_id`', 16, -1, FALSE, '`field_maps_id`', FALSE);
		$this->field_maps_id->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['field_maps_id'] =& $this->field_maps_id;

		// image_num
		$this->image_num = new cField('p_villages', 'p_villages', 'x_image_num', 'image_num', '`image_num`', 16, -1, FALSE, '`image_num`', FALSE);
		$this->image_num->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['image_num'] =& $this->image_num;

		// rand_num
		$this->rand_num = new cField('p_villages', 'p_villages', 'x_rand_num', 'rand_num', '`rand_num`', 3, -1, FALSE, '`rand_num`', FALSE);
		$this->rand_num->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['rand_num'] =& $this->rand_num;

		// parent_id
		$this->parent_id = new cField('p_villages', 'p_villages', 'x_parent_id', 'parent_id', '`parent_id`', 20, -1, FALSE, '`parent_id`', FALSE);
		$this->parent_id->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['parent_id'] =& $this->parent_id;

		// tribe_id
		$this->tribe_id = new cField('p_villages', 'p_villages', 'x_tribe_id', 'tribe_id', '`tribe_id`', 16, -1, FALSE, '`tribe_id`', FALSE);
		$this->tribe_id->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['tribe_id'] =& $this->tribe_id;

		// player_id
		$this->player_id = new cField('p_villages', 'p_villages', 'x_player_id', 'player_id', '`player_id`', 20, -1, FALSE, '`player_id`', FALSE);
		$this->player_id->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['player_id'] =& $this->player_id;

		// alliance_id
		$this->alliance_id = new cField('p_villages', 'p_villages', 'x_alliance_id', 'alliance_id', '`alliance_id`', 20, -1, FALSE, '`alliance_id`', FALSE);
		$this->alliance_id->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['alliance_id'] =& $this->alliance_id;

		// player_name
		$this->player_name = new cField('p_villages', 'p_villages', 'x_player_name', 'player_name', '`player_name`', 201, -1, FALSE, '`player_name`', FALSE);
		$this->fields['player_name'] =& $this->player_name;

		// village_name
		$this->village_name = new cField('p_villages', 'p_villages', 'x_village_name', 'village_name', '`village_name`', 200, -1, FALSE, '`village_name`', FALSE);
		$this->fields['village_name'] =& $this->village_name;

		// alliance_name
		$this->alliance_name = new cField('p_villages', 'p_villages', 'x_alliance_name', 'alliance_name', '`alliance_name`', 201, -1, FALSE, '`alliance_name`', FALSE);
		$this->fields['alliance_name'] =& $this->alliance_name;

		// is_capital
		$this->is_capital = new cField('p_villages', 'p_villages', 'x_is_capital', 'is_capital', '`is_capital`', 16, -1, FALSE, '`is_capital`', FALSE);
		$this->is_capital->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['is_capital'] =& $this->is_capital;

		// is_special_village
		$this->is_special_village = new cField('p_villages', 'p_villages', 'x_is_special_village', 'is_special_village', '`is_special_village`', 16, -1, FALSE, '`is_special_village`', FALSE);
		$this->is_special_village->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['is_special_village'] =& $this->is_special_village;

		// is_oasis
		$this->is_oasis = new cField('p_villages', 'p_villages', 'x_is_oasis', 'is_oasis', '`is_oasis`', 16, -1, FALSE, '`is_oasis`', FALSE);
		$this->is_oasis->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['is_oasis'] =& $this->is_oasis;

		// people_count
		$this->people_count = new cField('p_villages', 'p_villages', 'x_people_count', 'people_count', '`people_count`', 3, -1, FALSE, '`people_count`', FALSE);
		$this->people_count->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['people_count'] =& $this->people_count;

		// crop_consumption
		$this->crop_consumption = new cField('p_villages', 'p_villages', 'x_crop_consumption', 'crop_consumption', '`crop_consumption`', 3, -1, FALSE, '`crop_consumption`', FALSE);
		$this->crop_consumption->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['crop_consumption'] =& $this->crop_consumption;

		// time_consume_percent
		$this->time_consume_percent = new cField('p_villages', 'p_villages', 'x_time_consume_percent', 'time_consume_percent', '`time_consume_percent`', 4, -1, FALSE, '`time_consume_percent`', FALSE);
		$this->time_consume_percent->FldDefaultErrMsg = $Language->Phrase("IncorrectFloat");
		$this->fields['time_consume_percent'] =& $this->time_consume_percent;

		// offer_merchants_count
		$this->offer_merchants_count = new cField('p_villages', 'p_villages', 'x_offer_merchants_count', 'offer_merchants_count', '`offer_merchants_count`', 16, -1, FALSE, '`offer_merchants_count`', FALSE);
		$this->offer_merchants_count->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['offer_merchants_count'] =& $this->offer_merchants_count;

		// resources
		$this->resources = new cField('p_villages', 'p_villages', 'x_resources', 'resources', '`resources`', 201, -1, FALSE, '`resources`', FALSE);
		$this->fields['resources'] =& $this->resources;

		// cp
		$this->cp = new cField('p_villages', 'p_villages', 'x_cp', 'cp', '`cp`', 201, -1, FALSE, '`cp`', FALSE);
		$this->fields['cp'] =& $this->cp;

		// buildings
		$this->buildings = new cField('p_villages', 'p_villages', 'x_buildings', 'buildings', '`buildings`', 201, -1, FALSE, '`buildings`', FALSE);
		$this->fields['buildings'] =& $this->buildings;

		// troops_training
		$this->troops_training = new cField('p_villages', 'p_villages', 'x_troops_training', 'troops_training', '`troops_training`', 200, -1, FALSE, '`troops_training`', FALSE);
		$this->fields['troops_training'] =& $this->troops_training;

		// troops_num
		$this->troops_num = new cField('p_villages', 'p_villages', 'x_troops_num', 'troops_num', '`troops_num`', 201, -1, FALSE, '`troops_num`', FALSE);
		$this->fields['troops_num'] =& $this->troops_num;

		// troops_out_num
		$this->troops_out_num = new cField('p_villages', 'p_villages', 'x_troops_out_num', 'troops_out_num', '`troops_out_num`', 201, -1, FALSE, '`troops_out_num`', FALSE);
		$this->fields['troops_out_num'] =& $this->troops_out_num;

		// troops_intrap_num
		$this->troops_intrap_num = new cField('p_villages', 'p_villages', 'x_troops_intrap_num', 'troops_intrap_num', '`troops_intrap_num`', 201, -1, FALSE, '`troops_intrap_num`', FALSE);
		$this->fields['troops_intrap_num'] =& $this->troops_intrap_num;

		// troops_out_intrap_num
		$this->troops_out_intrap_num = new cField('p_villages', 'p_villages', 'x_troops_out_intrap_num', 'troops_out_intrap_num', '`troops_out_intrap_num`', 201, -1, FALSE, '`troops_out_intrap_num`', FALSE);
		$this->fields['troops_out_intrap_num'] =& $this->troops_out_intrap_num;

		// troops_trapped_num
		$this->troops_trapped_num = new cField('p_villages', 'p_villages', 'x_troops_trapped_num', 'troops_trapped_num', '`troops_trapped_num`', 3, -1, FALSE, '`troops_trapped_num`', FALSE);
		$this->troops_trapped_num->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['troops_trapped_num'] =& $this->troops_trapped_num;

		// allegiance_percent
		$this->allegiance_percent = new cField('p_villages', 'p_villages', 'x_allegiance_percent', 'allegiance_percent', '`allegiance_percent`', 3, -1, FALSE, '`allegiance_percent`', FALSE);
		$this->allegiance_percent->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['allegiance_percent'] =& $this->allegiance_percent;

		// child_villages_id
		$this->child_villages_id = new cField('p_villages', 'p_villages', 'x_child_villages_id', 'child_villages_id', '`child_villages_id`', 201, -1, FALSE, '`child_villages_id`', FALSE);
		$this->fields['child_villages_id'] =& $this->child_villages_id;

		// village_oases_id
		$this->village_oases_id = new cField('p_villages', 'p_villages', 'x_village_oases_id', 'village_oases_id', '`village_oases_id`', 201, -1, FALSE, '`village_oases_id`', FALSE);
		$this->fields['village_oases_id'] =& $this->village_oases_id;

		// creation_date
		$this->creation_date = new cField('p_villages', 'p_villages', 'x_creation_date', 'creation_date', '`creation_date`', 135, 5, FALSE, '`creation_date`', FALSE);
		$this->creation_date->FldDefaultErrMsg = str_replace("%s", "/", $Language->Phrase("IncorrectDateYMD"));
		$this->fields['creation_date'] =& $this->creation_date;

		// update_key
		$this->update_key = new cField('p_villages', 'p_villages', 'x_update_key', 'update_key', '`update_key`', 200, -1, FALSE, '`update_key`', FALSE);
		$this->fields['update_key'] =& $this->update_key;

		// last_update_date
		$this->last_update_date = new cField('p_villages', 'p_villages', 'x_last_update_date', 'last_update_date', '`last_update_date`', 135, 5, FALSE, '`last_update_date`', FALSE);
		$this->last_update_date->FldDefaultErrMsg = str_replace("%s", "/", $Language->Phrase("IncorrectDateYMD"));
		$this->fields['last_update_date'] =& $this->last_update_date;
	}

	// Table caption
	function TableCaption() {
		global $Language;
		return $Language->TablePhrase($this->TableVar, "TblCaption");
	}

	// Page caption
	function PageCaption($Page) {
		global $Language;
		$Caption = $Language->TablePhrase($this->TableVar, "TblPageCaption" . $Page);
		if ($Caption == "") $Caption = "Page " . $Page;
		return $Caption;
	}

	// Export return page
	function ExportReturnUrl() {
		$url = @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_EXPORT_RETURN_URL];
		return ($url <> "") ? $url : ew_CurrentPage();
	}

	function setExportReturnUrl($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_EXPORT_RETURN_URL] = $v;
	}

	// Records per page
	function getRecordsPerPage() {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_REC_PER_PAGE];
	}

	function setRecordsPerPage($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_REC_PER_PAGE] = $v;
	}

	// Start record number
	function getStartRecordNumber() {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_START_REC];
	}

	function setStartRecordNumber($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_START_REC] = $v;
	}

	// Search highlight name
	function HighlightName() {
		return "p_villages_Highlight";
	}

	// Advanced search
	function getAdvancedSearch($fld) {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_ADVANCED_SEARCH . "_" . $fld];
	}

	function setAdvancedSearch($fld, $v) {
		if (@$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_ADVANCED_SEARCH . "_" . $fld] <> $v) {
			$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_ADVANCED_SEARCH . "_" . $fld] = $v;
		}
	}

	// Basic search keyword
	function getSessionBasicSearchKeyword() {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_BASIC_SEARCH];
	}

	function setSessionBasicSearchKeyword($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_BASIC_SEARCH] = $v;
	}

	// Basic search type
	function getSessionBasicSearchType() {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_BASIC_SEARCH_TYPE];
	}

	function setSessionBasicSearchType($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_BASIC_SEARCH_TYPE] = $v;
	}

	// Search WHERE clause
	function getSearchWhere() {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_SEARCH_WHERE];
	}

	function setSearchWhere($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_SEARCH_WHERE] = $v;
	}

	// Single column sort
	function UpdateSort(&$ofld) {
		if ($this->CurrentOrder == $ofld->FldName) {
			$sSortField = $ofld->FldExpression;
			$sLastSort = $ofld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$sThisSort = $this->CurrentOrderType;
			} else {
				$sThisSort = ($sLastSort == "ASC") ? "DESC" : "ASC";
			}
			$ofld->setSort($sThisSort);
			$this->setSessionOrderBy($sSortField . " " . $sThisSort); // Save to Session
		} else {
			$ofld->setSort("");
		}
	}

	// Session WHERE clause
	function getSessionWhere() {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_WHERE];
	}

	function setSessionWhere($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_WHERE] = $v;
	}

	// Session ORDER BY
	function getSessionOrderBy() {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_ORDER_BY];
	}

	function setSessionOrderBy($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_ORDER_BY] = $v;
	}

	// Session key
	function getKey($fld) {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_KEY . "_" . $fld];
	}

	function setKey($fld, $v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_KEY . "_" . $fld] = $v;
	}

	// Table level SQL
	function SqlFrom() { // From
		return "`p_villages`";
	}

	function SqlSelect() { // Select
		return "SELECT * FROM " . $this->SqlFrom();
	}

	function SqlWhere() { // Where
		$sWhere = "";
		$this->TableFilter = "";
		if ($this->TableFilter <> "") {
			if ($sWhere <> "") $sWhere .= "(" . $sWhere . ") AND (";
			$sWhere .= "(" . $this->TableFilter . ")";
		}
		return $sWhere;
	}

	function SqlGroupBy() { // Group By
		return "";
	}

	function SqlHaving() { // Having
		return "";
	}

	function SqlOrderBy() { // Order By
		return "";
	}

	// Check if Anonymous User is allowed
	function AllowAnonymousUser() {
		switch (EW_PAGE_ID) {
			case "add":
			case "register":
			case "addopt":
				return FALSE;
			case "edit":
			case "update":
				return FALSE;
			case "delete":
				return FALSE;
			case "view":
				return FALSE;
			case "search":
				return FALSE;
			default:
				return FALSE;
		}
	}

	// Apply User ID filters
	function ApplyUserIDFilters($sFilter) {
		return $sFilter;
	}

	// Get SQL
	function GetSQL($where, $orderby) {
		return ew_BuildSelectSql($this->SqlSelect(), $this->SqlWhere(),
			$this->SqlGroupBy(), $this->SqlHaving(), $this->SqlOrderBy(),
			$where, $orderby);
	}

	// Table SQL
	function SQL() {
		$sFilter = $this->CurrentFilter;
		$sFilter = $this->ApplyUserIDFilters($sFilter);
		$sSort = $this->getSessionOrderBy();
		return ew_BuildSelectSql($this->SqlSelect(), $this->SqlWhere(),
			$this->SqlGroupBy(), $this->SqlHaving(), $this->SqlOrderBy(),
			$sFilter, $sSort);
	}

	// Table SQL with List page filter
	function SelectSQL() {
		$sFilter = $this->getSessionWhere();
		if ($this->CurrentFilter <> "") {
			if ($sFilter <> "") $sFilter = "(" . $sFilter . ") AND ";
			$sFilter .= "(" . $this->CurrentFilter . ")";
		}
		$sFilter = $this->ApplyUserIDFilters($sFilter);
		$sSort = $this->getSessionOrderBy();
		return ew_BuildSelectSql($this->SqlSelect(), $this->SqlWhere(), $this->SqlGroupBy(),
			$this->SqlHaving(), $this->SqlOrderBy(), $sFilter, $sSort);
	}

	// Try to get record count
	function TryGetRecordCount($sSql) {
		global $conn;
		$cnt = -1;
		if ($this->TableType == 'TABLE' || $this->TableType == 'VIEW') {
			$sSql = "SELECT COUNT(*) FROM" . substr($sSql, 13);
		} else {
			$sSql = "SELECT COUNT(*) FROM (" . $sSql . ") EW_COUNT_TABLE";
		}
		if ($rs = $conn->Execute($sSql)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->Close();
			}
		}
		return intval($cnt);
	}

	// Get record count based on filter (for detail record count in master table pages)
	function LoadRecordCount($sFilter) {
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $sFilter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$sSql = $this->SQL();
		$cnt = $this->TryGetRecordCount($sSql);
		if ($cnt == -1) {
			if ($rs = $this->LoadRs($this->CurrentFilter)) {
				$cnt = $rs->RecordCount();
				$rs->Close();
			}
		}
		$this->CurrentFilter = $origFilter;
		return intval($cnt);
	}

	// Get record count (for current List page)
	function SelectRecordCount() {
		global $conn;
		$origFilter = $this->CurrentFilter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$sSql = $this->SelectSQL();
		$cnt = $this->TryGetRecordCount($sSql);
		if ($cnt == -1) {
			if ($rs = $conn->Execute($this->SelectSQL())) {
				$cnt = $rs->RecordCount();
				$rs->Close();
			}
		}
		$this->CurrentFilter = $origFilter;
		return intval($cnt);
	}

	// INSERT statement
	function InsertSQL(&$rs) {
		global $conn;
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			$names .= $this->fields[$name]->FldExpression . ",";
			$values .= ew_QuotedValue($value, $this->fields[$name]->FldDataType) . ",";
		}
		if (substr($names, -1) == ",") $names = substr($names, 0, strlen($names)-1);
		if (substr($values, -1) == ",") $values = substr($values, 0, strlen($values)-1);
		return "INSERT INTO `p_villages` ($names) VALUES ($values)";
	}

	// UPDATE statement
	function UpdateSQL(&$rs) {
		global $conn;
		$SQL = "UPDATE `p_villages` SET ";
		foreach ($rs as $name => $value) {
			$SQL .= $this->fields[$name]->FldExpression . "=";
			$SQL .= ew_QuotedValue($value, $this->fields[$name]->FldDataType) . ",";
		}
		if (substr($SQL, -1) == ",") $SQL = substr($SQL, 0, strlen($SQL)-1);
		if ($this->CurrentFilter <> "")	$SQL .= " WHERE " . $this->CurrentFilter;
		return $SQL;
	}

	// DELETE statement
	function DeleteSQL(&$rs) {
		$SQL = "DELETE FROM `p_villages` WHERE ";
		$SQL .= ew_QuotedName('id') . '=' . ew_QuotedValue($rs['id'], $this->id->FldDataType) . ' AND ';
		if (substr($SQL, -5) == " AND ") $SQL = substr($SQL, 0, strlen($SQL)-5);
		if ($this->CurrentFilter <> "")	$SQL .= " AND " . $this->CurrentFilter;
		return $SQL;
	}

	// Key filter WHERE clause
	function SqlKeyFilter() {
		return "`id` = @id@";
	}

	// Key filter
	function KeyFilter() {
		$sKeyFilter = $this->SqlKeyFilter();
		if (!is_numeric($this->id->CurrentValue))
			$sKeyFilter = "0=1"; // Invalid key
		$sKeyFilter = str_replace("@id@", ew_AdjustSql($this->id->CurrentValue), $sKeyFilter); // Replace key value
		return $sKeyFilter;
	}

	// Return page URL
	function getReturnUrl() {
		$name = EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_RETURN_URL;

		// Get referer URL automatically
		if (ew_ServerVar("HTTP_REFERER") <> "" && ew_ReferPage() <> ew_CurrentPage() && ew_ReferPage() <> "login.php") // Referer not same page or login page
			$_SESSION[$name] = ew_ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] <> "") {
			return $_SESSION[$name];
		} else {
			return "p_villageslist.php";
		}
	}

	function setReturnUrl($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_RETURN_URL] = $v;
	}

	// List URL
	function ListUrl() {
		return "p_villageslist.php";
	}

	// View URL
	function ViewUrl() {
		return $this->KeyUrl("p_villagesview.php", $this->UrlParm());
	}

	// Add URL
	function AddUrl() {
		$AddUrl = "p_villagesadd.php";
		$sUrlParm = $this->UrlParm();
		if ($sUrlParm <> "")
			$AddUrl .= "?" . $sUrlParm;
		return $AddUrl;
	}

	// Edit URL
	function EditUrl() {
		return $this->KeyUrl("p_villagesedit.php", $this->UrlParm());
	}

	// Inline edit URL
	function InlineEditUrl() {
		return $this->KeyUrl(ew_CurrentPage(), $this->UrlParm("a=edit"));
	}

	// Copy URL
	function CopyUrl() {
		return $this->KeyUrl("p_villagesadd.php", $this->UrlParm());
	}

	// Inline copy URL
	function InlineCopyUrl() {
		return $this->KeyUrl(ew_CurrentPage(), $this->UrlParm("a=copy"));
	}

	// Delete URL
	function DeleteUrl() {
		return $this->KeyUrl("p_villagesdelete.php", $this->UrlParm());
	}

	// Add key value to URL
	function KeyUrl($url, $parm = "") {
		$sUrl = $url . "?";
		if ($parm <> "") $sUrl .= $parm . "&";
		if (!is_null($this->id->CurrentValue)) {
			$sUrl .= "id=" . urlencode($this->id->CurrentValue);
		} else {
			return "javascript:alert(ewLanguage.Phrase(\"InvalidRecord\"));";
		}
		return $sUrl;
	}

	// Sort URL
	function SortUrl(&$fld) {
		if ($this->CurrentAction <> "" || $this->Export <> "" ||
			in_array($fld->FldType, array(128, 204, 205))) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$sUrlParm = $this->UrlParm("order=" . urlencode($fld->FldName) . "&ordertype=" . $fld->ReverseSort());
			return ew_CurrentPage() . "?" . $sUrlParm;
		} else {
			return "";
		}
	}

	// Add URL parameter
	function UrlParm($parm = "") {
		$UrlParm = ($this->UseTokenInUrl) ? "t=p_villages" : "";
		if ($parm <> "") {
			if ($UrlParm <> "")
				$UrlParm .= "&";
			$UrlParm .= $parm;
		}
		return $UrlParm;
	}

	// Load rows based on filter
	function &LoadRs($sFilter) {
		global $conn;

		// Set up filter (SQL WHERE clause) and get return SQL
		$this->CurrentFilter = $sFilter;
		$sSql = $this->SQL();
		return $conn->Execute($sSql);
	}

	// Load row values from recordset
	function LoadListRowValues(&$rs) {
		$this->id->setDbValue($rs->fields('id'));
		$this->rel_x->setDbValue($rs->fields('rel_x'));
		$this->rel_y->setDbValue($rs->fields('rel_y'));
		$this->field_maps_id->setDbValue($rs->fields('field_maps_id'));
		$this->image_num->setDbValue($rs->fields('image_num'));
		$this->rand_num->setDbValue($rs->fields('rand_num'));
		$this->parent_id->setDbValue($rs->fields('parent_id'));
		$this->tribe_id->setDbValue($rs->fields('tribe_id'));
		$this->player_id->setDbValue($rs->fields('player_id'));
		$this->alliance_id->setDbValue($rs->fields('alliance_id'));
		$this->player_name->setDbValue($rs->fields('player_name'));
		$this->village_name->setDbValue($rs->fields('village_name'));
		$this->alliance_name->setDbValue($rs->fields('alliance_name'));
		$this->is_capital->setDbValue($rs->fields('is_capital'));
		$this->is_special_village->setDbValue($rs->fields('is_special_village'));
		$this->is_oasis->setDbValue($rs->fields('is_oasis'));
		$this->people_count->setDbValue($rs->fields('people_count'));
		$this->crop_consumption->setDbValue($rs->fields('crop_consumption'));
		$this->time_consume_percent->setDbValue($rs->fields('time_consume_percent'));
		$this->offer_merchants_count->setDbValue($rs->fields('offer_merchants_count'));
		$this->resources->setDbValue($rs->fields('resources'));
		$this->cp->setDbValue($rs->fields('cp'));
		$this->buildings->setDbValue($rs->fields('buildings'));
		$this->troops_training->setDbValue($rs->fields('troops_training'));
		$this->troops_num->setDbValue($rs->fields('troops_num'));
		$this->troops_out_num->setDbValue($rs->fields('troops_out_num'));
		$this->troops_intrap_num->setDbValue($rs->fields('troops_intrap_num'));
		$this->troops_out_intrap_num->setDbValue($rs->fields('troops_out_intrap_num'));
		$this->troops_trapped_num->setDbValue($rs->fields('troops_trapped_num'));
		$this->allegiance_percent->setDbValue($rs->fields('allegiance_percent'));
		$this->child_villages_id->setDbValue($rs->fields('child_villages_id'));
		$this->village_oases_id->setDbValue($rs->fields('village_oases_id'));
		$this->creation_date->setDbValue($rs->fields('creation_date'));
		$this->update_key->setDbValue($rs->fields('update_key'));
		$this->last_update_date->setDbValue($rs->fields('last_update_date'));
	}

	// Render list row values
	function RenderListRow() {
		global $conn, $Security;

		// Call Row Rendering event
		$this->Row_Rendering();

   // Common render codes
		// id

		$this->id->CellCssStyle = ""; $this->id->CellCssClass = "";
		$this->id->CellAttrs = array(); $this->id->ViewAttrs = array(); $this->id->EditAttrs = array();

		// player_name
		$this->player_name->CellCssStyle = ""; $this->player_name->CellCssClass = "";
		$this->player_name->CellAttrs = array(); $this->player_name->ViewAttrs = array(); $this->player_name->EditAttrs = array();

		// village_name
		$this->village_name->CellCssStyle = ""; $this->village_name->CellCssClass = "";
		$this->village_name->CellAttrs = array(); $this->village_name->ViewAttrs = array(); $this->village_name->EditAttrs = array();

		// is_capital
		$this->is_capital->CellCssStyle = ""; $this->is_capital->CellCssClass = "";
		$this->is_capital->CellAttrs = array(); $this->is_capital->ViewAttrs = array(); $this->is_capital->EditAttrs = array();

		// is_special_village
		$this->is_special_village->CellCssStyle = ""; $this->is_special_village->CellCssClass = "";
		$this->is_special_village->CellAttrs = array(); $this->is_special_village->ViewAttrs = array(); $this->is_special_village->EditAttrs = array();

		// people_count
		$this->people_count->CellCssStyle = ""; $this->people_count->CellCssClass = "";
		$this->people_count->CellAttrs = array(); $this->people_count->ViewAttrs = array(); $this->people_count->EditAttrs = array();

		// crop_consumption
		$this->crop_consumption->CellCssStyle = ""; $this->crop_consumption->CellCssClass = "";
		$this->crop_consumption->CellAttrs = array(); $this->crop_consumption->ViewAttrs = array(); $this->crop_consumption->EditAttrs = array();

		// resources
		$this->resources->CellCssStyle = ""; $this->resources->CellCssClass = "";
		$this->resources->CellAttrs = array(); $this->resources->ViewAttrs = array(); $this->resources->EditAttrs = array();

		// cp
		$this->cp->CellCssStyle = ""; $this->cp->CellCssClass = "";
		$this->cp->CellAttrs = array(); $this->cp->ViewAttrs = array(); $this->cp->EditAttrs = array();

		// buildings
		$this->buildings->CellCssStyle = ""; $this->buildings->CellCssClass = "";
		$this->buildings->CellAttrs = array(); $this->buildings->ViewAttrs = array(); $this->buildings->EditAttrs = array();

		// troops_num
		$this->troops_num->CellCssStyle = ""; $this->troops_num->CellCssClass = "";
		$this->troops_num->CellAttrs = array(); $this->troops_num->ViewAttrs = array(); $this->troops_num->EditAttrs = array();

		// id
		$this->id->ViewValue = $this->id->CurrentValue;
		$this->id->CssStyle = "";
		$this->id->CssClass = "";
		$this->id->ViewCustomAttributes = "";

		// player_name
		$this->player_name->ViewValue = $this->player_name->CurrentValue;
		$this->player_name->CssStyle = "";
		$this->player_name->CssClass = "";
		$this->player_name->ViewCustomAttributes = "";

		// village_name
		$this->village_name->ViewValue = $this->village_name->CurrentValue;
		$this->village_name->CssStyle = "";
		$this->village_name->CssClass = "";
		$this->village_name->ViewCustomAttributes = "";

		// is_capital
		$this->is_capital->ViewValue = $this->is_capital->CurrentValue;
		$this->is_capital->CssStyle = "";
		$this->is_capital->CssClass = "";
		$this->is_capital->ViewCustomAttributes = "";

		// is_special_village
		$this->is_special_village->ViewValue = $this->is_special_village->CurrentValue;
		$this->is_special_village->CssStyle = "";
		$this->is_special_village->CssClass = "";
		$this->is_special_village->ViewCustomAttributes = "";

		// people_count
		$this->people_count->ViewValue = $this->people_count->CurrentValue;
		$this->people_count->CssStyle = "";
		$this->people_count->CssClass = "";
		$this->people_count->ViewCustomAttributes = "";

		// crop_consumption
		$this->crop_consumption->ViewValue = $this->crop_consumption->CurrentValue;
		$this->crop_consumption->CssStyle = "";
		$this->crop_consumption->CssClass = "";
		$this->crop_consumption->ViewCustomAttributes = "";

		// resources
		$this->resources->ViewValue = $this->resources->CurrentValue;
		$this->resources->CssStyle = "";
		$this->resources->CssClass = "";
		$this->resources->ViewCustomAttributes = "";

		// cp
		$this->cp->ViewValue = $this->cp->CurrentValue;
		$this->cp->CssStyle = "";
		$this->cp->CssClass = "";
		$this->cp->ViewCustomAttributes = "";

		// buildings
		$this->buildings->ViewValue = $this->buildings->CurrentValue;
		$this->buildings->CssStyle = "";
		$this->buildings->CssClass = "";
		$this->buildings->ViewCustomAttributes = "";

		// troops_num
		$this->troops_num->ViewValue = $this->troops_num->CurrentValue;
		$this->troops_num->CssStyle = "";
		$this->troops_num->CssClass = "";
		$this->troops_num->ViewCustomAttributes = "";

		// id
		$this->id->HrefValue = "";
		$this->id->TooltipValue = "";

		// player_name
		$this->player_name->HrefValue = "";
		$this->player_name->TooltipValue = "";

		// village_name
		$this->village_name->HrefValue = "";
		$this->village_name->TooltipValue = "";

		// is_capital
		$this->is_capital->HrefValue = "";
		$this->is_capital->TooltipValue = "";

		// is_special_village
		$this->is_special_village->HrefValue = "";
		$this->is_special_village->TooltipValue = "";

		// people_count
		$this->people_count->HrefValue = "";
		$this->people_count->TooltipValue = "";

		// crop_consumption
		$this->crop_consumption->HrefValue = "";
		$this->crop_consumption->TooltipValue = "";

		// resources
		$this->resources->HrefValue = "";
		$this->resources->TooltipValue = "";

		// cp
		$this->cp->HrefValue = "";
		$this->cp->TooltipValue = "";

		// buildings
		$this->buildings->HrefValue = "";
		$this->buildings->TooltipValue = "";

		// troops_num
		$this->troops_num->HrefValue = "";
		$this->troops_num->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	function AggregateListRowValues() {
	}

	// Aggregate list row (for rendering)
	function AggregateListRow() {
	}

	// Row styles
	function RowStyles() {
		$sAtt = "";
		$sStyle = trim($this->CssStyle);
		if (@$this->RowAttrs["style"] <> "")
			$sStyle .= " " . $this->RowAttrs["style"];
		$sClass = trim($this->CssClass);
		if (@$this->RowAttrs["class"] <> "")
			$sClass .= " " . $this->RowAttrs["class"];
		if (trim($sStyle) <> "")
			$sAtt .= " style=\"" . trim($sStyle) . "\"";
		if (trim($sClass) <> "")
			$sAtt .= " class=\"" . trim($sClass) . "\"";
		return $sAtt;
	}

	// Row attributes
	function RowAttributes() {
		$sAtt = $this->RowStyles();
		if ($this->Export == "") {
			foreach ($this->RowAttrs as $k => $v) {
				if ($k <> "class" && $k <> "style" && trim($v) <> "")
					$sAtt .= " " . $k . "=\"" . trim($v) . "\"";
			}
		}
		return $sAtt;
	}

	// Field object by name
	function fields($fldname) {
		return $this->fields[$fldname];
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here	
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//global $MyTable;
		//$MyTable->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here	
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here	
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here	
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>); 

	}

	// Row Inserting event
	function Row_Inserting(&$rs) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted(&$rs) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating(&$rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated(&$rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict(&$rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending(&$Email, &$Args) {

		//var_dump($Email); var_dump($Args); exit();
		return TRUE;
	}
}
?>
