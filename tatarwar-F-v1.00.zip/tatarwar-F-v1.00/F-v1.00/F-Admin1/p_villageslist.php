<?php
session_start(); // Initialize Session data
ob_start(); // Turn on output buffering
?>
<?php include "ewcfg7.php" ?>
<?php include "ewmysql7.php" ?>
<?php include "phpfn7.php" ?>
<?php include "p_villagesinfo.php" ?>
<?php include "userfn7.php" ?>
<?php

// Create page object
$p_villages_list = new cp_villages_list();
$Page =& $p_villages_list;

// Page init
$p_villages_list->Page_Init();

// Page main
$p_villages_list->Page_Main();
?>
<?php include "header.php" ?>
<?php if ($p_villages->Export == "") { ?>
<script type="text/javascript">
<!--

// Create page object
var p_villages_list = new ew_Page("p_villages_list");

// page properties
p_villages_list.PageID = "list"; // page ID
p_villages_list.FormID = "fp_villageslist"; // form ID
var EW_PAGE_ID = p_villages_list.PageID; // for backward compatibility

// extend page with validate function for search
p_villages_list.ValidateSearch = function(fobj) {
	ew_PostAutoSuggest(fobj);
	if (this.ValidateRequired) {
		var infix = "";
		elm = fobj.elements["x" + infix + "_id"];
		if (elm && !ew_CheckInteger(elm.value))
			return ew_OnError(this, elm, "<?php echo ew_JsEncode2($p_villages->id->FldErrMsg()) ?>");

		// Call Form Custom Validate event
		if (!this.Form_CustomValidate(fobj))
			return false;
	}
	for (var i=0; i<fobj.elements.length; i++) {
		var elem = fobj.elements[i];
		if (elem.name.substring(0,2) == "s_" || elem.name.substring(0,3) == "sv_")
			elem.value = "";
	}
	return true;
}

// extend page with Form_CustomValidate function
p_villages_list.Form_CustomValidate =  
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }
<?php if (EW_CLIENT_VALIDATE) { ?>
p_villages_list.ValidateRequired = true; // uses JavaScript validation
<?php } else { ?>
p_villages_list.ValidateRequired = false; // no JavaScript validation
<?php } ?>

//-->
</script>
<script type="text/javascript">
<!--
var ew_DHTMLEditors = [];

//-->
</script>
<script language="JavaScript" type="text/javascript">
<!--

// Write your client script here, no need to add script tags.
// To include another .js script, use:
// ew_ClientScriptInclude("my_javascript.js"); 
//-->

</script>
<?php } ?>
<?php if ($p_villages->Export == "") { ?>
<?php } ?>
<?php
	$bSelectLimit = EW_SELECT_LIMIT;
	if ($bSelectLimit) {
		$p_villages_list->lTotalRecs = $p_villages->SelectRecordCount();
	} else {
		if ($rs = $p_villages_list->LoadRecordset())
			$p_villages_list->lTotalRecs = $rs->RecordCount();
	}
	$p_villages_list->lStartRec = 1;
	if ($p_villages_list->lDisplayRecs <= 0 || ($p_villages->Export <> "" && $p_villages->ExportAll)) // Display all records
		$p_villages_list->lDisplayRecs = $p_villages_list->lTotalRecs;
	if (!($p_villages->Export <> "" && $p_villages->ExportAll))
		$p_villages_list->SetUpStartRec(); // Set up start record position
	if ($bSelectLimit)
		$rs = $p_villages_list->LoadRecordset($p_villages_list->lStartRec-1, $p_villages_list->lDisplayRecs);
?>
<p><span class="phpmaker" style="white-space: nowrap;"><?php echo $Language->Phrase("TblTypeTABLE") ?><?php echo $p_villages->TableCaption() ?>
</span></p>
<?php if ($Security->IsLoggedIn()) { ?>
<?php if ($p_villages->Export == "" && $p_villages->CurrentAction == "") { ?>
<a href="javascript:ew_ToggleSearchPanel(p_villages_list);" style="text-decoration: none;"><img id="p_villages_list_SearchImage" src="images/collapse.gif" alt="" width="9" height="9" border="0"></a><span class="phpmaker">&nbsp;<?php echo $Language->Phrase("Search") ?></span><br>
<div id="p_villages_list_SearchPanel">
<form name="fp_villageslistsrch" id="fp_villageslistsrch" class="ewForm" action="<?php echo ew_CurrentPage() ?>" onsubmit="return p_villages_list.ValidateSearch(this);">
<input type="hidden" id="t" name="t" value="p_villages">
<?php
if ($gsSearchError == "")
	$p_villages_list->LoadAdvancedSearch(); // Load advanced search

// Render for search
$p_villages->RowType = EW_ROWTYPE_SEARCH;

// Render row
$p_villages_list->RenderRow();
?>
<table class="ewBasicSearch">
	<tr>
		<td><span class="phpmaker"><?php echo $p_villages->id->FldCaption() ?></span></td>
		<td><span class="ewSearchOpr"><?php echo $Language->Phrase("=") ?><input type="hidden" name="z_id" id="z_id" value="="></span></td>
		<td>			
			<div style="white-space: nowrap;">
				<span class="phpmaker" style="float: left;">
<input type="text" name="x_id" id="x_id" title="<?php echo $p_villages->id->FldTitle() ?>" value="<?php echo $p_villages->id->EditValue ?>"<?php echo $p_villages->id->EditAttributes() ?>>
</span>
			</div>
		</td>
	</tr>
	<tr>
		<td><span class="phpmaker"><?php echo $p_villages->player_name->FldCaption() ?></span></td>
		<td><span class="ewSearchOpr"><?php echo $Language->Phrase("LIKE") ?><input type="hidden" name="z_player_name" id="z_player_name" value="LIKE"></span></td>
		<td>			
			<div style="white-space: nowrap;">
				<span class="phpmaker" style="float: left;">
<textarea name="x_player_name" id="x_player_name" title="<?php echo $p_villages->player_name->FldTitle() ?>" cols="35" rows="4"<?php echo $p_villages->player_name->EditAttributes() ?>><?php echo $p_villages->player_name->EditValue ?></textarea>
</span>
			</div>
		</td>
	</tr>
	<tr>
		<td><span class="phpmaker"><?php echo $p_villages->village_name->FldCaption() ?></span></td>
		<td><span class="ewSearchOpr"><?php echo $Language->Phrase("LIKE") ?><input type="hidden" name="z_village_name" id="z_village_name" value="LIKE"></span></td>
		<td>			
			<div style="white-space: nowrap;">
				<span class="phpmaker" style="float: left;">
<input type="text" name="x_village_name" id="x_village_name" title="<?php echo $p_villages->village_name->FldTitle() ?>" size="30" maxlength="255" value="<?php echo $p_villages->village_name->EditValue ?>"<?php echo $p_villages->village_name->EditAttributes() ?>>
</span>
			</div>
		</td>
	</tr>
</table>
<table class="ewBasicSearch">
	<tr>
		<td><span class="phpmaker">
			<input type="text" name="<?php echo EW_TABLE_BASIC_SEARCH ?>" id="<?php echo EW_TABLE_BASIC_SEARCH ?>" size="20" value="<?php echo ew_HtmlEncode($p_villages->getSessionBasicSearchKeyword()) ?>">
			<input type="Submit" name="Submit" id="Submit" value="<?php echo ew_BtnCaption($Language->Phrase("QuickSearchBtn")) ?>">&nbsp;
			<a href="<?php echo $p_villages_list->PageUrl() ?>cmd=reset"><?php echo $Language->Phrase("ShowAll") ?></a>&nbsp;
		</span></td>
	</tr>
	<tr>
	<td><span class="phpmaker"><label><input type="radio" name="<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>" id="<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>" value=""<?php if ($p_villages->getSessionBasicSearchType() == "") { ?> checked="checked"<?php } ?>><?php echo $Language->Phrase("ExactPhrase") ?></label>&nbsp;&nbsp;<label><input type="radio" name="<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>" id="<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>" value="AND"<?php if ($p_villages->getSessionBasicSearchType() == "AND") { ?> checked="checked"<?php } ?>><?php echo $Language->Phrase("AllWord") ?></label>&nbsp;&nbsp;<label><input type="radio" name="<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>" id="<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>" value="OR"<?php if ($p_villages->getSessionBasicSearchType() == "OR") { ?> checked="checked"<?php } ?>><?php echo $Language->Phrase("AnyWord") ?></label></span></td>
	</tr>
</table>
</form>
</div>
<?php } ?>
<?php } ?>
<?php
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
$p_villages_list->ShowMessage();
?>
<br>
<table cellspacing="0" class="ewGrid"><tr><td class="ewGridContent">
<form name="fp_villageslist" id="fp_villageslist" class="ewForm" action="" method="post">
<div id="gmp_p_villages" class="ewGridMiddlePanel">
<?php if ($p_villages_list->lTotalRecs > 0) { ?>
<table cellspacing="0" rowhighlightclass="ewTableHighlightRow" rowselectclass="ewTableSelectRow" roweditclass="ewTableEditRow" class="ewTable ewTableSeparate">
<?php echo $p_villages->TableCustomInnerHtml ?>
<thead><!-- Table header -->
	<tr class="ewTableHeader">
<?php

// Render list options
$p_villages_list->RenderListOptions();

// Render list options (header, left)
$p_villages_list->ListOptions->Render("header", "left");
?>
<?php if ($p_villages->id->Visible) { // id ?>
	<?php if ($p_villages->SortUrl($p_villages->id) == "") { ?>
		<td><?php echo $p_villages->id->FldCaption() ?></td>
	<?php } else { ?>
		<td><div class="ewPointer" onmousedown="ew_Sort(event,'<?php echo $p_villages->SortUrl($p_villages->id) ?>',1);">
			<table cellspacing="0" class="ewTableHeaderBtn"><thead><tr><td><?php echo $p_villages->id->FldCaption() ?><?php echo $Language->Phrase("SrchLegend") ?></td><td style="width: 10px;"><?php if ($p_villages->id->getSort() == "ASC") { ?><img src="images/sortup.gif" width="10" height="9" border="0"><?php } elseif ($p_villages->id->getSort() == "DESC") { ?><img src="images/sortdown.gif" width="10" height="9" border="0"><?php } ?></td></tr></thead></table>
		</div></td>		
	<?php } ?>
<?php } ?>		
<?php if ($p_villages->player_name->Visible) { // player_name ?>
	<?php if ($p_villages->SortUrl($p_villages->player_name) == "") { ?>
		<td><?php echo $p_villages->player_name->FldCaption() ?></td>
	<?php } else { ?>
		<td><div class="ewPointer" onmousedown="ew_Sort(event,'<?php echo $p_villages->SortUrl($p_villages->player_name) ?>',1);">
			<table cellspacing="0" class="ewTableHeaderBtn"><thead><tr><td><?php echo $p_villages->player_name->FldCaption() ?><?php echo $Language->Phrase("SrchLegend") ?></td><td style="width: 10px;"><?php if ($p_villages->player_name->getSort() == "ASC") { ?><img src="images/sortup.gif" width="10" height="9" border="0"><?php } elseif ($p_villages->player_name->getSort() == "DESC") { ?><img src="images/sortdown.gif" width="10" height="9" border="0"><?php } ?></td></tr></thead></table>
		</div></td>		
	<?php } ?>
<?php } ?>		
<?php if ($p_villages->village_name->Visible) { // village_name ?>
	<?php if ($p_villages->SortUrl($p_villages->village_name) == "") { ?>
		<td><?php echo $p_villages->village_name->FldCaption() ?></td>
	<?php } else { ?>
		<td><div class="ewPointer" onmousedown="ew_Sort(event,'<?php echo $p_villages->SortUrl($p_villages->village_name) ?>',1);">
			<table cellspacing="0" class="ewTableHeaderBtn"><thead><tr><td><?php echo $p_villages->village_name->FldCaption() ?><?php echo $Language->Phrase("SrchLegend") ?></td><td style="width: 10px;"><?php if ($p_villages->village_name->getSort() == "ASC") { ?><img src="images/sortup.gif" width="10" height="9" border="0"><?php } elseif ($p_villages->village_name->getSort() == "DESC") { ?><img src="images/sortdown.gif" width="10" height="9" border="0"><?php } ?></td></tr></thead></table>
		</div></td>		
	<?php } ?>
<?php } ?>		
<?php if ($p_villages->is_capital->Visible) { // is_capital ?>
	<?php if ($p_villages->SortUrl($p_villages->is_capital) == "") { ?>
		<td><?php echo $p_villages->is_capital->FldCaption() ?></td>
	<?php } else { ?>
		<td><div class="ewPointer" onmousedown="ew_Sort(event,'<?php echo $p_villages->SortUrl($p_villages->is_capital) ?>',1);">
			<table cellspacing="0" class="ewTableHeaderBtn"><thead><tr><td><?php echo $p_villages->is_capital->FldCaption() ?><?php echo $Language->Phrase("SrchLegend") ?></td><td style="width: 10px;"><?php if ($p_villages->is_capital->getSort() == "ASC") { ?><img src="images/sortup.gif" width="10" height="9" border="0"><?php } elseif ($p_villages->is_capital->getSort() == "DESC") { ?><img src="images/sortdown.gif" width="10" height="9" border="0"><?php } ?></td></tr></thead></table>
		</div></td>		
	<?php } ?>
<?php } ?>		
<?php if ($p_villages->is_special_village->Visible) { // is_special_village ?>
	<?php if ($p_villages->SortUrl($p_villages->is_special_village) == "") { ?>
		<td><?php echo $p_villages->is_special_village->FldCaption() ?></td>
	<?php } else { ?>
		<td><div class="ewPointer" onmousedown="ew_Sort(event,'<?php echo $p_villages->SortUrl($p_villages->is_special_village) ?>',1);">
			<table cellspacing="0" class="ewTableHeaderBtn"><thead><tr><td><?php echo $p_villages->is_special_village->FldCaption() ?><?php echo $Language->Phrase("SrchLegend") ?></td><td style="width: 10px;"><?php if ($p_villages->is_special_village->getSort() == "ASC") { ?><img src="images/sortup.gif" width="10" height="9" border="0"><?php } elseif ($p_villages->is_special_village->getSort() == "DESC") { ?><img src="images/sortdown.gif" width="10" height="9" border="0"><?php } ?></td></tr></thead></table>
		</div></td>		
	<?php } ?>
<?php } ?>		
<?php if ($p_villages->people_count->Visible) { // people_count ?>
	<?php if ($p_villages->SortUrl($p_villages->people_count) == "") { ?>
		<td><?php echo $p_villages->people_count->FldCaption() ?></td>
	<?php } else { ?>
		<td><div class="ewPointer" onmousedown="ew_Sort(event,'<?php echo $p_villages->SortUrl($p_villages->people_count) ?>',1);">
			<table cellspacing="0" class="ewTableHeaderBtn"><thead><tr><td><?php echo $p_villages->people_count->FldCaption() ?><?php echo $Language->Phrase("SrchLegend") ?></td><td style="width: 10px;"><?php if ($p_villages->people_count->getSort() == "ASC") { ?><img src="images/sortup.gif" width="10" height="9" border="0"><?php } elseif ($p_villages->people_count->getSort() == "DESC") { ?><img src="images/sortdown.gif" width="10" height="9" border="0"><?php } ?></td></tr></thead></table>
		</div></td>		
	<?php } ?>
<?php } ?>		
<?php if ($p_villages->crop_consumption->Visible) { // crop_consumption ?>
	<?php if ($p_villages->SortUrl($p_villages->crop_consumption) == "") { ?>
		<td><?php echo $p_villages->crop_consumption->FldCaption() ?></td>
	<?php } else { ?>
		<td><div class="ewPointer" onmousedown="ew_Sort(event,'<?php echo $p_villages->SortUrl($p_villages->crop_consumption) ?>',1);">
			<table cellspacing="0" class="ewTableHeaderBtn"><thead><tr><td><?php echo $p_villages->crop_consumption->FldCaption() ?><?php echo $Language->Phrase("SrchLegend") ?></td><td style="width: 10px;"><?php if ($p_villages->crop_consumption->getSort() == "ASC") { ?><img src="images/sortup.gif" width="10" height="9" border="0"><?php } elseif ($p_villages->crop_consumption->getSort() == "DESC") { ?><img src="images/sortdown.gif" width="10" height="9" border="0"><?php } ?></td></tr></thead></table>
		</div></td>		
	<?php } ?>
<?php } ?>		
<?php if ($p_villages->resources->Visible) { // resources ?>
	<?php if ($p_villages->SortUrl($p_villages->resources) == "") { ?>
		<td><?php echo $p_villages->resources->FldCaption() ?></td>
	<?php } else { ?>
		<td><div class="ewPointer" onmousedown="ew_Sort(event,'<?php echo $p_villages->SortUrl($p_villages->resources) ?>',1);">
			<table cellspacing="0" class="ewTableHeaderBtn"><thead><tr><td><?php echo $p_villages->resources->FldCaption() ?><?php echo $Language->Phrase("SrchLegend") ?></td><td style="width: 10px;"><?php if ($p_villages->resources->getSort() == "ASC") { ?><img src="images/sortup.gif" width="10" height="9" border="0"><?php } elseif ($p_villages->resources->getSort() == "DESC") { ?><img src="images/sortdown.gif" width="10" height="9" border="0"><?php } ?></td></tr></thead></table>
		</div></td>		
	<?php } ?>
<?php } ?>		
<?php if ($p_villages->cp->Visible) { // cp ?>
	<?php if ($p_villages->SortUrl($p_villages->cp) == "") { ?>
		<td><?php echo $p_villages->cp->FldCaption() ?></td>
	<?php } else { ?>
		<td><div class="ewPointer" onmousedown="ew_Sort(event,'<?php echo $p_villages->SortUrl($p_villages->cp) ?>',1);">
			<table cellspacing="0" class="ewTableHeaderBtn"><thead><tr><td><?php echo $p_villages->cp->FldCaption() ?><?php echo $Language->Phrase("SrchLegend") ?></td><td style="width: 10px;"><?php if ($p_villages->cp->getSort() == "ASC") { ?><img src="images/sortup.gif" width="10" height="9" border="0"><?php } elseif ($p_villages->cp->getSort() == "DESC") { ?><img src="images/sortdown.gif" width="10" height="9" border="0"><?php } ?></td></tr></thead></table>
		</div></td>		
	<?php } ?>
<?php } ?>		
<?php if ($p_villages->buildings->Visible) { // buildings ?>
	<?php if ($p_villages->SortUrl($p_villages->buildings) == "") { ?>
		<td><?php echo $p_villages->buildings->FldCaption() ?></td>
	<?php } else { ?>
		<td><div class="ewPointer" onmousedown="ew_Sort(event,'<?php echo $p_villages->SortUrl($p_villages->buildings) ?>',1);">
			<table cellspacing="0" class="ewTableHeaderBtn"><thead><tr><td><?php echo $p_villages->buildings->FldCaption() ?><?php echo $Language->Phrase("SrchLegend") ?></td><td style="width: 10px;"><?php if ($p_villages->buildings->getSort() == "ASC") { ?><img src="images/sortup.gif" width="10" height="9" border="0"><?php } elseif ($p_villages->buildings->getSort() == "DESC") { ?><img src="images/sortdown.gif" width="10" height="9" border="0"><?php } ?></td></tr></thead></table>
		</div></td>		
	<?php } ?>
<?php } ?>		
<?php if ($p_villages->troops_num->Visible) { // troops_num ?>
	<?php if ($p_villages->SortUrl($p_villages->troops_num) == "") { ?>
		<td><?php echo $p_villages->troops_num->FldCaption() ?></td>
	<?php } else { ?>
		<td><div class="ewPointer" onmousedown="ew_Sort(event,'<?php echo $p_villages->SortUrl($p_villages->troops_num) ?>',1);">
			<table cellspacing="0" class="ewTableHeaderBtn"><thead><tr><td><?php echo $p_villages->troops_num->FldCaption() ?><?php echo $Language->Phrase("SrchLegend") ?></td><td style="width: 10px;"><?php if ($p_villages->troops_num->getSort() == "ASC") { ?><img src="images/sortup.gif" width="10" height="9" border="0"><?php } elseif ($p_villages->troops_num->getSort() == "DESC") { ?><img src="images/sortdown.gif" width="10" height="9" border="0"><?php } ?></td></tr></thead></table>
		</div></td>		
	<?php } ?>
<?php } ?>		
<?php

// Render list options (header, right)
$p_villages_list->ListOptions->Render("header", "right");
?>
	</tr>
</thead>
<?php
if ($p_villages->ExportAll && $p_villages->Export <> "") {
	$p_villages_list->lStopRec = $p_villages_list->lTotalRecs;
} else {
	$p_villages_list->lStopRec = $p_villages_list->lStartRec + $p_villages_list->lDisplayRecs - 1; // Set the last record to display
}
$p_villages_list->lRecCount = $p_villages_list->lStartRec - 1;
if ($rs && !$rs->EOF) {
	$rs->MoveFirst();
	if (!$bSelectLimit && $p_villages_list->lStartRec > 1)
		$rs->Move($p_villages_list->lStartRec - 1);
}

// Initialize aggregate
$p_villages->RowType = EW_ROWTYPE_AGGREGATEINIT;
$p_villages_list->RenderRow();
$p_villages_list->lRowCnt = 0;
while (($p_villages->CurrentAction == "gridadd" || !$rs->EOF) &&
	$p_villages_list->lRecCount < $p_villages_list->lStopRec) {
	$p_villages_list->lRecCount++;
	if (intval($p_villages_list->lRecCount) >= intval($p_villages_list->lStartRec)) {
		$p_villages_list->lRowCnt++;

	// Init row class and style
	$p_villages->CssClass = "";
	$p_villages->CssStyle = "";
	$p_villages->RowAttrs = array('onmouseover'=>'ew_MouseOver(event, this);', 'onmouseout'=>'ew_MouseOut(event, this);', 'onclick'=>'ew_Click(event, this);');
	if ($p_villages->CurrentAction == "gridadd") {
		$p_villages_list->LoadDefaultValues(); // Load default values
	} else {
		$p_villages_list->LoadRowValues($rs); // Load row values
	}
	$p_villages->RowType = EW_ROWTYPE_VIEW; // Render view

	// Render row
	$p_villages_list->RenderRow();

	// Render list options
	$p_villages_list->RenderListOptions();
?>
	<tr<?php echo $p_villages->RowAttributes() ?>>
<?php

// Render list options (body, left)
$p_villages_list->ListOptions->Render("body", "left");
?>
	<?php if ($p_villages->id->Visible) { // id ?>
		<td<?php echo $p_villages->id->CellAttributes() ?>>
<div<?php echo $p_villages->id->ViewAttributes() ?>><?php echo $p_villages->id->ListViewValue() ?></div>
</td>
	<?php } ?>
	<?php if ($p_villages->player_name->Visible) { // player_name ?>
		<td<?php echo $p_villages->player_name->CellAttributes() ?>>
<div<?php echo $p_villages->player_name->ViewAttributes() ?>><?php echo $p_villages->player_name->ListViewValue() ?></div>
</td>
	<?php } ?>
	<?php if ($p_villages->village_name->Visible) { // village_name ?>
		<td<?php echo $p_villages->village_name->CellAttributes() ?>>
<div<?php echo $p_villages->village_name->ViewAttributes() ?>><?php echo $p_villages->village_name->ListViewValue() ?></div>
</td>
	<?php } ?>
	<?php if ($p_villages->is_capital->Visible) { // is_capital ?>
		<td<?php echo $p_villages->is_capital->CellAttributes() ?>>
<div<?php echo $p_villages->is_capital->ViewAttributes() ?>><?php echo $p_villages->is_capital->ListViewValue() ?></div>
</td>
	<?php } ?>
	<?php if ($p_villages->is_special_village->Visible) { // is_special_village ?>
		<td<?php echo $p_villages->is_special_village->CellAttributes() ?>>
<div<?php echo $p_villages->is_special_village->ViewAttributes() ?>><?php echo $p_villages->is_special_village->ListViewValue() ?></div>
</td>
	<?php } ?>
	<?php if ($p_villages->people_count->Visible) { // people_count ?>
		<td<?php echo $p_villages->people_count->CellAttributes() ?>>
<div<?php echo $p_villages->people_count->ViewAttributes() ?>><?php echo $p_villages->people_count->ListViewValue() ?></div>
</td>
	<?php } ?>
	<?php if ($p_villages->crop_consumption->Visible) { // crop_consumption ?>
		<td<?php echo $p_villages->crop_consumption->CellAttributes() ?>>
<div<?php echo $p_villages->crop_consumption->ViewAttributes() ?>><?php echo $p_villages->crop_consumption->ListViewValue() ?></div>
</td>
	<?php } ?>
	<?php if ($p_villages->resources->Visible) { // resources ?>
		<td<?php echo $p_villages->resources->CellAttributes() ?>>
<div<?php echo $p_villages->resources->ViewAttributes() ?>><?php echo $p_villages->resources->ListViewValue() ?></div>
</td>
	<?php } ?>
	<?php if ($p_villages->cp->Visible) { // cp ?>
		<td<?php echo $p_villages->cp->CellAttributes() ?>>
<div<?php echo $p_villages->cp->ViewAttributes() ?>><?php echo $p_villages->cp->ListViewValue() ?></div>
</td>
	<?php } ?>
	<?php if ($p_villages->buildings->Visible) { // buildings ?>
		<td<?php echo $p_villages->buildings->CellAttributes() ?>>
<div<?php echo $p_villages->buildings->ViewAttributes() ?>><?php echo $p_villages->buildings->ListViewValue() ?></div>
</td>
	<?php } ?>
	<?php if ($p_villages->troops_num->Visible) { // troops_num ?>
		<td<?php echo $p_villages->troops_num->CellAttributes() ?>>
<div<?php echo $p_villages->troops_num->ViewAttributes() ?>><?php echo $p_villages->troops_num->ListViewValue() ?></div>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$p_villages_list->ListOptions->Render("body", "right");
?>
	</tr>
<?php
	}
	if ($p_villages->CurrentAction <> "gridadd")
		$rs->MoveNext();
}
?>
</tbody>
</table>
<?php } ?>
</div>
</form>
<?php

// Close recordset
if ($rs)
	$rs->Close();
?>
<?php if ($p_villages->Export == "") { ?>
<div class="ewGridLowerPanel">
<?php if ($p_villages->CurrentAction <> "gridadd" && $p_villages->CurrentAction <> "gridedit") { ?>
<form name="ewpagerform" id="ewpagerform" class="ewForm" action="<?php echo ew_CurrentPage() ?>">
<table border="0" cellspacing="0" cellpadding="0" class="ewPager">
	<tr>
		<td nowrap>
<?php if (!isset($p_villages_list->Pager)) $p_villages_list->Pager = new cPrevNextPager($p_villages_list->lStartRec, $p_villages_list->lDisplayRecs, $p_villages_list->lTotalRecs) ?>
<?php if ($p_villages_list->Pager->RecordCount > 0) { ?>
	<table border="0" cellspacing="0" cellpadding="0"><tr><td><span class="phpmaker"><?php echo $Language->Phrase("Page") ?>&nbsp;</span></td>
<!--first page button-->
	<?php if ($p_villages_list->Pager->FirstButton->Enabled) { ?>
	<td><a href="<?php echo $p_villages_list->PageUrl() ?>start=<?php echo $p_villages_list->Pager->FirstButton->Start ?>"><img src="images/first.gif" alt="<?php echo $Language->Phrase("PagerFirst") ?>" width="16" height="16" border="0"></a></td>
	<?php } else { ?>
	<td><img src="images/firstdisab.gif" alt="<?php echo $Language->Phrase("PagerFirst") ?>" width="16" height="16" border="0"></td>
	<?php } ?>
<!--previous page button-->
	<?php if ($p_villages_list->Pager->PrevButton->Enabled) { ?>
	<td><a href="<?php echo $p_villages_list->PageUrl() ?>start=<?php echo $p_villages_list->Pager->PrevButton->Start ?>"><img src="images/prev.gif" alt="<?php echo $Language->Phrase("PagerPrevious") ?>" width="16" height="16" border="0"></a></td>
	<?php } else { ?>
	<td><img src="images/prevdisab.gif" alt="<?php echo $Language->Phrase("PagerPrevious") ?>" width="16" height="16" border="0"></td>
	<?php } ?>
<!--current page number-->
	<td><input type="text" name="<?php echo EW_TABLE_PAGE_NO ?>" id="<?php echo EW_TABLE_PAGE_NO ?>" value="<?php echo $p_villages_list->Pager->CurrentPage ?>" size="4"></td>
<!--next page button-->
	<?php if ($p_villages_list->Pager->NextButton->Enabled) { ?>
	<td><a href="<?php echo $p_villages_list->PageUrl() ?>start=<?php echo $p_villages_list->Pager->NextButton->Start ?>"><img src="images/next.gif" alt="<?php echo $Language->Phrase("PagerNext") ?>" width="16" height="16" border="0"></a></td>	
	<?php } else { ?>
	<td><img src="images/nextdisab.gif" alt="<?php echo $Language->Phrase("PagerNext") ?>" width="16" height="16" border="0"></td>
	<?php } ?>
<!--last page button-->
	<?php if ($p_villages_list->Pager->LastButton->Enabled) { ?>
	<td><a href="<?php echo $p_villages_list->PageUrl() ?>start=<?php echo $p_villages_list->Pager->LastButton->Start ?>"><img src="images/last.gif" alt="<?php echo $Language->Phrase("PagerLast") ?>" width="16" height="16" border="0"></a></td>	
	<?php } else { ?>
	<td><img src="images/lastdisab.gif" alt="<?php echo $Language->Phrase("PagerLast") ?>" width="16" height="16" border="0"></td>
	<?php } ?>
	<td><span class="phpmaker">&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $p_villages_list->Pager->PageCount ?></span></td>
	</tr></table>
	</td>	
	<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td>
	<span class="phpmaker"><?php echo $Language->Phrase("Record") ?>&nbsp;<?php echo $p_villages_list->Pager->FromIndex ?>&nbsp;<?php echo $Language->Phrase("To") ?>&nbsp;<?php echo $p_villages_list->Pager->ToIndex ?>&nbsp;<?php echo $Language->Phrase("Of") ?>&nbsp;<?php echo $p_villages_list->Pager->RecordCount ?></span>
<?php } else { ?>
	<?php if ($p_villages_list->sSrchWhere == "0=101") { ?>
	<span class="phpmaker"><?php echo $Language->Phrase("EnterSearchCriteria") ?></span>
	<?php } else { ?>
	<span class="phpmaker"><?php echo $Language->Phrase("NoRecord") ?></span>
	<?php } ?>
<?php } ?>
		</td>
<?php if ($p_villages_list->lTotalRecs > 0) { ?>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td><table border="0" cellspacing="0" cellpadding="0"><tr><td><?php echo $Language->Phrase("RecordsPerPage") ?>&nbsp;</td><td>
<input type="hidden" id="t" name="t" value="p_villages">
<select name="<?php echo EW_TABLE_REC_PER_PAGE ?>" id="<?php echo EW_TABLE_REC_PER_PAGE ?>" onchange="this.form.submit();" class="phpmaker">
<option value="10"<?php if ($p_villages_list->lDisplayRecs == 10) { ?> selected="selected"<?php } ?>>10</option>
<option value="50"<?php if ($p_villages_list->lDisplayRecs == 50) { ?> selected="selected"<?php } ?>>50</option>
<option value="190"<?php if ($p_villages_list->lDisplayRecs == 190) { ?> selected="selected"<?php } ?>>190</option>
<option value="220"<?php if ($p_villages_list->lDisplayRecs == 220) { ?> selected="selected"<?php } ?>>220</option>
<option value="480"<?php if ($p_villages_list->lDisplayRecs == 480) { ?> selected="selected"<?php } ?>>480</option>
<option value="500"<?php if ($p_villages_list->lDisplayRecs == 500) { ?> selected="selected"<?php } ?>>500</option>
</select></td></tr></table>
		</td>
<?php } ?>
	</tr>
</table>
</form>
<?php } ?>
<?php //if ($p_villages_list->lTotalRecs > 0) { ?>
<span class="phpmaker">
</span>
<?php //} ?>
</div>
<?php } ?>
</td></tr></table>
<?php if ($p_villages->Export == "" && $p_villages->CurrentAction == "") { ?>
<?php } ?>
<?php if ($p_villages->Export == "") { ?>
<script language="JavaScript" type="text/javascript">
<!--

// Write your table-specific startup script here
// document.write("page loaded");
//-->

</script>
<?php } ?>
<?php include "footer.php" ?>
<?php
$p_villages_list->Page_Terminate();
?>
<?php

//
// Page class
//
class cp_villages_list {

	// Page ID
	var $PageID = 'list';

	// Table name
	var $TableName = 'p_villages';

	// Page object name
	var $PageObjName = 'p_villages_list';

	// Page name
	function PageName() {
		return ew_CurrentPage();
	}

	// Page URL
	function PageUrl() {
		$PageUrl = ew_CurrentPage() . "?";
		global $p_villages;
		if ($p_villages->UseTokenInUrl) $PageUrl .= "t=" . $p_villages->TableVar . "&"; // Add page token
		return $PageUrl;
	}

	// Page URLs
	var $AddUrl;
	var $EditUrl;
	var $CopyUrl;
	var $DeleteUrl;
	var $ViewUrl;
	var $ListUrl;

	// Export URLs
	var $ExportPrintUrl;
	var $ExportHtmlUrl;
	var $ExportExcelUrl;
	var $ExportWordUrl;
	var $ExportXmlUrl;
	var $ExportCsvUrl;

	// Update URLs
	var $InlineAddUrl;
	var $InlineCopyUrl;
	var $InlineEditUrl;
	var $GridAddUrl;
	var $GridEditUrl;
	var $MultiDeleteUrl;
	var $MultiUpdateUrl;

	// Message
	function getMessage() {
		return @$_SESSION[EW_SESSION_MESSAGE];
	}

	function setMessage($v) {
		if (@$_SESSION[EW_SESSION_MESSAGE] <> "") { // Append
			$_SESSION[EW_SESSION_MESSAGE] .= "<br>" . $v;
		} else {
			$_SESSION[EW_SESSION_MESSAGE] = $v;
		}
	}

	// Show message
	function ShowMessage() {
		$sMessage = $this->getMessage();
		$this->Message_Showing($sMessage);
		if ($sMessage <> "") { // Message in Session, display
			echo "<p><span class=\"ewMessage\">" . $sMessage . "</span></p>";
			$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message in Session
		}
	}

	// Validate page request
	function IsPageRequest() {
		global $objForm, $p_villages;
		if ($p_villages->UseTokenInUrl) {
			if ($objForm)
				return ($p_villages->TableVar == $objForm->GetValue("t"));
			if (@$_GET["t"] <> "")
				return ($p_villages->TableVar == $_GET["t"]);
		} else {
			return TRUE;
		}
	}

	//
	// Page class constructor
	//
	function cp_villages_list() {
		global $conn, $Language;

		// Language object
		$Language = new cLanguage();

		// Table object (p_villages)
		$GLOBALS["p_villages"] = new cp_villages();

		// Initialize URLs
		$this->ExportPrintUrl = $this->PageUrl() . "export=print";
		$this->ExportExcelUrl = $this->PageUrl() . "export=excel";
		$this->ExportWordUrl = $this->PageUrl() . "export=word";
		$this->ExportHtmlUrl = $this->PageUrl() . "export=html";
		$this->ExportXmlUrl = $this->PageUrl() . "export=xml";
		$this->ExportCsvUrl = $this->PageUrl() . "export=csv";
		$this->AddUrl = $GLOBALS["p_villages"]->AddUrl();
		$this->InlineAddUrl = $this->PageUrl() . "a=add";
		$this->GridAddUrl = $this->PageUrl() . "a=gridadd";
		$this->GridEditUrl = $this->PageUrl() . "a=gridedit";
		$this->MultiDeleteUrl = "p_villagesdelete.php";
		$this->MultiUpdateUrl = "p_villagesupdate.php";

		// Page ID
		if (!defined("EW_PAGE_ID"))
			define("EW_PAGE_ID", 'list', TRUE);

		// Table name (for backward compatibility)
		if (!defined("EW_TABLE_NAME"))
			define("EW_TABLE_NAME", 'p_villages', TRUE);

		// Start timer
		$GLOBALS["gsTimer"] = new cTimer();

		// Open connection
		$conn = ew_Connect();

		// List options
		$this->ListOptions = new cListOptions();
	}

	// 
	//  Page_Init
	//
	function Page_Init() {
		global $gsExport, $gsExportFile, $UserProfile, $Language, $Security, $objForm;
		global $p_villages;

		// Security
		$Security = new cAdvancedSecurity();
		if (!$Security->IsLoggedIn()) $Security->AutoLogin();
		if (!$Security->IsLoggedIn()) {
			$Security->SaveLastUrl();
			$this->Page_Terminate("login.php");
		}

		// Get export parameters
		if (@$_GET["export"] <> "") {
			$p_villages->Export = $_GET["export"];
		} elseif (ew_IsHttpPost()) {
			if (@$_POST["exporttype"] <> "")
				$p_villages->Export = $_POST["exporttype"];
		} else {
			$p_villages->setExportReturnUrl(ew_CurrentUrl());
		}
		$gsExport = $p_villages->Export; // Get export parameter, used in header
		$gsExportFile = $p_villages->TableVar; // Get export file, used in header

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();
	}

	//
	// Page_Terminate
	//
	function Page_Terminate($url = "") {
		global $conn;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		 // Close connection
		$conn->Close();

		// Go to URL if specified
		$this->Page_Redirecting($url);
		if ($url <> "") {
			if (!EW_DEBUG_ENABLED && ob_get_length())
				ob_end_clean();
			header("Location: " . $url);
		}
		exit();
	}

	// Class variables
	var $ListOptions; // List options
	var $lDisplayRecs = 500;
	var $lStartRec;
	var $lStopRec;
	var $lTotalRecs = 0;
	var $lRecRange = 10;
	var $sSrchWhere = ""; // Search WHERE clause
	var $lRecCnt = 0; // Record count
	var $lEditRowCnt;
	var $lRowCnt;
	var $lRowIndex; // Row index
	var $lRecPerRow = 0;
	var $lColCnt = 0;
	var $sDbMasterFilter = ""; // Master filter
	var $sDbDetailFilter = ""; // Detail filter
	var $bMasterRecordExists;	
	var $sMultiSelectKey;
	var $RestoreSearch;

	//
	// Page main
	//
	function Page_Main() {
		global $objForm, $Language, $gsSearchError, $Security, $p_villages;

		// Search filters
		$sSrchAdvanced = ""; // Advanced search filter
		$sSrchBasic = ""; // Basic search filter
		$sFilter = "";
		if ($this->IsPageRequest()) { // Validate request

			// Set up records per page
			$this->SetUpDisplayRecs();

			// Handle reset command
			$this->ResetCmd();

			// Set up list options
			$this->SetupListOptions();

			// Get basic search values
			$this->LoadBasicSearchValues();

			// Get and validate search values for advanced search
			$this->LoadSearchValues(); // Get search values
			if (!$this->ValidateSearch())
				$this->setMessage($gsSearchError);

			// Restore search parms from Session
			$this->RestoreSearchParms();

			// Call Recordset SearchValidated event
			$p_villages->Recordset_SearchValidated();

			// Set up sorting order
			$this->SetUpSortOrder();

			// Get basic search criteria
			if ($gsSearchError == "")
				$sSrchBasic = $this->BasicSearchWhere();

			// Get search criteria for advanced search
			if ($gsSearchError == "")
				$sSrchAdvanced = $this->AdvancedSearchWhere();
		}

		// Restore display records
		if ($p_villages->getRecordsPerPage() <> "") {
			$this->lDisplayRecs = $p_villages->getRecordsPerPage(); // Restore from Session
		} else {
			$this->lDisplayRecs = 500; // Load default
		}

		// Load Sorting Order
		$this->LoadSortOrder();

		// Build search criteria
		if ($sSrchAdvanced <> "")
			$this->sSrchWhere = ($this->sSrchWhere <> "") ? "(" . $this->sSrchWhere . ") AND (" . $sSrchAdvanced . ")" : $sSrchAdvanced;
		if ($sSrchBasic <> "")
			$this->sSrchWhere = ($this->sSrchWhere <> "") ? "(" . $this->sSrchWhere . ") AND (" . $sSrchBasic. ")" : $sSrchBasic;

		// Call Recordset_Searching event
		$p_villages->Recordset_Searching($this->sSrchWhere);

		// Save search criteria
		if ($this->sSrchWhere <> "") {
			if ($sSrchBasic == "")
				$this->ResetBasicSearchParms();
			if ($sSrchAdvanced == "")
				$this->ResetAdvancedSearchParms();
			$p_villages->setSearchWhere($this->sSrchWhere); // Save to Session
			if (!$this->RestoreSearch) {
				$this->lStartRec = 1; // Reset start record counter
				$p_villages->setStartRecordNumber($this->lStartRec);
			}
		} else {
			$this->sSrchWhere = $p_villages->getSearchWhere();
		}

		// Build filter
		$sFilter = "";
		if ($this->sDbDetailFilter <> "")
			$sFilter = ($sFilter <> "") ? "(" . $sFilter . ") AND (" . $this->sDbDetailFilter . ")" : $this->sDbDetailFilter;
		if ($this->sSrchWhere <> "")
			$sFilter = ($sFilter <> "") ? "(" . $sFilter . ") AND (". $this->sSrchWhere . ")" : $this->sSrchWhere;

		// Set up filter in session
		$p_villages->setSessionWhere($sFilter);
		$p_villages->CurrentFilter = "";
	}

	// Set up number of records displayed per page
	function SetUpDisplayRecs() {
		global $p_villages;
		$sWrk = @$_GET[EW_TABLE_REC_PER_PAGE];
		if ($sWrk <> "") {
			if (is_numeric($sWrk)) {
				$this->lDisplayRecs = intval($sWrk);
			} else {
				if (strtolower($sWrk) == "all") { // Display all records
					$this->lDisplayRecs = -1;
				} else {
					$this->lDisplayRecs = 500; // Non-numeric, load default
				}
			}
			$p_villages->setRecordsPerPage($this->lDisplayRecs); // Save to Session

			// Reset start position
			$this->lStartRec = 1;
			$p_villages->setStartRecordNumber($this->lStartRec);
		}
	}

	// Advanced search WHERE clause based on QueryString
	function AdvancedSearchWhere() {
		global $Security, $p_villages;
		$sWhere = "";
		$this->BuildSearchSql($sWhere, $p_villages->id, FALSE); // id
		$this->BuildSearchSql($sWhere, $p_villages->rel_x, FALSE); // rel_x
		$this->BuildSearchSql($sWhere, $p_villages->rel_y, FALSE); // rel_y
		$this->BuildSearchSql($sWhere, $p_villages->field_maps_id, FALSE); // field_maps_id
		$this->BuildSearchSql($sWhere, $p_villages->image_num, FALSE); // image_num
		$this->BuildSearchSql($sWhere, $p_villages->rand_num, FALSE); // rand_num
		$this->BuildSearchSql($sWhere, $p_villages->parent_id, FALSE); // parent_id
		$this->BuildSearchSql($sWhere, $p_villages->tribe_id, FALSE); // tribe_id
		$this->BuildSearchSql($sWhere, $p_villages->player_id, FALSE); // player_id
		$this->BuildSearchSql($sWhere, $p_villages->alliance_id, FALSE); // alliance_id
		$this->BuildSearchSql($sWhere, $p_villages->player_name, FALSE); // player_name
		$this->BuildSearchSql($sWhere, $p_villages->village_name, FALSE); // village_name
		$this->BuildSearchSql($sWhere, $p_villages->alliance_name, FALSE); // alliance_name
		$this->BuildSearchSql($sWhere, $p_villages->is_capital, FALSE); // is_capital
		$this->BuildSearchSql($sWhere, $p_villages->is_special_village, FALSE); // is_special_village
		$this->BuildSearchSql($sWhere, $p_villages->is_oasis, FALSE); // is_oasis
		$this->BuildSearchSql($sWhere, $p_villages->people_count, FALSE); // people_count
		$this->BuildSearchSql($sWhere, $p_villages->crop_consumption, FALSE); // crop_consumption
		$this->BuildSearchSql($sWhere, $p_villages->time_consume_percent, FALSE); // time_consume_percent
		$this->BuildSearchSql($sWhere, $p_villages->offer_merchants_count, FALSE); // offer_merchants_count
		$this->BuildSearchSql($sWhere, $p_villages->resources, FALSE); // resources
		$this->BuildSearchSql($sWhere, $p_villages->cp, FALSE); // cp
		$this->BuildSearchSql($sWhere, $p_villages->buildings, FALSE); // buildings
		$this->BuildSearchSql($sWhere, $p_villages->troops_training, FALSE); // troops_training
		$this->BuildSearchSql($sWhere, $p_villages->troops_num, FALSE); // troops_num
		$this->BuildSearchSql($sWhere, $p_villages->troops_out_num, FALSE); // troops_out_num
		$this->BuildSearchSql($sWhere, $p_villages->troops_intrap_num, FALSE); // troops_intrap_num
		$this->BuildSearchSql($sWhere, $p_villages->troops_out_intrap_num, FALSE); // troops_out_intrap_num
		$this->BuildSearchSql($sWhere, $p_villages->troops_trapped_num, FALSE); // troops_trapped_num
		$this->BuildSearchSql($sWhere, $p_villages->allegiance_percent, FALSE); // allegiance_percent
		$this->BuildSearchSql($sWhere, $p_villages->child_villages_id, FALSE); // child_villages_id
		$this->BuildSearchSql($sWhere, $p_villages->village_oases_id, FALSE); // village_oases_id
		$this->BuildSearchSql($sWhere, $p_villages->creation_date, FALSE); // creation_date
		$this->BuildSearchSql($sWhere, $p_villages->update_key, FALSE); // update_key
		$this->BuildSearchSql($sWhere, $p_villages->last_update_date, FALSE); // last_update_date

		// Set up search parm
		if ($sWhere <> "") {
			$this->SetSearchParm($p_villages->id); // id
			$this->SetSearchParm($p_villages->rel_x); // rel_x
			$this->SetSearchParm($p_villages->rel_y); // rel_y
			$this->SetSearchParm($p_villages->field_maps_id); // field_maps_id
			$this->SetSearchParm($p_villages->image_num); // image_num
			$this->SetSearchParm($p_villages->rand_num); // rand_num
			$this->SetSearchParm($p_villages->parent_id); // parent_id
			$this->SetSearchParm($p_villages->tribe_id); // tribe_id
			$this->SetSearchParm($p_villages->player_id); // player_id
			$this->SetSearchParm($p_villages->alliance_id); // alliance_id
			$this->SetSearchParm($p_villages->player_name); // player_name
			$this->SetSearchParm($p_villages->village_name); // village_name
			$this->SetSearchParm($p_villages->alliance_name); // alliance_name
			$this->SetSearchParm($p_villages->is_capital); // is_capital
			$this->SetSearchParm($p_villages->is_special_village); // is_special_village
			$this->SetSearchParm($p_villages->is_oasis); // is_oasis
			$this->SetSearchParm($p_villages->people_count); // people_count
			$this->SetSearchParm($p_villages->crop_consumption); // crop_consumption
			$this->SetSearchParm($p_villages->time_consume_percent); // time_consume_percent
			$this->SetSearchParm($p_villages->offer_merchants_count); // offer_merchants_count
			$this->SetSearchParm($p_villages->resources); // resources
			$this->SetSearchParm($p_villages->cp); // cp
			$this->SetSearchParm($p_villages->buildings); // buildings
			$this->SetSearchParm($p_villages->troops_training); // troops_training
			$this->SetSearchParm($p_villages->troops_num); // troops_num
			$this->SetSearchParm($p_villages->troops_out_num); // troops_out_num
			$this->SetSearchParm($p_villages->troops_intrap_num); // troops_intrap_num
			$this->SetSearchParm($p_villages->troops_out_intrap_num); // troops_out_intrap_num
			$this->SetSearchParm($p_villages->troops_trapped_num); // troops_trapped_num
			$this->SetSearchParm($p_villages->allegiance_percent); // allegiance_percent
			$this->SetSearchParm($p_villages->child_villages_id); // child_villages_id
			$this->SetSearchParm($p_villages->village_oases_id); // village_oases_id
			$this->SetSearchParm($p_villages->creation_date); // creation_date
			$this->SetSearchParm($p_villages->update_key); // update_key
			$this->SetSearchParm($p_villages->last_update_date); // last_update_date
		}
		return $sWhere;
	}

	// Build search SQL
	function BuildSearchSql(&$Where, &$Fld, $MultiValue) {
		$FldParm = substr($Fld->FldVar, 2);		
		$FldVal = $Fld->AdvancedSearch->SearchValue; // @$_GET["x_$FldParm"]
		$FldOpr = $Fld->AdvancedSearch->SearchOperator; // @$_GET["z_$FldParm"]
		$FldCond = $Fld->AdvancedSearch->SearchCondition; // @$_GET["v_$FldParm"]
		$FldVal2 = $Fld->AdvancedSearch->SearchValue2; // @$_GET["y_$FldParm"]
		$FldOpr2 = $Fld->AdvancedSearch->SearchOperator2; // @$_GET["w_$FldParm"]
		$sWrk = "";

		//$FldVal = ew_StripSlashes($FldVal);
		if (is_array($FldVal)) $FldVal = implode(",", $FldVal);

		//$FldVal2 = ew_StripSlashes($FldVal2);
		if (is_array($FldVal2)) $FldVal2 = implode(",", $FldVal2);
		$FldOpr = strtoupper(trim($FldOpr));
		if ($FldOpr == "") $FldOpr = "=";
		$FldOpr2 = strtoupper(trim($FldOpr2));
		if ($FldOpr2 == "") $FldOpr2 = "=";
		if (EW_SEARCH_MULTI_VALUE_OPTION == 1 || $FldOpr <> "LIKE" ||
			($FldOpr2 <> "LIKE" && $FldVal2 <> ""))
			$MultiValue = FALSE;
		if ($MultiValue) {
			$sWrk1 = ($FldVal <> "") ? ew_GetMultiSearchSql($Fld, $FldVal) : ""; // Field value 1
			$sWrk2 = ($FldVal2 <> "") ? ew_GetMultiSearchSql($Fld, $FldVal2) : ""; // Field value 2
			$sWrk = $sWrk1; // Build final SQL
			if ($sWrk2 <> "")
				$sWrk = ($sWrk <> "") ? "($sWrk) $FldCond ($sWrk2)" : $sWrk2;
		} else {
			$FldVal = $this->ConvertSearchValue($Fld, $FldVal);
			$FldVal2 = $this->ConvertSearchValue($Fld, $FldVal2);
			$sWrk = ew_GetSearchSql($Fld, $FldVal, $FldOpr, $FldCond, $FldVal2, $FldOpr2);
		}
		if ($sWrk <> "") {
			if ($Where <> "") $Where .= " AND ";
			$Where .= "(" . $sWrk . ")";
		}
	}

	// Set search parameters
	function SetSearchParm(&$Fld) {
		global $p_villages;
		$FldParm = substr($Fld->FldVar, 2);
		$FldVal = $Fld->AdvancedSearch->SearchValue; // @$_GET["x_$FldParm"]
		$FldVal = ew_StripSlashes($FldVal);
		if (is_array($FldVal)) $FldVal = implode(",", $FldVal);
		$FldVal2 = $Fld->AdvancedSearch->SearchValue2; // @$_GET["y_$FldParm"]
		$FldVal2 = ew_StripSlashes($FldVal2);
		if (is_array($FldVal2)) $FldVal2 = implode(",", $FldVal2);
		$p_villages->setAdvancedSearch("x_$FldParm", $FldVal);
		$p_villages->setAdvancedSearch("z_$FldParm", $Fld->AdvancedSearch->SearchOperator); // @$_GET["z_$FldParm"]
		$p_villages->setAdvancedSearch("v_$FldParm", $Fld->AdvancedSearch->SearchCondition); // @$_GET["v_$FldParm"]
		$p_villages->setAdvancedSearch("y_$FldParm", $FldVal2);
		$p_villages->setAdvancedSearch("w_$FldParm", $Fld->AdvancedSearch->SearchOperator2); // @$_GET["w_$FldParm"]
	}

	// Get search parameters
	function GetSearchParm(&$Fld) {
		global $p_villages;
		$FldParm = substr($Fld->FldVar, 2);
		$Fld->AdvancedSearch->SearchValue = $p_villages->GetAdvancedSearch("x_$FldParm");
		$Fld->AdvancedSearch->SearchOperator = $p_villages->GetAdvancedSearch("z_$FldParm");
		$Fld->AdvancedSearch->SearchCondition = $p_villages->GetAdvancedSearch("v_$FldParm");
		$Fld->AdvancedSearch->SearchValue2 = $p_villages->GetAdvancedSearch("y_$FldParm");
		$Fld->AdvancedSearch->SearchOperator2 = $p_villages->GetAdvancedSearch("w_$FldParm");
	}

	// Convert search value
	function ConvertSearchValue(&$Fld, $FldVal) {
		$Value = $FldVal;
		if ($Fld->FldDataType == EW_DATATYPE_BOOLEAN) {
			if ($FldVal <> "") $Value = ($FldVal == "1") ? $Fld->TrueValue : $Fld->FalseValue;
		} elseif ($Fld->FldDataType == EW_DATATYPE_DATE) {
			if ($FldVal <> "") $Value = ew_UnFormatDateTime($FldVal, $Fld->FldDateTimeFormat);
		}
		return $Value;
	}

	// Return basic search SQL
	function BasicSearchSQL($Keyword) {
		global $p_villages;
		$sKeyword = ew_AdjustSql($Keyword);
		$sWhere = "";
		if (is_numeric($Keyword)) $this->BuildBasicSearchSQL($sWhere, $p_villages->id, $Keyword);
		$this->BuildBasicSearchSQL($sWhere, $p_villages->player_name, $Keyword);
		$this->BuildBasicSearchSQL($sWhere, $p_villages->village_name, $Keyword);
		if (is_numeric($Keyword)) $this->BuildBasicSearchSQL($sWhere, $p_villages->is_capital, $Keyword);
		if (is_numeric($Keyword)) $this->BuildBasicSearchSQL($sWhere, $p_villages->is_special_village, $Keyword);
		if (is_numeric($Keyword)) $this->BuildBasicSearchSQL($sWhere, $p_villages->people_count, $Keyword);
		if (is_numeric($Keyword)) $this->BuildBasicSearchSQL($sWhere, $p_villages->crop_consumption, $Keyword);
		$this->BuildBasicSearchSQL($sWhere, $p_villages->resources, $Keyword);
		$this->BuildBasicSearchSQL($sWhere, $p_villages->cp, $Keyword);
		$this->BuildBasicSearchSQL($sWhere, $p_villages->buildings, $Keyword);
		$this->BuildBasicSearchSQL($sWhere, $p_villages->troops_num, $Keyword);
		return $sWhere;
	}

	// Build basic search SQL
	function BuildBasicSearchSql(&$Where, &$Fld, $Keyword) {
		$sFldExpression = ($Fld->FldVirtualExpression <> "") ? $Fld->FldVirtualExpression : $Fld->FldExpression;
		$lFldDataType = ($Fld->FldIsVirtual) ? EW_DATATYPE_STRING : $Fld->FldDataType;
		if ($lFldDataType == EW_DATATYPE_NUMBER) {
			$sWrk = $sFldExpression . " = " . ew_QuotedValue($Keyword, $lFldDataType);
		} else {
			$sWrk = $sFldExpression . " LIKE " . ew_QuotedValue("%" . $Keyword . "%", $lFldDataType);
		}
		if ($Where <> "") $Where .= " OR ";
		$Where .= $sWrk;
	}

	// Return basic search WHERE clause based on search keyword and type
	function BasicSearchWhere() {
		global $Security, $p_villages;
		$sSearchStr = "";
		$sSearchKeyword = $p_villages->BasicSearchKeyword;
		$sSearchType = $p_villages->BasicSearchType;
		if ($sSearchKeyword <> "") {
			$sSearch = trim($sSearchKeyword);
			if ($sSearchType <> "") {
				while (strpos($sSearch, "  ") !== FALSE)
					$sSearch = str_replace("  ", " ", $sSearch);
				$arKeyword = explode(" ", trim($sSearch));
				foreach ($arKeyword as $sKeyword) {
					if ($sSearchStr <> "") $sSearchStr .= " " . $sSearchType . " ";
					$sSearchStr .= "(" . $this->BasicSearchSQL($sKeyword) . ")";
				}
			} else {
				$sSearchStr = $this->BasicSearchSQL($sSearch);
			}
		}
		if ($sSearchKeyword <> "") {
			$p_villages->setSessionBasicSearchKeyword($sSearchKeyword);
			$p_villages->setSessionBasicSearchType($sSearchType);
		}
		return $sSearchStr;
	}

	// Clear all search parameters
	function ResetSearchParms() {
		global $p_villages;

		// Clear search WHERE clause
		$this->sSrchWhere = "";
		$p_villages->setSearchWhere($this->sSrchWhere);

		// Clear basic search parameters
		$this->ResetBasicSearchParms();

		// Clear advanced search parameters
		$this->ResetAdvancedSearchParms();
	}

	// Clear all basic search parameters
	function ResetBasicSearchParms() {
		global $p_villages;
		$p_villages->setSessionBasicSearchKeyword("");
		$p_villages->setSessionBasicSearchType("");
	}

	// Clear all advanced search parameters
	function ResetAdvancedSearchParms() {
		global $p_villages;
		$p_villages->setAdvancedSearch("x_id", "");
		$p_villages->setAdvancedSearch("x_rel_x", "");
		$p_villages->setAdvancedSearch("x_rel_y", "");
		$p_villages->setAdvancedSearch("x_field_maps_id", "");
		$p_villages->setAdvancedSearch("x_image_num", "");
		$p_villages->setAdvancedSearch("x_rand_num", "");
		$p_villages->setAdvancedSearch("x_parent_id", "");
		$p_villages->setAdvancedSearch("x_tribe_id", "");
		$p_villages->setAdvancedSearch("x_player_id", "");
		$p_villages->setAdvancedSearch("x_alliance_id", "");
		$p_villages->setAdvancedSearch("x_player_name", "");
		$p_villages->setAdvancedSearch("x_village_name", "");
		$p_villages->setAdvancedSearch("x_alliance_name", "");
		$p_villages->setAdvancedSearch("x_is_capital", "");
		$p_villages->setAdvancedSearch("x_is_special_village", "");
		$p_villages->setAdvancedSearch("x_is_oasis", "");
		$p_villages->setAdvancedSearch("x_people_count", "");
		$p_villages->setAdvancedSearch("x_crop_consumption", "");
		$p_villages->setAdvancedSearch("x_time_consume_percent", "");
		$p_villages->setAdvancedSearch("x_offer_merchants_count", "");
		$p_villages->setAdvancedSearch("x_resources", "");
		$p_villages->setAdvancedSearch("x_cp", "");
		$p_villages->setAdvancedSearch("x_buildings", "");
		$p_villages->setAdvancedSearch("x_troops_training", "");
		$p_villages->setAdvancedSearch("x_troops_num", "");
		$p_villages->setAdvancedSearch("x_troops_out_num", "");
		$p_villages->setAdvancedSearch("x_troops_intrap_num", "");
		$p_villages->setAdvancedSearch("x_troops_out_intrap_num", "");
		$p_villages->setAdvancedSearch("x_troops_trapped_num", "");
		$p_villages->setAdvancedSearch("x_allegiance_percent", "");
		$p_villages->setAdvancedSearch("x_child_villages_id", "");
		$p_villages->setAdvancedSearch("x_village_oases_id", "");
		$p_villages->setAdvancedSearch("x_creation_date", "");
		$p_villages->setAdvancedSearch("x_update_key", "");
		$p_villages->setAdvancedSearch("x_last_update_date", "");
	}

	// Restore all search parameters
	function RestoreSearchParms() {
		global $p_villages;
		$bRestore = TRUE;
		if (@$_GET[EW_TABLE_BASIC_SEARCH] <> "") $bRestore = FALSE;
		if (@$_GET["x_id"] <> "") $bRestore = FALSE;
		if (@$_GET["x_rel_x"] <> "") $bRestore = FALSE;
		if (@$_GET["x_rel_y"] <> "") $bRestore = FALSE;
		if (@$_GET["x_field_maps_id"] <> "") $bRestore = FALSE;
		if (@$_GET["x_image_num"] <> "") $bRestore = FALSE;
		if (@$_GET["x_rand_num"] <> "") $bRestore = FALSE;
		if (@$_GET["x_parent_id"] <> "") $bRestore = FALSE;
		if (@$_GET["x_tribe_id"] <> "") $bRestore = FALSE;
		if (@$_GET["x_player_id"] <> "") $bRestore = FALSE;
		if (@$_GET["x_alliance_id"] <> "") $bRestore = FALSE;
		if (@$_GET["x_player_name"] <> "") $bRestore = FALSE;
		if (@$_GET["x_village_name"] <> "") $bRestore = FALSE;
		if (@$_GET["x_alliance_name"] <> "") $bRestore = FALSE;
		if (@$_GET["x_is_capital"] <> "") $bRestore = FALSE;
		if (@$_GET["x_is_special_village"] <> "") $bRestore = FALSE;
		if (@$_GET["x_is_oasis"] <> "") $bRestore = FALSE;
		if (@$_GET["x_people_count"] <> "") $bRestore = FALSE;
		if (@$_GET["x_crop_consumption"] <> "") $bRestore = FALSE;
		if (@$_GET["x_time_consume_percent"] <> "") $bRestore = FALSE;
		if (@$_GET["x_offer_merchants_count"] <> "") $bRestore = FALSE;
		if (@$_GET["x_resources"] <> "") $bRestore = FALSE;
		if (@$_GET["x_cp"] <> "") $bRestore = FALSE;
		if (@$_GET["x_buildings"] <> "") $bRestore = FALSE;
		if (@$_GET["x_troops_training"] <> "") $bRestore = FALSE;
		if (@$_GET["x_troops_num"] <> "") $bRestore = FALSE;
		if (@$_GET["x_troops_out_num"] <> "") $bRestore = FALSE;
		if (@$_GET["x_troops_intrap_num"] <> "") $bRestore = FALSE;
		if (@$_GET["x_troops_out_intrap_num"] <> "") $bRestore = FALSE;
		if (@$_GET["x_troops_trapped_num"] <> "") $bRestore = FALSE;
		if (@$_GET["x_allegiance_percent"] <> "") $bRestore = FALSE;
		if (@$_GET["x_child_villages_id"] <> "") $bRestore = FALSE;
		if (@$_GET["x_village_oases_id"] <> "") $bRestore = FALSE;
		if (@$_GET["x_creation_date"] <> "") $bRestore = FALSE;
		if (@$_GET["x_update_key"] <> "") $bRestore = FALSE;
		if (@$_GET["x_last_update_date"] <> "") $bRestore = FALSE;
		$this->RestoreSearch = $bRestore;
		if ($bRestore) {

			// Restore basic search values
			$p_villages->BasicSearchKeyword = $p_villages->getSessionBasicSearchKeyword();
			$p_villages->BasicSearchType = $p_villages->getSessionBasicSearchType();

			// Restore advanced search values
			$this->GetSearchParm($p_villages->id);
			$this->GetSearchParm($p_villages->rel_x);
			$this->GetSearchParm($p_villages->rel_y);
			$this->GetSearchParm($p_villages->field_maps_id);
			$this->GetSearchParm($p_villages->image_num);
			$this->GetSearchParm($p_villages->rand_num);
			$this->GetSearchParm($p_villages->parent_id);
			$this->GetSearchParm($p_villages->tribe_id);
			$this->GetSearchParm($p_villages->player_id);
			$this->GetSearchParm($p_villages->alliance_id);
			$this->GetSearchParm($p_villages->player_name);
			$this->GetSearchParm($p_villages->village_name);
			$this->GetSearchParm($p_villages->alliance_name);
			$this->GetSearchParm($p_villages->is_capital);
			$this->GetSearchParm($p_villages->is_special_village);
			$this->GetSearchParm($p_villages->is_oasis);
			$this->GetSearchParm($p_villages->people_count);
			$this->GetSearchParm($p_villages->crop_consumption);
			$this->GetSearchParm($p_villages->time_consume_percent);
			$this->GetSearchParm($p_villages->offer_merchants_count);
			$this->GetSearchParm($p_villages->resources);
			$this->GetSearchParm($p_villages->cp);
			$this->GetSearchParm($p_villages->buildings);
			$this->GetSearchParm($p_villages->troops_training);
			$this->GetSearchParm($p_villages->troops_num);
			$this->GetSearchParm($p_villages->troops_out_num);
			$this->GetSearchParm($p_villages->troops_intrap_num);
			$this->GetSearchParm($p_villages->troops_out_intrap_num);
			$this->GetSearchParm($p_villages->troops_trapped_num);
			$this->GetSearchParm($p_villages->allegiance_percent);
			$this->GetSearchParm($p_villages->child_villages_id);
			$this->GetSearchParm($p_villages->village_oases_id);
			$this->GetSearchParm($p_villages->creation_date);
			$this->GetSearchParm($p_villages->update_key);
			$this->GetSearchParm($p_villages->last_update_date);
		}
	}

	// Set up sort parameters
	function SetUpSortOrder() {
		global $p_villages;

		// Check for "order" parameter
		if (@$_GET["order"] <> "") {
			$p_villages->CurrentOrder = ew_StripSlashes(@$_GET["order"]);
			$p_villages->CurrentOrderType = @$_GET["ordertype"];
			$p_villages->UpdateSort($p_villages->id); // id
			$p_villages->UpdateSort($p_villages->player_name); // player_name
			$p_villages->UpdateSort($p_villages->village_name); // village_name
			$p_villages->UpdateSort($p_villages->is_capital); // is_capital
			$p_villages->UpdateSort($p_villages->is_special_village); // is_special_village
			$p_villages->UpdateSort($p_villages->people_count); // people_count
			$p_villages->UpdateSort($p_villages->crop_consumption); // crop_consumption
			$p_villages->UpdateSort($p_villages->resources); // resources
			$p_villages->UpdateSort($p_villages->cp); // cp
			$p_villages->UpdateSort($p_villages->buildings); // buildings
			$p_villages->UpdateSort($p_villages->troops_num); // troops_num
			$p_villages->setStartRecordNumber(1); // Reset start position
		}
	}

	// Load sort order parameters
	function LoadSortOrder() {
		global $p_villages;
		$sOrderBy = $p_villages->getSessionOrderBy(); // Get ORDER BY from Session
		if ($sOrderBy == "") {
			if ($p_villages->SqlOrderBy() <> "") {
				$sOrderBy = $p_villages->SqlOrderBy();
				$p_villages->setSessionOrderBy($sOrderBy);
			}
		}
	}

	// Reset command
	// cmd=reset (Reset search parameters)
	// cmd=resetall (Reset search and master/detail parameters)
	// cmd=resetsort (Reset sort parameters)
	function ResetCmd() {
		global $p_villages;

		// Get reset command
		if (@$_GET["cmd"] <> "") {
			$sCmd = $_GET["cmd"];

			// Reset search criteria
			if (strtolower($sCmd) == "reset" || strtolower($sCmd) == "resetall")
				$this->ResetSearchParms();

			// Reset sorting order
			if (strtolower($sCmd) == "resetsort") {
				$sOrderBy = "";
				$p_villages->setSessionOrderBy($sOrderBy);
				$p_villages->id->setSort("");
				$p_villages->player_name->setSort("");
				$p_villages->village_name->setSort("");
				$p_villages->is_capital->setSort("");
				$p_villages->is_special_village->setSort("");
				$p_villages->people_count->setSort("");
				$p_villages->crop_consumption->setSort("");
				$p_villages->resources->setSort("");
				$p_villages->cp->setSort("");
				$p_villages->buildings->setSort("");
				$p_villages->troops_num->setSort("");
			}

			// Reset start position
			$this->lStartRec = 1;
			$p_villages->setStartRecordNumber($this->lStartRec);
		}
	}

	// Set up list options
	function SetupListOptions() {
		global $Security, $p_villages;

		// "view"
		$this->ListOptions->Add("view");
		$item =& $this->ListOptions->Items["view"];
		$item->CssStyle = "white-space: nowrap;";
		$item->Visible = $Security->IsLoggedIn();
		$item->OnLeft = FALSE;

		// "edit"
		$this->ListOptions->Add("edit");
		$item =& $this->ListOptions->Items["edit"];
		$item->CssStyle = "white-space: nowrap;";
		$item->Visible = $Security->IsLoggedIn();
		$item->OnLeft = FALSE;

		// Call ListOptions_Load event
		$this->ListOptions_Load();
		if ($p_villages->Export <> "" ||
			$p_villages->CurrentAction == "gridadd" ||
			$p_villages->CurrentAction == "gridedit")
			$this->ListOptions->HideAllOptions();
	}

	// Render list options
	function RenderListOptions() {
		global $Security, $Language, $p_villages;
		$this->ListOptions->LoadDefault();

		// "view"
		$oListOpt =& $this->ListOptions->Items["view"];
		if ($Security->IsLoggedIn() && $oListOpt->Visible)
			$oListOpt->Body = "<a href=\"" . $this->ViewUrl . "\">" . $Language->Phrase("ViewLink") . "</a>";

		// "edit"
		$oListOpt =& $this->ListOptions->Items["edit"];
		if ($Security->IsLoggedIn() && $oListOpt->Visible) {
			$oListOpt->Body = "<a href=\"" . $this->EditUrl . "\">" . $Language->Phrase("EditLink") . "</a>";
		}
		$this->RenderListOptionsExt();

		// Call ListOptions_Rendered event
		$this->ListOptions_Rendered();
	}

	function RenderListOptionsExt() {
		global $Security, $Language, $p_villages;
	}

	// Set up starting record parameters
	function SetUpStartRec() {
		global $p_villages;
		if ($this->lDisplayRecs == 0)
			return;
		if ($this->IsPageRequest()) { // Validate request
			if (@$_GET[EW_TABLE_START_REC] <> "") { // Check for "start" parameter
				$this->lStartRec = $_GET[EW_TABLE_START_REC];
				$p_villages->setStartRecordNumber($this->lStartRec);
			} elseif (@$_GET[EW_TABLE_PAGE_NO] <> "") {
				$this->nPageNo = $_GET[EW_TABLE_PAGE_NO];
				if (is_numeric($this->nPageNo)) {
					$this->lStartRec = ($this->nPageNo-1)*$this->lDisplayRecs+1;
					if ($this->lStartRec <= 0) {
						$this->lStartRec = 1;
					} elseif ($this->lStartRec >= intval(($this->lTotalRecs-1)/$this->lDisplayRecs)*$this->lDisplayRecs+1) {
						$this->lStartRec = intval(($this->lTotalRecs-1)/$this->lDisplayRecs)*$this->lDisplayRecs+1;
					}
					$p_villages->setStartRecordNumber($this->lStartRec);
				}
			}
		}
		$this->lStartRec = $p_villages->getStartRecordNumber();

		// Check if correct start record counter
		if (!is_numeric($this->lStartRec) || $this->lStartRec == "") { // Avoid invalid start record counter
			$this->lStartRec = 1; // Reset start record counter
			$p_villages->setStartRecordNumber($this->lStartRec);
		} elseif (intval($this->lStartRec) > intval($this->lTotalRecs)) { // Avoid starting record > total records
			$this->lStartRec = intval(($this->lTotalRecs-1)/$this->lDisplayRecs)*$this->lDisplayRecs+1; // Point to last page first record
			$p_villages->setStartRecordNumber($this->lStartRec);
		} elseif (($this->lStartRec-1) % $this->lDisplayRecs <> 0) {
			$this->lStartRec = intval(($this->lStartRec-1)/$this->lDisplayRecs)*$this->lDisplayRecs+1; // Point to page boundary
			$p_villages->setStartRecordNumber($this->lStartRec);
		}
	}

	// Load basic search values
	function LoadBasicSearchValues() {
		global $p_villages;
		$p_villages->BasicSearchKeyword = @$_GET[EW_TABLE_BASIC_SEARCH];
		$p_villages->BasicSearchType = @$_GET[EW_TABLE_BASIC_SEARCH_TYPE];
	}

	//  Load search values for validation
	function LoadSearchValues() {
		global $objForm, $p_villages;

		// Load search values
		// id

		$p_villages->id->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_id"]);
		$p_villages->id->AdvancedSearch->SearchOperator = @$_GET["z_id"];

		// rel_x
		$p_villages->rel_x->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_rel_x"]);
		$p_villages->rel_x->AdvancedSearch->SearchOperator = @$_GET["z_rel_x"];

		// rel_y
		$p_villages->rel_y->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_rel_y"]);
		$p_villages->rel_y->AdvancedSearch->SearchOperator = @$_GET["z_rel_y"];

		// field_maps_id
		$p_villages->field_maps_id->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_field_maps_id"]);
		$p_villages->field_maps_id->AdvancedSearch->SearchOperator = @$_GET["z_field_maps_id"];

		// image_num
		$p_villages->image_num->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_image_num"]);
		$p_villages->image_num->AdvancedSearch->SearchOperator = @$_GET["z_image_num"];

		// rand_num
		$p_villages->rand_num->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_rand_num"]);
		$p_villages->rand_num->AdvancedSearch->SearchOperator = @$_GET["z_rand_num"];

		// parent_id
		$p_villages->parent_id->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_parent_id"]);
		$p_villages->parent_id->AdvancedSearch->SearchOperator = @$_GET["z_parent_id"];

		// tribe_id
		$p_villages->tribe_id->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_tribe_id"]);
		$p_villages->tribe_id->AdvancedSearch->SearchOperator = @$_GET["z_tribe_id"];

		// player_id
		$p_villages->player_id->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_player_id"]);
		$p_villages->player_id->AdvancedSearch->SearchOperator = @$_GET["z_player_id"];

		// alliance_id
		$p_villages->alliance_id->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_alliance_id"]);
		$p_villages->alliance_id->AdvancedSearch->SearchOperator = @$_GET["z_alliance_id"];

		// player_name
		$p_villages->player_name->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_player_name"]);
		$p_villages->player_name->AdvancedSearch->SearchOperator = @$_GET["z_player_name"];

		// village_name
		$p_villages->village_name->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_village_name"]);
		$p_villages->village_name->AdvancedSearch->SearchOperator = @$_GET["z_village_name"];

		// alliance_name
		$p_villages->alliance_name->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_alliance_name"]);
		$p_villages->alliance_name->AdvancedSearch->SearchOperator = @$_GET["z_alliance_name"];

		// is_capital
		$p_villages->is_capital->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_is_capital"]);
		$p_villages->is_capital->AdvancedSearch->SearchOperator = @$_GET["z_is_capital"];

		// is_special_village
		$p_villages->is_special_village->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_is_special_village"]);
		$p_villages->is_special_village->AdvancedSearch->SearchOperator = @$_GET["z_is_special_village"];

		// is_oasis
		$p_villages->is_oasis->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_is_oasis"]);
		$p_villages->is_oasis->AdvancedSearch->SearchOperator = @$_GET["z_is_oasis"];

		// people_count
		$p_villages->people_count->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_people_count"]);
		$p_villages->people_count->AdvancedSearch->SearchOperator = @$_GET["z_people_count"];

		// crop_consumption
		$p_villages->crop_consumption->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_crop_consumption"]);
		$p_villages->crop_consumption->AdvancedSearch->SearchOperator = @$_GET["z_crop_consumption"];

		// time_consume_percent
		$p_villages->time_consume_percent->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_time_consume_percent"]);
		$p_villages->time_consume_percent->AdvancedSearch->SearchOperator = @$_GET["z_time_consume_percent"];

		// offer_merchants_count
		$p_villages->offer_merchants_count->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_offer_merchants_count"]);
		$p_villages->offer_merchants_count->AdvancedSearch->SearchOperator = @$_GET["z_offer_merchants_count"];

		// resources
		$p_villages->resources->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_resources"]);
		$p_villages->resources->AdvancedSearch->SearchOperator = @$_GET["z_resources"];

		// cp
		$p_villages->cp->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_cp"]);
		$p_villages->cp->AdvancedSearch->SearchOperator = @$_GET["z_cp"];

		// buildings
		$p_villages->buildings->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_buildings"]);
		$p_villages->buildings->AdvancedSearch->SearchOperator = @$_GET["z_buildings"];

		// troops_training
		$p_villages->troops_training->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_troops_training"]);
		$p_villages->troops_training->AdvancedSearch->SearchOperator = @$_GET["z_troops_training"];

		// troops_num
		$p_villages->troops_num->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_troops_num"]);
		$p_villages->troops_num->AdvancedSearch->SearchOperator = @$_GET["z_troops_num"];

		// troops_out_num
		$p_villages->troops_out_num->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_troops_out_num"]);
		$p_villages->troops_out_num->AdvancedSearch->SearchOperator = @$_GET["z_troops_out_num"];

		// troops_intrap_num
		$p_villages->troops_intrap_num->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_troops_intrap_num"]);
		$p_villages->troops_intrap_num->AdvancedSearch->SearchOperator = @$_GET["z_troops_intrap_num"];

		// troops_out_intrap_num
		$p_villages->troops_out_intrap_num->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_troops_out_intrap_num"]);
		$p_villages->troops_out_intrap_num->AdvancedSearch->SearchOperator = @$_GET["z_troops_out_intrap_num"];

		// troops_trapped_num
		$p_villages->troops_trapped_num->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_troops_trapped_num"]);
		$p_villages->troops_trapped_num->AdvancedSearch->SearchOperator = @$_GET["z_troops_trapped_num"];

		// allegiance_percent
		$p_villages->allegiance_percent->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_allegiance_percent"]);
		$p_villages->allegiance_percent->AdvancedSearch->SearchOperator = @$_GET["z_allegiance_percent"];

		// child_villages_id
		$p_villages->child_villages_id->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_child_villages_id"]);
		$p_villages->child_villages_id->AdvancedSearch->SearchOperator = @$_GET["z_child_villages_id"];

		// village_oases_id
		$p_villages->village_oases_id->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_village_oases_id"]);
		$p_villages->village_oases_id->AdvancedSearch->SearchOperator = @$_GET["z_village_oases_id"];

		// creation_date
		$p_villages->creation_date->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_creation_date"]);
		$p_villages->creation_date->AdvancedSearch->SearchOperator = @$_GET["z_creation_date"];

		// update_key
		$p_villages->update_key->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_update_key"]);
		$p_villages->update_key->AdvancedSearch->SearchOperator = @$_GET["z_update_key"];

		// last_update_date
		$p_villages->last_update_date->AdvancedSearch->SearchValue = ew_StripSlashes(@$_GET["x_last_update_date"]);
		$p_villages->last_update_date->AdvancedSearch->SearchOperator = @$_GET["z_last_update_date"];
	}

	// Load recordset
	function LoadRecordset($offset = -1, $rowcnt = -1) {
		global $conn, $p_villages;

		// Call Recordset Selecting event
		$p_villages->Recordset_Selecting($p_villages->CurrentFilter);

		// Load List page SQL
		$sSql = $p_villages->SelectSQL();
		if ($offset > -1 && $rowcnt > -1)
			$sSql .= " LIMIT $offset, $rowcnt";

		// Load recordset
		$rs = ew_LoadRecordset($sSql);

		// Call Recordset Selected event
		$p_villages->Recordset_Selected($rs);
		return $rs;
	}

	// Load row based on key values
	function LoadRow() {
		global $conn, $Security, $p_villages;
		$sFilter = $p_villages->KeyFilter();

		// Call Row Selecting event
		$p_villages->Row_Selecting($sFilter);

		// Load SQL based on filter
		$p_villages->CurrentFilter = $sFilter;
		$sSql = $p_villages->SQL();
		$res = FALSE;
		$rs = ew_LoadRecordset($sSql);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->LoadRowValues($rs); // Load row values

			// Call Row Selected event
			$p_villages->Row_Selected($rs);
			$rs->Close();
		}
		return $res;
	}

	// Load row values from recordset
	function LoadRowValues(&$rs) {
		global $conn, $p_villages;
		$p_villages->id->setDbValue($rs->fields('id'));
		$p_villages->rel_x->setDbValue($rs->fields('rel_x'));
		$p_villages->rel_y->setDbValue($rs->fields('rel_y'));
		$p_villages->field_maps_id->setDbValue($rs->fields('field_maps_id'));
		$p_villages->image_num->setDbValue($rs->fields('image_num'));
		$p_villages->rand_num->setDbValue($rs->fields('rand_num'));
		$p_villages->parent_id->setDbValue($rs->fields('parent_id'));
		$p_villages->tribe_id->setDbValue($rs->fields('tribe_id'));
		$p_villages->player_id->setDbValue($rs->fields('player_id'));
		$p_villages->alliance_id->setDbValue($rs->fields('alliance_id'));
		$p_villages->player_name->setDbValue($rs->fields('player_name'));
		$p_villages->village_name->setDbValue($rs->fields('village_name'));
		$p_villages->alliance_name->setDbValue($rs->fields('alliance_name'));
		$p_villages->is_capital->setDbValue($rs->fields('is_capital'));
		$p_villages->is_special_village->setDbValue($rs->fields('is_special_village'));
		$p_villages->is_oasis->setDbValue($rs->fields('is_oasis'));
		$p_villages->people_count->setDbValue($rs->fields('people_count'));
		$p_villages->crop_consumption->setDbValue($rs->fields('crop_consumption'));
		$p_villages->time_consume_percent->setDbValue($rs->fields('time_consume_percent'));
		$p_villages->offer_merchants_count->setDbValue($rs->fields('offer_merchants_count'));
		$p_villages->resources->setDbValue($rs->fields('resources'));
		$p_villages->cp->setDbValue($rs->fields('cp'));
		$p_villages->buildings->setDbValue($rs->fields('buildings'));
		$p_villages->troops_training->setDbValue($rs->fields('troops_training'));
		$p_villages->troops_num->setDbValue($rs->fields('troops_num'));
		$p_villages->troops_out_num->setDbValue($rs->fields('troops_out_num'));
		$p_villages->troops_intrap_num->setDbValue($rs->fields('troops_intrap_num'));
		$p_villages->troops_out_intrap_num->setDbValue($rs->fields('troops_out_intrap_num'));
		$p_villages->troops_trapped_num->setDbValue($rs->fields('troops_trapped_num'));
		$p_villages->allegiance_percent->setDbValue($rs->fields('allegiance_percent'));
		$p_villages->child_villages_id->setDbValue($rs->fields('child_villages_id'));
		$p_villages->village_oases_id->setDbValue($rs->fields('village_oases_id'));
		$p_villages->creation_date->setDbValue($rs->fields('creation_date'));
		$p_villages->update_key->setDbValue($rs->fields('update_key'));
		$p_villages->last_update_date->setDbValue($rs->fields('last_update_date'));
	}

	// Render row values based on field settings
	function RenderRow() {
		global $conn, $Security, $Language, $p_villages;

		// Initialize URLs
		$this->ViewUrl = $p_villages->ViewUrl();
		$this->EditUrl = $p_villages->EditUrl();
		$this->InlineEditUrl = $p_villages->InlineEditUrl();
		$this->CopyUrl = $p_villages->CopyUrl();
		$this->InlineCopyUrl = $p_villages->InlineCopyUrl();
		$this->DeleteUrl = $p_villages->DeleteUrl();

		// Call Row_Rendering event
		$p_villages->Row_Rendering();

		// Common render codes for all row types
		// id

		$p_villages->id->CellCssStyle = ""; $p_villages->id->CellCssClass = "";
		$p_villages->id->CellAttrs = array(); $p_villages->id->ViewAttrs = array(); $p_villages->id->EditAttrs = array();

		// player_name
		$p_villages->player_name->CellCssStyle = ""; $p_villages->player_name->CellCssClass = "";
		$p_villages->player_name->CellAttrs = array(); $p_villages->player_name->ViewAttrs = array(); $p_villages->player_name->EditAttrs = array();

		// village_name
		$p_villages->village_name->CellCssStyle = ""; $p_villages->village_name->CellCssClass = "";
		$p_villages->village_name->CellAttrs = array(); $p_villages->village_name->ViewAttrs = array(); $p_villages->village_name->EditAttrs = array();

		// is_capital
		$p_villages->is_capital->CellCssStyle = ""; $p_villages->is_capital->CellCssClass = "";
		$p_villages->is_capital->CellAttrs = array(); $p_villages->is_capital->ViewAttrs = array(); $p_villages->is_capital->EditAttrs = array();

		// is_special_village
		$p_villages->is_special_village->CellCssStyle = ""; $p_villages->is_special_village->CellCssClass = "";
		$p_villages->is_special_village->CellAttrs = array(); $p_villages->is_special_village->ViewAttrs = array(); $p_villages->is_special_village->EditAttrs = array();

		// people_count
		$p_villages->people_count->CellCssStyle = ""; $p_villages->people_count->CellCssClass = "";
		$p_villages->people_count->CellAttrs = array(); $p_villages->people_count->ViewAttrs = array(); $p_villages->people_count->EditAttrs = array();

		// crop_consumption
		$p_villages->crop_consumption->CellCssStyle = ""; $p_villages->crop_consumption->CellCssClass = "";
		$p_villages->crop_consumption->CellAttrs = array(); $p_villages->crop_consumption->ViewAttrs = array(); $p_villages->crop_consumption->EditAttrs = array();

		// resources
		$p_villages->resources->CellCssStyle = ""; $p_villages->resources->CellCssClass = "";
		$p_villages->resources->CellAttrs = array(); $p_villages->resources->ViewAttrs = array(); $p_villages->resources->EditAttrs = array();

		// cp
		$p_villages->cp->CellCssStyle = ""; $p_villages->cp->CellCssClass = "";
		$p_villages->cp->CellAttrs = array(); $p_villages->cp->ViewAttrs = array(); $p_villages->cp->EditAttrs = array();

		// buildings
		$p_villages->buildings->CellCssStyle = ""; $p_villages->buildings->CellCssClass = "";
		$p_villages->buildings->CellAttrs = array(); $p_villages->buildings->ViewAttrs = array(); $p_villages->buildings->EditAttrs = array();

		// troops_num
		$p_villages->troops_num->CellCssStyle = ""; $p_villages->troops_num->CellCssClass = "";
		$p_villages->troops_num->CellAttrs = array(); $p_villages->troops_num->ViewAttrs = array(); $p_villages->troops_num->EditAttrs = array();
		if ($p_villages->RowType == EW_ROWTYPE_VIEW) { // View row

			// id
			$p_villages->id->ViewValue = $p_villages->id->CurrentValue;
			$p_villages->id->CssStyle = "";
			$p_villages->id->CssClass = "";
			$p_villages->id->ViewCustomAttributes = "";

			// player_name
			$p_villages->player_name->ViewValue = $p_villages->player_name->CurrentValue;
			$p_villages->player_name->CssStyle = "";
			$p_villages->player_name->CssClass = "";
			$p_villages->player_name->ViewCustomAttributes = "";

			// village_name
			$p_villages->village_name->ViewValue = $p_villages->village_name->CurrentValue;
			$p_villages->village_name->CssStyle = "";
			$p_villages->village_name->CssClass = "";
			$p_villages->village_name->ViewCustomAttributes = "";

			// is_capital
			$p_villages->is_capital->ViewValue = $p_villages->is_capital->CurrentValue;
			$p_villages->is_capital->CssStyle = "";
			$p_villages->is_capital->CssClass = "";
			$p_villages->is_capital->ViewCustomAttributes = "";

			// is_special_village
			$p_villages->is_special_village->ViewValue = $p_villages->is_special_village->CurrentValue;
			$p_villages->is_special_village->CssStyle = "";
			$p_villages->is_special_village->CssClass = "";
			$p_villages->is_special_village->ViewCustomAttributes = "";

			// people_count
			$p_villages->people_count->ViewValue = $p_villages->people_count->CurrentValue;
			$p_villages->people_count->CssStyle = "";
			$p_villages->people_count->CssClass = "";
			$p_villages->people_count->ViewCustomAttributes = "";

			// crop_consumption
			$p_villages->crop_consumption->ViewValue = $p_villages->crop_consumption->CurrentValue;
			$p_villages->crop_consumption->CssStyle = "";
			$p_villages->crop_consumption->CssClass = "";
			$p_villages->crop_consumption->ViewCustomAttributes = "";

			// resources
			$p_villages->resources->ViewValue = $p_villages->resources->CurrentValue;
			$p_villages->resources->CssStyle = "";
			$p_villages->resources->CssClass = "";
			$p_villages->resources->ViewCustomAttributes = "";

			// cp
			$p_villages->cp->ViewValue = $p_villages->cp->CurrentValue;
			$p_villages->cp->CssStyle = "";
			$p_villages->cp->CssClass = "";
			$p_villages->cp->ViewCustomAttributes = "";

			// buildings
			$p_villages->buildings->ViewValue = $p_villages->buildings->CurrentValue;
			$p_villages->buildings->CssStyle = "";
			$p_villages->buildings->CssClass = "";
			$p_villages->buildings->ViewCustomAttributes = "";

			// troops_num
			$p_villages->troops_num->ViewValue = $p_villages->troops_num->CurrentValue;
			$p_villages->troops_num->CssStyle = "";
			$p_villages->troops_num->CssClass = "";
			$p_villages->troops_num->ViewCustomAttributes = "";

			// id
			$p_villages->id->HrefValue = "";
			$p_villages->id->TooltipValue = "";

			// player_name
			$p_villages->player_name->HrefValue = "";
			$p_villages->player_name->TooltipValue = "";

			// village_name
			$p_villages->village_name->HrefValue = "";
			$p_villages->village_name->TooltipValue = "";

			// is_capital
			$p_villages->is_capital->HrefValue = "";
			$p_villages->is_capital->TooltipValue = "";

			// is_special_village
			$p_villages->is_special_village->HrefValue = "";
			$p_villages->is_special_village->TooltipValue = "";

			// people_count
			$p_villages->people_count->HrefValue = "";
			$p_villages->people_count->TooltipValue = "";

			// crop_consumption
			$p_villages->crop_consumption->HrefValue = "";
			$p_villages->crop_consumption->TooltipValue = "";

			// resources
			$p_villages->resources->HrefValue = "";
			$p_villages->resources->TooltipValue = "";

			// cp
			$p_villages->cp->HrefValue = "";
			$p_villages->cp->TooltipValue = "";

			// buildings
			$p_villages->buildings->HrefValue = "";
			$p_villages->buildings->TooltipValue = "";

			// troops_num
			$p_villages->troops_num->HrefValue = "";
			$p_villages->troops_num->TooltipValue = "";
		} elseif ($p_villages->RowType == EW_ROWTYPE_SEARCH) { // Search row

			// id
			$p_villages->id->EditCustomAttributes = "";
			$p_villages->id->EditValue = ew_HtmlEncode($p_villages->id->AdvancedSearch->SearchValue);

			// player_name
			$p_villages->player_name->EditCustomAttributes = "";
			$p_villages->player_name->EditValue = ew_HtmlEncode($p_villages->player_name->AdvancedSearch->SearchValue);

			// village_name
			$p_villages->village_name->EditCustomAttributes = "";
			$p_villages->village_name->EditValue = ew_HtmlEncode($p_villages->village_name->AdvancedSearch->SearchValue);

			// is_capital
			$p_villages->is_capital->EditCustomAttributes = "";
			$p_villages->is_capital->EditValue = ew_HtmlEncode($p_villages->is_capital->AdvancedSearch->SearchValue);

			// is_special_village
			$p_villages->is_special_village->EditCustomAttributes = "";
			$p_villages->is_special_village->EditValue = ew_HtmlEncode($p_villages->is_special_village->AdvancedSearch->SearchValue);

			// people_count
			$p_villages->people_count->EditCustomAttributes = "";
			$p_villages->people_count->EditValue = ew_HtmlEncode($p_villages->people_count->AdvancedSearch->SearchValue);

			// crop_consumption
			$p_villages->crop_consumption->EditCustomAttributes = "";
			$p_villages->crop_consumption->EditValue = ew_HtmlEncode($p_villages->crop_consumption->AdvancedSearch->SearchValue);

			// resources
			$p_villages->resources->EditCustomAttributes = "";
			$p_villages->resources->EditValue = ew_HtmlEncode($p_villages->resources->AdvancedSearch->SearchValue);

			// cp
			$p_villages->cp->EditCustomAttributes = "";
			$p_villages->cp->EditValue = ew_HtmlEncode($p_villages->cp->AdvancedSearch->SearchValue);

			// buildings
			$p_villages->buildings->EditCustomAttributes = "";
			$p_villages->buildings->EditValue = ew_HtmlEncode($p_villages->buildings->AdvancedSearch->SearchValue);

			// troops_num
			$p_villages->troops_num->EditCustomAttributes = "";
			$p_villages->troops_num->EditValue = ew_HtmlEncode($p_villages->troops_num->AdvancedSearch->SearchValue);
		}

		// Call Row Rendered event
		if ($p_villages->RowType <> EW_ROWTYPE_AGGREGATEINIT)
			$p_villages->Row_Rendered();
	}

	// Validate search
	function ValidateSearch() {
		global $gsSearchError, $p_villages;

		// Initialize
		$gsSearchError = "";

		// Check if validation required
		if (!EW_SERVER_VALIDATE)
			return TRUE;
		if (!ew_CheckInteger($p_villages->id->AdvancedSearch->SearchValue)) {
			if ($gsSearchError <> "") $gsSearchError .= "<br>";
			$gsSearchError .= $p_villages->id->FldErrMsg();
		}

		// Return validate result
		$ValidateSearch = ($gsSearchError == "");

		// Call Form_CustomValidate event
		$sFormCustomError = "";
		$ValidateSearch = $ValidateSearch && $this->Form_CustomValidate($sFormCustomError);
		if ($sFormCustomError <> "") {
			if ($gsSearchError <> "") $gsSearchError .= "<br>";
			$gsSearchError .= $sFormCustomError;
		}
		return $ValidateSearch;
	}

	// Load advanced search
	function LoadAdvancedSearch() {
		global $p_villages;
		$p_villages->id->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_id");
		$p_villages->rel_x->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_rel_x");
		$p_villages->rel_y->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_rel_y");
		$p_villages->field_maps_id->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_field_maps_id");
		$p_villages->image_num->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_image_num");
		$p_villages->rand_num->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_rand_num");
		$p_villages->parent_id->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_parent_id");
		$p_villages->tribe_id->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_tribe_id");
		$p_villages->player_id->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_player_id");
		$p_villages->alliance_id->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_alliance_id");
		$p_villages->player_name->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_player_name");
		$p_villages->village_name->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_village_name");
		$p_villages->alliance_name->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_alliance_name");
		$p_villages->is_capital->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_is_capital");
		$p_villages->is_special_village->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_is_special_village");
		$p_villages->is_oasis->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_is_oasis");
		$p_villages->people_count->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_people_count");
		$p_villages->crop_consumption->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_crop_consumption");
		$p_villages->time_consume_percent->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_time_consume_percent");
		$p_villages->offer_merchants_count->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_offer_merchants_count");
		$p_villages->resources->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_resources");
		$p_villages->cp->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_cp");
		$p_villages->buildings->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_buildings");
		$p_villages->troops_training->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_troops_training");
		$p_villages->troops_num->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_troops_num");
		$p_villages->troops_out_num->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_troops_out_num");
		$p_villages->troops_intrap_num->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_troops_intrap_num");
		$p_villages->troops_out_intrap_num->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_troops_out_intrap_num");
		$p_villages->troops_trapped_num->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_troops_trapped_num");
		$p_villages->allegiance_percent->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_allegiance_percent");
		$p_villages->child_villages_id->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_child_villages_id");
		$p_villages->village_oases_id->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_village_oases_id");
		$p_villages->creation_date->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_creation_date");
		$p_villages->update_key->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_update_key");
		$p_villages->last_update_date->AdvancedSearch->SearchValue = $p_villages->getAdvancedSearch("x_last_update_date");
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	function Message_Showing(&$msg) {

		// Example:
		//$msg = "your new message";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$CustomError) {

		// Return error message in CustomError
		return TRUE;
	}

	// ListOptions Load event
	function ListOptions_Load() {

		// Example: 
		//$this->ListOptions->Add("new");
		//$this->ListOptions->Items["new"]->OnLeft = TRUE; // Link on left
		//$this->ListOptions->MoveItem("new", 0); // Move to first column

	}

	// ListOptions Rendered event
	function ListOptions_Rendered() {

		// Example: 
		//$this->ListOptions->Items["new"]->Body = "xxx";

	}
}
?>
