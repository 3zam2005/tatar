<?php
session_start(); // Initialize Session data
ob_start(); // Turn on output buffering
?>
<?php include "ewcfg7.php" ?>
<?php include "ewmysql7.php" ?>
<?php include "phpfn7.php" ?>
<?php include "p_playersinfo.php" ?>
<?php include "userfn7.php" ?>
<?php

// Create page object
$p_players_edit = new cp_players_edit();
$Page =& $p_players_edit;

// Page init
$p_players_edit->Page_Init();

// Page main
$p_players_edit->Page_Main();
?>
<?php include "header.php" ?>
<script type="text/javascript">
<!--

// Create page object
var p_players_edit = new ew_Page("p_players_edit");

// page properties
p_players_edit.PageID = "edit"; // page ID
p_players_edit.FormID = "fp_playersedit"; // form ID
var EW_PAGE_ID = p_players_edit.PageID; // for backward compatibility

// extend page with ValidateForm function
p_players_edit.ValidateForm = function(fobj) {
	ew_PostAutoSuggest(fobj);
	if (!this.ValidateRequired)
		return true; // ignore validation
	if (fobj.a_confirm && fobj.a_confirm.value == "F")
		return true;
	var i, elm, aelm, infix;
	var rowcnt = (fobj.key_count) ? Number(fobj.key_count.value) : 1;
	for (i=0; i<rowcnt; i++) {
		infix = (fobj.key_count) ? String(i+1) : "";
		elm = fobj.elements["x" + infix + "_is_active"];
		if (elm && !ew_CheckInteger(elm.value))
			return ew_OnError(this, elm, "<?php echo ew_JsEncode2($p_players->is_active->FldErrMsg()) ?>");
		elm = fobj.elements["x" + infix + "_active_plus_account"];
		if (elm && !ew_CheckInteger(elm.value))
			return ew_OnError(this, elm, "<?php echo ew_JsEncode2($p_players->active_plus_account->FldErrMsg()) ?>");
		elm = fobj.elements["x" + infix + "_gold_num"];
		if (elm && !ew_CheckInteger(elm.value))
			return ew_OnError(this, elm, "<?php echo ew_JsEncode2($p_players->gold_num->FldErrMsg()) ?>");
		elm = fobj.elements["x" + infix + "_total_people_count"];
		if (elm && !ew_CheckInteger(elm.value))
			return ew_OnError(this, elm, "<?php echo ew_JsEncode2($p_players->total_people_count->FldErrMsg()) ?>");

		// Call Form Custom Validate event
		if (!this.Form_CustomValidate(fobj)) return false;
	}
	return true;
}

// extend page with Form_CustomValidate function
p_players_edit.Form_CustomValidate =  
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }
<?php if (EW_CLIENT_VALIDATE) { ?>
p_players_edit.ValidateRequired = true; // uses JavaScript validation
<?php } else { ?>
p_players_edit.ValidateRequired = false; // no JavaScript validation
<?php } ?>

//-->
</script>
<script type="text/javascript">
<!--
var ew_DHTMLEditors = [];

//-->
</script>
<script language="JavaScript" type="text/javascript">
<!--

// Write your client script here, no need to add script tags.
// To include another .js script, use:
// ew_ClientScriptInclude("my_javascript.js"); 
//-->

</script>
<p><span class="phpmaker"><?php echo $Language->Phrase("Edit") ?>&nbsp;<?php echo $Language->Phrase("TblTypeTABLE") ?><?php echo $p_players->TableCaption() ?><br><br>
<a href="<?php echo $p_players->getReturnUrl() ?>"><?php echo $Language->Phrase("GoBack") ?></a></span></p>
<?php
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
$p_players_edit->ShowMessage();
?>
<form name="fp_playersedit" id="fp_playersedit" action="<?php echo ew_CurrentPage() ?>" method="post" onsubmit="return p_players_edit.ValidateForm(this);">
<p>
<input type="hidden" name="a_table" id="a_table" value="p_players">
<input type="hidden" name="a_edit" id="a_edit" value="U">
<table cellspacing="0" class="ewGrid"><tr><td class="ewGridContent">
<div class="ewGridMiddlePanel">
<table cellspacing="0" class="ewTable">
<?php if ($p_players->id->Visible) { // id ?>
	<tr<?php echo $p_players->id->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_players->id->FldCaption() ?></td>
		<td<?php echo $p_players->id->CellAttributes() ?>><span id="el_id">
<div<?php echo $p_players->id->ViewAttributes() ?>><?php echo $p_players->id->EditValue ?></div><input type="hidden" name="x_id" id="x_id" value="<?php echo ew_HtmlEncode($p_players->id->CurrentValue) ?>">
</span><?php echo $p_players->id->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_players->name->Visible) { // name ?>
	<tr<?php echo $p_players->name->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_players->name->FldCaption() ?></td>
		<td<?php echo $p_players->name->CellAttributes() ?>><span id="el_name">
<input type="text" name="x_name" id="x_name" title="<?php echo $p_players->name->FldTitle() ?>" size="30" maxlength="255" value="<?php echo $p_players->name->EditValue ?>"<?php echo $p_players->name->EditAttributes() ?>>
</span><?php echo $p_players->name->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_players->is_active->Visible) { // is_active ?>
	<tr<?php echo $p_players->is_active->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_players->is_active->FldCaption() ?></td>
		<td<?php echo $p_players->is_active->CellAttributes() ?>><span id="el_is_active">
<input type="text" name="x_is_active" id="x_is_active" title="<?php echo $p_players->is_active->FldTitle() ?>" size="30" value="<?php echo $p_players->is_active->EditValue ?>"<?php echo $p_players->is_active->EditAttributes() ?>>
</span><?php echo $p_players->is_active->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_players->active_plus_account->Visible) { // active_plus_account ?>
	<tr<?php echo $p_players->active_plus_account->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_players->active_plus_account->FldCaption() ?></td>
		<td<?php echo $p_players->active_plus_account->CellAttributes() ?>><span id="el_active_plus_account">
<input type="text" name="x_active_plus_account" id="x_active_plus_account" title="<?php echo $p_players->active_plus_account->FldTitle() ?>" size="30" value="<?php echo $p_players->active_plus_account->EditValue ?>"<?php echo $p_players->active_plus_account->EditAttributes() ?>>
</span><?php echo $p_players->active_plus_account->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_players->gold_num->Visible) { // gold_num ?>
	<tr<?php echo $p_players->gold_num->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_players->gold_num->FldCaption() ?></td>
		<td<?php echo $p_players->gold_num->CellAttributes() ?>><span id="el_gold_num">
<input type="text" name="x_gold_num" id="x_gold_num" title="<?php echo $p_players->gold_num->FldTitle() ?>" size="30" value="<?php echo $p_players->gold_num->EditValue ?>"<?php echo $p_players->gold_num->EditAttributes() ?>>
</span><?php echo $p_players->gold_num->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($p_players->total_people_count->Visible) { // total_people_count ?>
	<tr<?php echo $p_players->total_people_count->RowAttributes ?>>
		<td class="ewTableHeader"><?php echo $p_players->total_people_count->FldCaption() ?></td>
		<td<?php echo $p_players->total_people_count->CellAttributes() ?>><span id="el_total_people_count">
<input type="text" name="x_total_people_count" id="x_total_people_count" title="<?php echo $p_players->total_people_count->FldTitle() ?>" size="30" value="<?php echo $p_players->total_people_count->EditValue ?>"<?php echo $p_players->total_people_count->EditAttributes() ?>>
</span><?php echo $p_players->total_people_count->CustomMsg ?></td>
	</tr>
<?php } ?>
</table>
</div>
</td></tr></table>
<p>
<input type="submit" name="btnAction" id="btnAction" value="<?php echo ew_BtnCaption($Language->Phrase("EditBtn")) ?>">
</form>
<script language="JavaScript" type="text/javascript">
<!--

// Write your table-specific startup script here
// document.write("page loaded");
//-->

</script>
<?php include "footer.php" ?>
<?php
$p_players_edit->Page_Terminate();
?>
<?php

//
// Page class
//
class cp_players_edit {

	// Page ID
	var $PageID = 'edit';

	// Table name
	var $TableName = 'p_players';

	// Page object name
	var $PageObjName = 'p_players_edit';

	// Page name
	function PageName() {
		return ew_CurrentPage();
	}

	// Page URL
	function PageUrl() {
		$PageUrl = ew_CurrentPage() . "?";
		global $p_players;
		if ($p_players->UseTokenInUrl) $PageUrl .= "t=" . $p_players->TableVar . "&"; // Add page token
		return $PageUrl;
	}

	// Page URLs
	var $AddUrl;
	var $EditUrl;
	var $CopyUrl;
	var $DeleteUrl;
	var $ViewUrl;
	var $ListUrl;

	// Export URLs
	var $ExportPrintUrl;
	var $ExportHtmlUrl;
	var $ExportExcelUrl;
	var $ExportWordUrl;
	var $ExportXmlUrl;
	var $ExportCsvUrl;

	// Update URLs
	var $InlineAddUrl;
	var $InlineCopyUrl;
	var $InlineEditUrl;
	var $GridAddUrl;
	var $GridEditUrl;
	var $MultiDeleteUrl;
	var $MultiUpdateUrl;

	// Message
	function getMessage() {
		return @$_SESSION[EW_SESSION_MESSAGE];
	}

	function setMessage($v) {
		if (@$_SESSION[EW_SESSION_MESSAGE] <> "") { // Append
			$_SESSION[EW_SESSION_MESSAGE] .= "<br>" . $v;
		} else {
			$_SESSION[EW_SESSION_MESSAGE] = $v;
		}
	}

	// Show message
	function ShowMessage() {
		$sMessage = $this->getMessage();
		$this->Message_Showing($sMessage);
		if ($sMessage <> "") { // Message in Session, display
			echo "<p><span class=\"ewMessage\">" . $sMessage . "</span></p>";
			$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message in Session
		}
	}

	// Validate page request
	function IsPageRequest() {
		global $objForm, $p_players;
		if ($p_players->UseTokenInUrl) {
			if ($objForm)
				return ($p_players->TableVar == $objForm->GetValue("t"));
			if (@$_GET["t"] <> "")
				return ($p_players->TableVar == $_GET["t"]);
		} else {
			return TRUE;
		}
	}

	//
	// Page class constructor
	//
	function cp_players_edit() {
		global $conn, $Language;

		// Language object
		$Language = new cLanguage();

		// Table object (p_players)
		$GLOBALS["p_players"] = new cp_players();

		// Page ID
		if (!defined("EW_PAGE_ID"))
			define("EW_PAGE_ID", 'edit', TRUE);

		// Table name (for backward compatibility)
		if (!defined("EW_TABLE_NAME"))
			define("EW_TABLE_NAME", 'p_players', TRUE);

		// Start timer
		$GLOBALS["gsTimer"] = new cTimer();

		// Open connection
		$conn = ew_Connect();
	}

	// 
	//  Page_Init
	//
	function Page_Init() {
		global $gsExport, $gsExportFile, $UserProfile, $Language, $Security, $objForm;
		global $p_players;

		// Security
		$Security = new cAdvancedSecurity();
		if (!$Security->IsLoggedIn()) $Security->AutoLogin();
		if (!$Security->IsLoggedIn()) {
			$Security->SaveLastUrl();
			$this->Page_Terminate("login.php");
		}

		// Create form object
		$objForm = new cFormObj();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();
	}

	//
	// Page_Terminate
	//
	function Page_Terminate($url = "") {
		global $conn;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		 // Close connection
		$conn->Close();

		// Go to URL if specified
		$this->Page_Redirecting($url);
		if ($url <> "") {
			if (!EW_DEBUG_ENABLED && ob_get_length())
				ob_end_clean();
			header("Location: " . $url);
		}
		exit();
	}
	var $sDbMasterFilter;
	var $sDbDetailFilter;

	// 
	// Page main
	//
	function Page_Main() {
		global $objForm, $Language, $gsFormError, $p_players;

		// Load key from QueryString
		if (@$_GET["id"] <> "")
			$p_players->id->setQueryStringValue($_GET["id"]);
		if (@$_POST["a_edit"] <> "") {
			$p_players->CurrentAction = $_POST["a_edit"]; // Get action code
			$this->LoadFormValues(); // Get form values

			// Validate form
			if (!$this->ValidateForm()) {
				$p_players->CurrentAction = ""; // Form error, reset action
				$this->setMessage($gsFormError);
				$p_players->EventCancelled = TRUE; // Event cancelled
				$this->RestoreFormValues();
			}
		} else {
			$p_players->CurrentAction = "I"; // Default action is display
		}

		// Check if valid key
		if ($p_players->id->CurrentValue == "")
			$this->Page_Terminate("p_playerslist.php"); // Invalid key, return to list
		switch ($p_players->CurrentAction) {
			case "I": // Get a record to display
				if (!$this->LoadRow()) { // Load record based on key
					$this->setMessage($Language->Phrase("NoRecord")); // No record found
					$this->Page_Terminate("p_playerslist.php"); // No matching record, return to list
				}
				break;
			Case "U": // Update
				$p_players->SendEmail = TRUE; // Send email on update success
				if ($this->EditRow()) { // Update record based on key
					$this->setMessage($Language->Phrase("UpdateSuccess")); // Update success
					$sReturnUrl = $p_players->getReturnUrl();
					$this->Page_Terminate($sReturnUrl); // Return to caller
				} else {
					$p_players->EventCancelled = TRUE; // Event cancelled
					$this->RestoreFormValues(); // Restore form values if update failed
				}
		}

		// Render the record
		$p_players->RowType = EW_ROWTYPE_EDIT; // Render as Edit
		$this->RenderRow();
	}

	// Get upload files
	function GetUploadFiles() {
		global $objForm, $p_players;

		// Get upload data
	}

	// Load form values
	function LoadFormValues() {

		// Load from form
		global $objForm, $p_players;
		$p_players->id->setFormValue($objForm->GetValue("x_id"));
		$p_players->name->setFormValue($objForm->GetValue("x_name"));
		$p_players->is_active->setFormValue($objForm->GetValue("x_is_active"));
		$p_players->active_plus_account->setFormValue($objForm->GetValue("x_active_plus_account"));
		$p_players->gold_num->setFormValue($objForm->GetValue("x_gold_num"));
		$p_players->total_people_count->setFormValue($objForm->GetValue("x_total_people_count"));
	}

	// Restore form values
	function RestoreFormValues() {
		global $objForm, $p_players;
		$this->LoadRow();
		$p_players->id->CurrentValue = $p_players->id->FormValue;
		$p_players->name->CurrentValue = $p_players->name->FormValue;
		$p_players->is_active->CurrentValue = $p_players->is_active->FormValue;
		$p_players->active_plus_account->CurrentValue = $p_players->active_plus_account->FormValue;
		$p_players->gold_num->CurrentValue = $p_players->gold_num->FormValue;
		$p_players->total_people_count->CurrentValue = $p_players->total_people_count->FormValue;
	}

	// Load row based on key values
	function LoadRow() {
		global $conn, $Security, $p_players;
		$sFilter = $p_players->KeyFilter();

		// Call Row Selecting event
		$p_players->Row_Selecting($sFilter);

		// Load SQL based on filter
		$p_players->CurrentFilter = $sFilter;
		$sSql = $p_players->SQL();
		$res = FALSE;
		$rs = ew_LoadRecordset($sSql);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->LoadRowValues($rs); // Load row values

			// Call Row Selected event
			$p_players->Row_Selected($rs);
			$rs->Close();
		}
		return $res;
	}

	// Load row values from recordset
	function LoadRowValues(&$rs) {
		global $conn, $p_players;
		$p_players->id->setDbValue($rs->fields('id'));
		$p_players->tribe_id->setDbValue($rs->fields('tribe_id'));
		$p_players->alliance_id->setDbValue($rs->fields('alliance_id'));
		$p_players->alliance_name->setDbValue($rs->fields('alliance_name'));
		$p_players->alliance_roles->setDbValue($rs->fields('alliance_roles'));
		$p_players->invites_alliance_ids->setDbValue($rs->fields('invites_alliance_ids'));
		$p_players->name->setDbValue($rs->fields('name'));
		$p_players->pwd->setDbValue($rs->fields('pwd'));
		$p_players->zemail->setDbValue($rs->fields('email'));
		$p_players->is_active->setDbValue($rs->fields('is_active'));
		$p_players->is_blocked->setDbValue($rs->fields('is_blocked'));
		$p_players->player_type->setDbValue($rs->fields('player_type'));
		$p_players->active_plus_account->setDbValue($rs->fields('active_plus_account'));
		$p_players->activation_code->setDbValue($rs->fields('activation_code'));
		$p_players->last_login_date->setDbValue($rs->fields('last_login_date'));
		$p_players->last_ip->setDbValue($rs->fields('last_ip'));
		$p_players->birth_date->setDbValue($rs->fields('birth_date'));
		$p_players->gender->setDbValue($rs->fields('gender'));
		$p_players->description1->setDbValue($rs->fields('description1'));
		$p_players->description2->setDbValue($rs->fields('description2'));
		$p_players->house_name->setDbValue($rs->fields('house_name'));
		$p_players->registration_date->setDbValue($rs->fields('registration_date'));
		$p_players->gold_num->setDbValue($rs->fields('gold_num'));
		$p_players->agent_for_players->setDbValue($rs->fields('agent_for_players'));
		$p_players->my_agent_players->setDbValue($rs->fields('my_agent_players'));
		$p_players->custom_links->setDbValue($rs->fields('custom_links'));
		$p_players->medals->setDbValue($rs->fields('medals'));
		$p_players->total_people_count->setDbValue($rs->fields('total_people_count'));
		$p_players->selected_village_id->setDbValue($rs->fields('selected_village_id'));
		$p_players->villages_count->setDbValue($rs->fields('villages_count'));
		$p_players->villages_id->setDbValue($rs->fields('villages_id'));
		$p_players->villages_data->setDbValue($rs->fields('villages_data'));
		$p_players->friend_players->setDbValue($rs->fields('friend_players'));
		$p_players->notes->setDbValue($rs->fields('notes'));
		$p_players->hero_troop_id->setDbValue($rs->fields('hero_troop_id'));
		$p_players->hero_level->setDbValue($rs->fields('hero_level'));
		$p_players->hero_points->setDbValue($rs->fields('hero_points'));
		$p_players->hero_name->setDbValue($rs->fields('hero_name'));
		$p_players->hero_in_village_id->setDbValue($rs->fields('hero_in_village_id'));
		$p_players->attack_points->setDbValue($rs->fields('attack_points'));
		$p_players->defense_points->setDbValue($rs->fields('defense_points'));
		$p_players->week_attack_points->setDbValue($rs->fields('week_attack_points'));
		$p_players->week_defense_points->setDbValue($rs->fields('week_defense_points'));
		$p_players->week_dev_points->setDbValue($rs->fields('week_dev_points'));
		$p_players->week_thief_points->setDbValue($rs->fields('week_thief_points'));
		$p_players->new_report_count->setDbValue($rs->fields('new_report_count'));
		$p_players->new_mail_count->setDbValue($rs->fields('new_mail_count'));
		$p_players->guide_quiz->setDbValue($rs->fields('guide_quiz'));
	}

	// Render row values based on field settings
	function RenderRow() {
		global $conn, $Security, $Language, $p_players;

		// Initialize URLs
		// Call Row_Rendering event

		$p_players->Row_Rendering();

		// Common render codes for all row types
		// id

		$p_players->id->CellCssStyle = ""; $p_players->id->CellCssClass = "";
		$p_players->id->CellAttrs = array(); $p_players->id->ViewAttrs = array(); $p_players->id->EditAttrs = array();

		// name
		$p_players->name->CellCssStyle = ""; $p_players->name->CellCssClass = "";
		$p_players->name->CellAttrs = array(); $p_players->name->ViewAttrs = array(); $p_players->name->EditAttrs = array();

		// is_active
		$p_players->is_active->CellCssStyle = ""; $p_players->is_active->CellCssClass = "";
		$p_players->is_active->CellAttrs = array(); $p_players->is_active->ViewAttrs = array(); $p_players->is_active->EditAttrs = array();

		// active_plus_account
		$p_players->active_plus_account->CellCssStyle = ""; $p_players->active_plus_account->CellCssClass = "";
		$p_players->active_plus_account->CellAttrs = array(); $p_players->active_plus_account->ViewAttrs = array(); $p_players->active_plus_account->EditAttrs = array();

		// gold_num
		$p_players->gold_num->CellCssStyle = ""; $p_players->gold_num->CellCssClass = "";
		$p_players->gold_num->CellAttrs = array(); $p_players->gold_num->ViewAttrs = array(); $p_players->gold_num->EditAttrs = array();

		// total_people_count
		$p_players->total_people_count->CellCssStyle = ""; $p_players->total_people_count->CellCssClass = "";
		$p_players->total_people_count->CellAttrs = array(); $p_players->total_people_count->ViewAttrs = array(); $p_players->total_people_count->EditAttrs = array();
		if ($p_players->RowType == EW_ROWTYPE_VIEW) { // View row

			// id
			$p_players->id->ViewValue = $p_players->id->CurrentValue;
			$p_players->id->CssStyle = "";
			$p_players->id->CssClass = "";
			$p_players->id->ViewCustomAttributes = "";

			// name
			$p_players->name->ViewValue = $p_players->name->CurrentValue;
			$p_players->name->CssStyle = "";
			$p_players->name->CssClass = "";
			$p_players->name->ViewCustomAttributes = "";

			// is_active
			$p_players->is_active->ViewValue = $p_players->is_active->CurrentValue;
			$p_players->is_active->CssStyle = "";
			$p_players->is_active->CssClass = "";
			$p_players->is_active->ViewCustomAttributes = "";

			// active_plus_account
			$p_players->active_plus_account->ViewValue = $p_players->active_plus_account->CurrentValue;
			$p_players->active_plus_account->CssStyle = "";
			$p_players->active_plus_account->CssClass = "";
			$p_players->active_plus_account->ViewCustomAttributes = "";

			// last_ip
			$p_players->last_ip->ViewValue = $p_players->last_ip->CurrentValue;
			$p_players->last_ip->CssStyle = "";
			$p_players->last_ip->CssClass = "";
			$p_players->last_ip->ViewCustomAttributes = "";

			// gold_num
			$p_players->gold_num->ViewValue = $p_players->gold_num->CurrentValue;
			$p_players->gold_num->CssStyle = "";
			$p_players->gold_num->CssClass = "";
			$p_players->gold_num->ViewCustomAttributes = "";

			// total_people_count
			$p_players->total_people_count->ViewValue = $p_players->total_people_count->CurrentValue;
			$p_players->total_people_count->CssStyle = "";
			$p_players->total_people_count->CssClass = "";
			$p_players->total_people_count->ViewCustomAttributes = "";

			// id
			$p_players->id->HrefValue = "";
			$p_players->id->TooltipValue = "";

			// name
			$p_players->name->HrefValue = "";
			$p_players->name->TooltipValue = "";

			// is_active
			$p_players->is_active->HrefValue = "";
			$p_players->is_active->TooltipValue = "";

			// active_plus_account
			$p_players->active_plus_account->HrefValue = "";
			$p_players->active_plus_account->TooltipValue = "";

			// gold_num
			$p_players->gold_num->HrefValue = "";
			$p_players->gold_num->TooltipValue = "";

			// total_people_count
			$p_players->total_people_count->HrefValue = "";
			$p_players->total_people_count->TooltipValue = "";
		} elseif ($p_players->RowType == EW_ROWTYPE_EDIT) { // Edit row

			// id
			$p_players->id->EditCustomAttributes = "";
			$p_players->id->EditValue = $p_players->id->CurrentValue;
			$p_players->id->CssStyle = "";
			$p_players->id->CssClass = "";
			$p_players->id->ViewCustomAttributes = "";

			// name
			$p_players->name->EditCustomAttributes = "";
			$p_players->name->EditValue = ew_HtmlEncode($p_players->name->CurrentValue);

			// is_active
			$p_players->is_active->EditCustomAttributes = "";
			$p_players->is_active->EditValue = ew_HtmlEncode($p_players->is_active->CurrentValue);

			// active_plus_account
			$p_players->active_plus_account->EditCustomAttributes = "";
			$p_players->active_plus_account->EditValue = ew_HtmlEncode($p_players->active_plus_account->CurrentValue);

			// gold_num
			$p_players->gold_num->EditCustomAttributes = "";
			$p_players->gold_num->EditValue = ew_HtmlEncode($p_players->gold_num->CurrentValue);

			// total_people_count
			$p_players->total_people_count->EditCustomAttributes = "";
			$p_players->total_people_count->EditValue = ew_HtmlEncode($p_players->total_people_count->CurrentValue);

			// Edit refer script
			// id

			$p_players->id->HrefValue = "";

			// name
			$p_players->name->HrefValue = "";

			// is_active
			$p_players->is_active->HrefValue = "";

			// active_plus_account
			$p_players->active_plus_account->HrefValue = "";

			// gold_num
			$p_players->gold_num->HrefValue = "";

			// total_people_count
			$p_players->total_people_count->HrefValue = "";
		}

		// Call Row Rendered event
		if ($p_players->RowType <> EW_ROWTYPE_AGGREGATEINIT)
			$p_players->Row_Rendered();
	}

	// Validate form
	function ValidateForm() {
		global $Language, $gsFormError, $p_players;

		// Initialize form error message
		$gsFormError = "";

		// Check if validation required
		if (!EW_SERVER_VALIDATE)
			return ($gsFormError == "");
		if (!ew_CheckInteger($p_players->is_active->FormValue)) {
			if ($gsFormError <> "") $gsFormError .= "<br>";
			$gsFormError .= $p_players->is_active->FldErrMsg();
		}
		if (!ew_CheckInteger($p_players->active_plus_account->FormValue)) {
			if ($gsFormError <> "") $gsFormError .= "<br>";
			$gsFormError .= $p_players->active_plus_account->FldErrMsg();
		}
		if (!ew_CheckInteger($p_players->gold_num->FormValue)) {
			if ($gsFormError <> "") $gsFormError .= "<br>";
			$gsFormError .= $p_players->gold_num->FldErrMsg();
		}
		if (!ew_CheckInteger($p_players->total_people_count->FormValue)) {
			if ($gsFormError <> "") $gsFormError .= "<br>";
			$gsFormError .= $p_players->total_people_count->FldErrMsg();
		}

		// Return validate result
		$ValidateForm = ($gsFormError == "");

		// Call Form_CustomValidate event
		$sFormCustomError = "";
		$ValidateForm = $ValidateForm && $this->Form_CustomValidate($sFormCustomError);
		if ($sFormCustomError <> "") {
			$gsFormError .= ($gsFormError <> "") ? "<br>" : "";
			$gsFormError .= $sFormCustomError;
		}
		return $ValidateForm;
	}

	// Update record based on key values
	function EditRow() {
		global $conn, $Security, $Language, $p_players;
		$sFilter = $p_players->KeyFilter();
			if ($p_players->name->CurrentValue <> "") { // Check field with unique index
			$sFilterChk = "(`name` = '" . ew_AdjustSql($p_players->name->CurrentValue) . "')";
			$sFilterChk .= " AND NOT (" . $sFilter . ")";
			$p_players->CurrentFilter = $sFilterChk;
			$sSqlChk = $p_players->SQL();
			$conn->raiseErrorFn = 'ew_ErrorFn';
			$rsChk = $conn->Execute($sSqlChk);
			$conn->raiseErrorFn = '';
			if ($rsChk === FALSE) {
				return FALSE;
			} elseif (!$rsChk->EOF) {
				$sIdxErrMsg = str_replace("%f", 'name', $Language->Phrase("DupIndex"));
				$sIdxErrMsg = str_replace("%v", $p_players->name->CurrentValue, $sIdxErrMsg);
				$this->setMessage($sIdxErrMsg);				
				$rsChk->Close();
				return FALSE;
			}
			$rsChk->Close();
		}
			if ($p_players->zemail->CurrentValue <> "") { // Check field with unique index
			$sFilterChk = "(`email` = '" . ew_AdjustSql($p_players->zemail->CurrentValue) . "')";
			$sFilterChk .= " AND NOT (" . $sFilter . ")";
			$p_players->CurrentFilter = $sFilterChk;
			$sSqlChk = $p_players->SQL();
			$conn->raiseErrorFn = 'ew_ErrorFn';
			$rsChk = $conn->Execute($sSqlChk);
			$conn->raiseErrorFn = '';
			if ($rsChk === FALSE) {
				return FALSE;
			} elseif (!$rsChk->EOF) {
				$sIdxErrMsg = str_replace("%f", 'email', $Language->Phrase("DupIndex"));
				$sIdxErrMsg = str_replace("%v", $p_players->zemail->CurrentValue, $sIdxErrMsg);
				$this->setMessage($sIdxErrMsg);				
				$rsChk->Close();
				return FALSE;
			}
			$rsChk->Close();
		}
			if ($p_players->activation_code->CurrentValue <> "") { // Check field with unique index
			$sFilterChk = "(`activation_code` = '" . ew_AdjustSql($p_players->activation_code->CurrentValue) . "')";
			$sFilterChk .= " AND NOT (" . $sFilter . ")";
			$p_players->CurrentFilter = $sFilterChk;
			$sSqlChk = $p_players->SQL();
			$conn->raiseErrorFn = 'ew_ErrorFn';
			$rsChk = $conn->Execute($sSqlChk);
			$conn->raiseErrorFn = '';
			if ($rsChk === FALSE) {
				return FALSE;
			} elseif (!$rsChk->EOF) {
				$sIdxErrMsg = str_replace("%f", 'activation_code', $Language->Phrase("DupIndex"));
				$sIdxErrMsg = str_replace("%v", $p_players->activation_code->CurrentValue, $sIdxErrMsg);
				$this->setMessage($sIdxErrMsg);				
				$rsChk->Close();
				return FALSE;
			}
			$rsChk->Close();
		}
		$p_players->CurrentFilter = $sFilter;
		$sSql = $p_players->SQL();
		$conn->raiseErrorFn = 'ew_ErrorFn';
		$rs = $conn->Execute($sSql);
		$conn->raiseErrorFn = '';
		if ($rs === FALSE)
			return FALSE;
		if ($rs->EOF) {
			$EditRow = FALSE; // Update Failed
		} else {

			// Save old values
			$rsold =& $rs->fields;
			$rsnew = array();

			// name
			$p_players->name->SetDbValueDef($rsnew, $p_players->name->CurrentValue, NULL, FALSE);

			// is_active
			$p_players->is_active->SetDbValueDef($rsnew, $p_players->is_active->CurrentValue, NULL, FALSE);

			// active_plus_account
			$p_players->active_plus_account->SetDbValueDef($rsnew, $p_players->active_plus_account->CurrentValue, NULL, FALSE);

			// gold_num
			$p_players->gold_num->SetDbValueDef($rsnew, $p_players->gold_num->CurrentValue, NULL, FALSE);

			// total_people_count
			$p_players->total_people_count->SetDbValueDef($rsnew, $p_players->total_people_count->CurrentValue, NULL, FALSE);

			// Call Row Updating event
			$bUpdateRow = $p_players->Row_Updating($rsold, $rsnew);
			if ($bUpdateRow) {
				$conn->raiseErrorFn = 'ew_ErrorFn';
				$EditRow = $conn->Execute($p_players->UpdateSQL($rsnew));
				$conn->raiseErrorFn = '';
			} else {
				if ($p_players->CancelMessage <> "") {
					$this->setMessage($p_players->CancelMessage);
					$p_players->CancelMessage = "";
				} else {
					$this->setMessage($Language->Phrase("UpdateCancelled"));
				}
				$EditRow = FALSE;
			}
		}

		// Call Row_Updated event
		if ($EditRow)
			$p_players->Row_Updated($rsold, $rsnew);
		$rs->Close();
		return $EditRow;
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	function Message_Showing(&$msg) {

		// Example:
		//$msg = "your new message";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$CustomError) {

		// Return error message in CustomError
		return TRUE;
	}
}
?>
