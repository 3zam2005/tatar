<?php
require(".".DIRECTORY_SEPARATOR."F-Core".DIRECTORY_SEPARATOR."boot.php");
class GPage extends SecureGamePage
{
        function GPage(){
                parent::securegamepage();
                $this->viewFile = "fourm.phtml";
if (isset($_GET['shows']) or isset($_GET['newtopic']) or isset($_GET['newforum'])) {
                $this->contentCssClass = "forum";
}else{
                $this->contentCssClass = "plus";
}
        }
        function load()
                {
           parent::load();

                }
}
$p = new GPage();
$p->run();
?>
