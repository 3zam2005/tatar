<?php
import_request_variables("POST") ; ?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
       <meta charset="UTF-8">
       <title>محرك الإرسال</title>
</head>
<body>
<?

$email = explode("\r\n", $emails);

$count = count($email) ;

$headers .= "From: $sender <$sm>\r\n";

for ($cou =0 ; $cou <= $count ; $cou ++)
{
mail($email[$cou], $name, $mes, $headers);
echo "<CENTER>" ;
echo "<font face=tahoma size=3> تم الإرسال للبريد رقم $cou </font>" ;
echo "<BR>" ;
echo "</CENTER>" ;
}
?>
</body>
</html>
