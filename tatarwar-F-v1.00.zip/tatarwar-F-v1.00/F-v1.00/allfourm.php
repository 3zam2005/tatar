<?php

require( ".".DIRECTORY_SEPARATOR."F-Core".DIRECTORY_SEPARATOR."boot.php" );
class GPage extends SecureGamePage {
   
    public function GPage( )
    {
        parent::securegamepage( );
        $this->viewFile = "allfourm.phtml";
        $this->contentCssClass = "forum";
    }

    public function load( )
    {
        parent::load( );
}
}


$p = new GPage( );
$p->run( );
?>