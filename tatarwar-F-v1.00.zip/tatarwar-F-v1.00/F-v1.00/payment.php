<?php
require( ".".DIRECTORY_SEPARATOR."F-Core".DIRECTORY_SEPARATOR."boot.php" );
class GPage extends PopupPage
{
    public $requestPaymentProvider = FALSE;
    public $providerType = "";
    public $package = NULL;
    public $payment = NULL;
    public $secureId = NULL;
    public $Domain = NULL;
    public $gold = NULL;
    public function GPage()
    {
        parent::popuppage();
$this->contentCssClass = 'payment';
        $this->viewFile = "payment.phtml";
    }



 public function load()
    {
        parent::load();
        $this->Domain = webhelper::getbaseurl();
        if ( isset( $_GET['p'], $_GET['pg'] ) )
        {
            $this->providerType = trim( $_GET['p'] );
            $this->packageIndex = trim( $_GET['pg'] );
            if ( isset( $GLOBALS['AppConfig']['plus']['payments'][$this->providerType], $GLOBALS['AppConfig']['plus']['packages'][$this->packageIndex] ) )
            {
                $this->title = sprintf( payment_loading." %s ...", $GLOBALS['AppConfig']['plus']['payments'][$this->providerType]['name'] );
                $this->package = $GLOBALS['AppConfig']['plus']['packages'][$this->packageIndex];
                $this->payment = $GLOBALS['AppConfig']['plus']['payments'][$this->providerType];
                                
                                $this->pg_name = $GLOBALS['AppConfig']['plus']['payments'][$this->providerType]['pg_name'];
                                $this->pg_serviceid = $GLOBALS['AppConfig']['plus']['payments'][$this->providerType]['pg_serviceid'];
                                $this->pg_serviceid = $GLOBALS['AppConfig']['plus']['payments'][$this->providerType]['pg_serviceid'];
                                $this->pg_return_url = $GLOBALS['AppConfig']['plus']['payments'][$this->providerType]['pg_return_url'];
                                $this->pg_cancel_url = $GLOBALS['AppConfig']['plus']['payments'][$this->providerType]['pg_cancel_url'];
                                

$this->requestPaymentProvider = isset( $_GET['c'] );
                if ( $this->requestPaymentProvider )
                {
                    $this->layoutViewFile = NULL;
                    $this->secureId = base64_encode( $this->player->playerId );
                }
            }
            else
            {
                echo "<script type=\"text/javascript\">self.close();</script>";
            }
        }
    }

}

$p = new GPage();
$p->run();
?>
