<?php
require(".".DIRECTORY_SEPARATOR."F-Core".DIRECTORY_SEPARATOR."boot.php");
class GPage extends securegamepage{
	public function GPage(){
		parent::securegamepage();
		$this->viewFile = "vote.phtml";
		$this->contentCssClass = "plus";
	}
}
$p = new GPage();
$p->run();
?>