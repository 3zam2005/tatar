<?php
require("." . DIRECTORY_SEPARATOR . "F-Core" . DIRECTORY_SEPARATOR . "boot.php");
class GPage extends GamePage
    {
    function GPage()
        {
        parent::gamepage();
        $this->viewFile        = "index.phtml";
        $this->contentCssClass = "logout";
        }
    function load()
        {
        parent::load();
//config
$title = 'حرب التتار - لعبة الانترنت - الرومان, الاغريق, الجرمان';
$sitename = 'حرب التتار';

for ($ns=1; $ns<=1; $ns++) {
$config = APP_PATH."con_ndc/s".$ns.".php";
include( $config );
$c[$ns]=($AppConfig['Game']['RegisterOver']);
$s[$ns]=($AppConfig['Game']['speed']);
$link = mysql_connect($AppConfig['db']['host'],$AppConfig['db']['user'],$AppConfig['db']['password']);
mysql_select_db($AppConfig['db']['database'],$link);
$q[$ns] = mysql_query ("SELECT * FROM g_summary");
$r[$ns] = mysql_fetch_assoc ($q[$ns]);

}




$player = array('',$r[$ns]['players_count'],$r[$ns]['players_count'],$r[$ns]['players_count'],$r[$ns]['players_count'],$r[$ns]['players_count']);
$dayEnd = array('',$c[$ns],$c[$ns],$c[$ns],$c[$ns],$c[$ns]);
$speed = array('',$s[$ns],$s[$ns],$s[$ns],$s[$ns],$s[$ns]);
$day = array('',$r1['server_start_time'],$r2['server_start_time'],$r3['server_start_time'],$r4['server_start_time'],$r5['server_start_time']);;
$allp = $player[1]+$player[2]+$player[3]+$player[4]+$player[5];

//end code
        }
    }
$p = new GPage();
$p->run();
?>