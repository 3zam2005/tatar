<?php
?><html><meta http-equiv="content-type" content="text/html; charset=UTF-8;charset=utf-8" />
<style type="text/css">
.alignright {
	border:3px solid #C2C2C2;
	border-radius: 10px;
     -moz-border-radius: 10px;
     -webkit-border-radius: 10px;
}
.alignright:hover {
	border:3px solid #FF8000;
	border-radius: 10px;
     -moz-border-radius: 10px;
     -webkit-border-radius: 10px;
}
td{
	border:1px solid #C2C2C2;
	padding-right:0px;
	opacity: 0.8;
}
h1{
	color:#662504;
}
</style>
<span class="close"><!--Close--></span>
<h1>جديد اللعبه</h1>
<p><br>
[#] ميزه ازالة الاستهلاك<br>
[#] لايمكن تدمير العاصمه <br>
[#] بعض التعديلات على الاستايل<br>
[#] معرفة اخر المحتلين للتحفه<br>
[#] عند احتلال التحفه 3 ساعات لتفعيل تاُثير التحفه <br>
[#] اصلاح تاريخ احتلال الحفه<br>
[#] معالجه الرسائل المتكرره من قبل بعض الاعبين<br>
[#] اي لاعب يدخل بحسابين لن يتمكن من تموين بعضهما بعض الى نهايه السيرفر </p>