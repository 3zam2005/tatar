<?php
echo "<META HTTP-EQUIV=\"refresh\" CONTENT=\"0; URL=/index.php\">";
?>
