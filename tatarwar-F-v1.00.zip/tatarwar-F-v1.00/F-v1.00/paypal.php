<center>
<br>
<br>
<br>
<br>
<br>
<br>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="NSAQQYW2AJTWS">
<table>
<tr><td><input type="hidden" name="on0" value="&#1584;&#1607;&#1576;"><center> Gold</center></td></tr><tr><td><select name="os0">
	<option value="Gold">Gold $15.00 USD</option>
	<option value="Gold">Gold $30.00 USD</option>
	<option value="Gold">Gold $55.00 USD</option>
	<option value="Gold">Gold $135.00 USD</option>
	<option value="Gold">Gold $270.00 USD</option>
	<option value="Gold">Gold $560.00 USD</option>
</select> </td></tr>
</table>
<input type="hidden" name="currency_code" value="USD">
<br>
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
