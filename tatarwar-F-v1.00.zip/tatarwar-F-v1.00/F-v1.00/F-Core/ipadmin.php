<?php
        //Protection admin
       $ipadmin = "41.45.171.86";
       
?>