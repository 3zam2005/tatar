﻿<?php
$AppConfig = array (
        'db'                                         => array (
                'host'                                => 'localhost',
                'user'                                => '',
                'password'                        => '',
                'database'                        => '',
                   ),
				'New'                         => array (  // اضافات جديده
				'nmouse'                      => '0',// الماوس الجديد 1 يعمل 0 موقوف
				'hdya'                      => '1',// الهديه اليومية الجديد 1 يعمل 0 موقوف
				),
                'Game'                         => array (
                // اعدادات اللعبه
                'speed'                      => '300',//سرعة اللعبه
                'speed_t'                      => '50',//سرعه توقيت تدريب القوات
                'speed_b'                      => '50',//سرعه توقيت بناء المباني
                'dev_troop_to_20'                    => '20',//ذهب افران صهر الحديد بناء الى 20
                'WWW'        => '1',//مضروب مووارد بناء المعجزه
                'WWW2'        => '1',// مضروب توقيت بناء المعجزه
                'map'                      => '301',//حجم الخريطه
                'attack'        => '50',//100سرعه الهجوم يفضل
                'protection'        => '24',// الحمايه بالساعات
                'protectionx'       => '0',//تدبيل الحمايه
                'X'                 => '1328827643',//غير مهم يرجى تركه هكذا
                'capacity'      => '100', // المخازن يفضل 125
                'cranny'        => '100', // المخابأ
                'cp'            => '100',//ولاء القريه الجديده
                'market'        => '10000', // حمولة التجار
                'speedmarket'        => '10000', // سرعه التجار
                //البلاس
                'plus1'          => '7',//مده بلاس بالايام
                'plus2'          => '7',//مده الزياده بالايام
                'plus3'          => '0',//قائمة بلاس
                'plus4'          => '0',// زياده بلاس
                'plus5'          => '0',//انهاء المباني فورأ
                'plus6'          => '0',//تاجر مبادله
                'plus7'          => '0',//انهاء تدريب القوات فورأ
                'plus9'          => '0',//انهاء التعزيزات فورأ
                'plus8'          => '100',//نادي الذهب
                'plus_by_abdullah_1_1'     => '3', // عدد ايام +20% قوة الهجوم 
                'plus_by_abdullah_1_2'     => '3', // سعر +20% قوة الهجوم 
                'plus_by_abdullah_2_1'     => '3', // عدد ايام +20% قوة الدفاع 
                'plus_by_abdullah_2_2'     => '3', // سعر +20% قوة الدفاع 
                'plus_by_abdullah_3_1'     => '3', // عدد ايام+20% قوة المباني ضد المقاليع 
                'plus_by_abdullah_3_2'     => '3',// سعر +20% قوة المباني ضد المقاليع 
                'plus_by_abdullah_4_1'     => '3', // عدد ايام +30% سرعة القوات 
                'plus_by_abdullah_4_2'     => '50', // سعر +30% سرعة القوات 
                'plus_by_abdullah_5_1'     => '3', // عدد ايام كشف نوع قوات المهاجم 
                'plus_by_abdullah_5_2'     => '50', // سعر كشف نوع قوات المهاجم 
                'plus_by_abdullah_6_1'     => '3', // عدد ايام كشف نوع قوات المهاجم 
                'plus_by_abdullah_6_2'     => '50', // سعر كشف نوع قوات المهاجم 
                //مميزات حرب التتار
                'activitebuytroops'        => '0',// 1 سوق المحاربين شغال 0 تعطيل
                'plus7_on'          => '0',//تفعيل خصائص حرب التتار
                'activitebuyres'        => '0',// 1 شراء الموارد شغال 0 تعطيل
                'res'        => '0',// 1 شراء الموارد شغال 0 تعطيل
                //سوق المحاربين
                'piyadeh'        => '0.00009',// الجندي في سوق المحاربي 0.0009
                'piyadeh1'        => '0.00009',// الجندي رقم 2 في سوق المحاربي
                'piyadeh2'        => '0.00009',// الجندي رقم 3 في سوق المحاربي
                'ksaf'        => '0.00009',// الكشاف في سوق المحاربي
                'savareh'        => '0.0009', // الفرسان في سوق المحاربين
                'shovalieh'      => '0.0009',//المقلاع في سوق المحاربين
                //امـور عامه
                'pepolegold'        => '1000',//سكان استلام الذهب لكسب الذهب
                'setgold'        => '500',//الذهب المعطى لكسب الذهب
                'bonous'        => '200',//غير مهم
                'osas'        => '200',// الواحات العاديه
                'osasX'       => '400',// الواحات الكبيره القمح
                'online'        => '50',//المتصلين خروجهم بعد
                'freegold'       => '500',//ذهب مجاني عند التسجيل
                'freegoldweek'       => '100',//ذهب مجاني أسبوعي
                'awsmh'       => '100000',// مده توزيع الاوسمه بالثواني 
                'RegisterOver'  => '50',//مدة اغلاق التسجيل عدد الايام
        ),
		'Files'                         => array (
		'Fourm'  		=> '1', // المنتدى 1 يعمل 0 لا يعمل
		'Blog'  		=> '1', // المدونة 1 يعمل 0 لا يعمل
		'Ask'  		=> '1', // سوال وجواب 1 يعمل 0 لا يعمل
		'Fast'  		=> '1', // صفحة احصائيات سريعة 1 يعمل 0 لا يعمل
		'tvq'  		=> '1', // صفحة احصائيات سريعة 1 يعمل 0 لا يعمل
		'link'  		=> '1', // صفحة ربح الذهب 1 يعمل 0 لا يعمل
		'hdya'  		=> '1', // الهديه اليومية 1 يعمل 0 لا يعمل
		),
        'page'                 => array (
                'ar_title'                        => 'حرب التتار سمارت سيرفس TATARWAR F-V1.00',
                'en_title'                        => 'حرب التتار سمارت سيرفس TATARWAR F-V1.00',
                'asset_version'                => 'Nhjkh1ka111alcMfks'
        ),

        'system'         => array (
                'adminName'         => 'Admin', //admin
                'adminPassword'          => '123123',
                'adming'          => '123123',
                'VGOLD'          => '15',//مدة نزل جزيرة الكنز
                'tatar'          => '30',//مده نزول التتار بالايام
                'artef'          => '20',//مده نزول التحف بالايام
                'start'          => '',//مده العداد بالايام
                'endin'          => '3',//مده اعاده السيرفر بالساعات
                'lang'                                => 'ar',//اللغه
                'admin_email'                => 'smartservs.com@gmail.com',//الايميل
                'webname'                         => 'SmartServs',
                'email'                    => 'smartservs.com@gmail.com',//المرسل
                'namesite'                => 'SmartServs-TATARWAR F-1.00',//اسم الموقع انجليزي
                'linksite'                         => 'http://demo.smartservs.com/tatarwar-F-v1.00/F-v1.00/assets/',//رابط ألموقع
                'installkey'                 => 'setupsmartservstatarf',//رمز التسطيب
                ),
        'plus'                        => array (
                'packages'        => array (
                        array (
                                'name'                => 'sms',
                                'gold'                => 2000,
                                'cost'                => 10,
                                'plus'                => 0,
                                'currency'        => 'ريال',
                                'image'                => 'sms.png'
                        ),

                        array (
                                'name'                => 'الاولى',
                                'gold'                => 50000,
                                'cost'                => 15,
                                'sawacost'=> 50,
                                'plus'                => 100,
                                'currency'        => 'دولار',
                                'image'                => 'package_a.jpg'
                        ),
                        array (
                                'name'                => 'الثانيه',
                                'gold'                => 100000,
                                'cost'                => 30,
                                'sawacost'=> 100,
                                'plus'                => 100,
                                'currency'        => 'دولار',
                                'image'                => 'package_b.jpg'
                        ),
                        array (
                                'name'                => 'الثالثه',
                                'gold'                => 200000,
                                'cost'                => 55,
                                'sawacost'=> 0,
                                'plus'                => 100,
                                'currency'        => 'دولار',
                                'image'                => 'package_c.jpg'
                        ),
                        array (
                                'name'                => 'الرابعه',
                                'gold'                => 600000,
                                'cost'                => 135,
                                'sawacost'=> 0,
                                'plus'                => 100,
                                'currency'        => 'دولار',
                                'image'                => 'package_d.jpg'
                        ),


                        array (
                                'name'                => 'الخامسه',
                                'gold'                => 1200000,
                                'cost'                => 270,
                                'plus'                => 100,
                                'currency'        => 'دولار',
                                'image'                => 'package_d.jpg'
                        ),

                        array (
                                'name'                => 'السادسه',
                                'gold'                => 3000000,
                                'cost'                => 560,
                                'plus'                => 100,
                                'currency'        => 'دولار',
                                'image'                => 'package_f.jpg'
                        ),
                ),
                'payments' => array (
                        'cashu'        => array (
                                'testMode'                => FALSE,
                                'name'                        => 'CashU',
                                'image'                        => 'cashu.png',
                                'serviceName'         => '',
                                'merchant_id'        => '',
                                'key'                        => '',
                                'testKey'                => '',
                                'returnKey'                => '',
                                'currency'                => 'usd'
                                ),

								'mobily'=> array (
								'merchant_id'=> '',
								'testMode'=> FALSE,
								'name'=> 'Mobily',
								'image'=> 'mobily' // auto detect
								),
								'sawa'=> array (
								'merchant_id'=> '',
								'testMode'=> FALSE,
								'name'=> 'Sawa',
								'image'=> 'sawa' // auto detect
								),

								'onecard'           => array (
                        		'testMode'           => FALSE,
                       		    'name'           => 'OneCard',
             		            'image'           => 'onecard_logo.gif',
                    		    'serviceName'   => '',
 		                        'merchant_id'   => '',
        		                'key'           => '',
                		        'testKey'           => '',
                    		    'returnKey'           => '',
            		            'currency'           => 'usd'
                		        ),
                    		    'payGol'                           => array (
                                'name'               => 'payGol',
                                'pg_name'            => 'gold',
                                'image'              => 'paygol_main.png',
                                'pg_serviceid'       => '',
                                'pg_return_url'      => 'http://smartservs.com',
                                'pg_cancel_url'      => 'http://smartservs.com'
                                ),

                )
        )

);
?>