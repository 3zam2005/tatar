<?php
class T {
public $numservers = '1';
public $serv1 = 'login.php';
public $serv2 = '';
public $serv3 = '';
public $serv4 = '';
public $serv5 = '';
}
?>