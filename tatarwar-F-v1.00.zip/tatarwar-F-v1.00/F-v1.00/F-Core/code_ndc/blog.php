<?php
class BlogModel extends ModelBase{

    public function changesummaryBlog(){
	return $this->provider->fetchResultSet( "SELECT blog FROM g_summary");
    }       
	public function addgesummaryBlog ( $blog )
	{
	    $this->provider->executeQuery( "UPDATE g_summary m SET m.blog='$blog'");
	}

	
}
?>
