<?php

class NewsModel extends ModelBase{


}
?>
