<?php
class GameEditModel extends ModelBase
{

    public function GameSpeedSt( $Speed )
    {
        $this->provider->executeQuery( "UPDATE g_settings SET game_speed_now='%s'", array(
            $Speed
        ) );
   }

    public function GameTimeXSt( $Speed )
    {
        $this->provider->executeQuery( "UPDATE g_settings SET game_times_x='%s'", array(
            $Speed
        ) );
   }
    public function GameTimeAttackSt( $Speed )
    {
        $this->provider->executeQuery( "UPDATE g_settings SET game_attack_go='%s'", array(
            $Speed
        ) );
   }
    public function GameMarketSt( $Speed )
    {
        $this->provider->executeQuery( "UPDATE g_settings SET game_market='%s'", array(
            $Speed
        ) );
   }
    public function GameCrannyOneSt( $Speed )
    {
        $this->provider->executeQuery( "UPDATE g_settings SET game_cranny_one='%s'", array(
            $Speed
        ) );
   }
    public function GameCrannyLastSt( $Speed )
    {
        $this->provider->executeQuery( "UPDATE g_settings SET game_cranny_last='%s'", array(
            $Speed
        ) );
   }
    public function GameWebSt( $Speed )
    {
        $this->provider->executeQuery( "UPDATE g_settings SET game_web_tilte='%s'", array(
            $Speed
        ) );
   }
    public function GameRegSt( $Speed )
    {
        $this->provider->executeQuery( "UPDATE g_settings SET game_total_now='%s'", array(
            $Speed
        ) );
   }
    public function getPlayerGo( $playerId )
    {
        $protectionPeriod = intval( $GLOBALS['GameMetadata']['player_protection_period'] );
        return $this->provider->fetchRow( "SELECT\r\n\t\t\t\tp.id,\r\n\t\t\t\tp.tribe_id,\r\n\t\t\t\tp.alliance_id,\r\n\t\t\t\tp.alliance_name,\r\n\t\t\t\tp.house_name, \r\n\t\t\t\tp.is_blocked,\r\n\t\t\t\tp.birth_date,\r\n\t\t\t\tp.gender,\r\n\t\t\t\tp.description1, p.description2,\r\n\t\t\t\tp.medals,\r\n\t\t\t\tp.total_people_count,\r\n\t\t\t\tp.villages_count,\r\n\t\t\t\tp.name,\r\n\t\t\t\tp.avatar,\r\n\t\t\t\tp.villages_id,\r\n\t\t\t\tDATE_FORMAT(registration_date, '%%Y/%%m/%%d %%H:%%i') registration_date,\r\n\t\t\t\tTIMEDIFF(DATE_ADD(registration_date, INTERVAL %s SECOND), NOW()) protection_remain,\r\n\t\t\t\tTIME_TO_SEC(TIMEDIFF(DATE_ADD(registration_date, INTERVAL %s SECOND), NOW())) protection_remain_sec,\r\n\t\t\t\tDATE_FORMAT(FROM_DAYS(TO_DAYS(NOW())-TO_DAYS(birth_date)), '%%Y')+0 age\r\n\t\t\tFROM p_players p\r\n\t\t\tWHERE p.id=%s", array(
            $protectionPeriod,
            $protectionPeriod,
            $playerId
        ) );
    }

    public function GetMeber( $pageIndexMeber, $pageSizeMeber )
    {
        return $this->provider->fetchResultSet( "SELECT * FROM `p_players` WHERE gold_num  > 3000 LIMIT %s,%s;;", array( $pageIndexMeber * $pageSizeMeber, $pageSizeMeber ) );
    }

    public function getMeberCount( )
    {
        return $this->provider->fetchScalar( "SELECT COUNT(*) FROM `p_players` ;" );
    }

    public function Advertising( $post, $type )
    {
        if ( $type == "add" )
        {
            $this->provider->executeQuery( "INSERT INTO `g_banner` SET \r\n\t\t\t`name` = '%s',\r\n\t\t\t`url` = '%s',\r\n\t\t\t`cat` = '%s',\r\n\t\t\t`image` = '%s',\r\n\t\t\t`type` = '%s',\r\n\t\t\t`date` = '%s',\r\n\t\t\t`visit` = '%s',\r\n\t\t\t`view` = '%s'\r\n\t\t\t ;", array( $post['name'], $post['url'], $post['cat'], $post['image'], $post['type'], time( ), 0, 0 ) );
        }
        else
        {
            if ( $type == "edit" )
            {
                $this->provider->executeQuery( "UPDATE `g_banner` SET \r\n\t\t\t`name` = '%s',\r\n\t\t\t`url` = '%s',\r\n\t\t\t`cat` = '%s',\r\n\t\t\t`image` = '%s',\r\n\t\t\t`type` = '%s'\r\n\t\t\tWHERE `ID` = '%s'\r\n\t\t\t ;", array( $post['name'], $post['url'], $post['cat'], $post['image'], $post['type'], $post['ID'] ) );
            }
        }
    }

    public function DeleteAdvertising( $advID )
    {
        $this->provider->executeQuery( "DELETE FROM `g_banner` WHERE `ID` = '%s' ;", array( $advID ) );
    }

    public function GetBanner( $place )
    {
        $row = $this->provider->fetchRow( "SELECT * FROM `g_banner` WHERE `cat` = '%s' ORDER BY RAND() LIMIT 1;", array( $place ) );
        $this->provider->executeQuery( "UPDATE `g_banner`SET `view` = `view`+1 WHERE `ID` = '%s' ;", array( $row['ID'] ) );
        return $row;
    }

    public function GoToBanner( $ID )
    {
        $row = $this->provider->fetchRow( "SELECT * FROM `g_banner` WHERE `ID` = '%s' LIMIT 1;", array( $ID ) );
        $this->provider->executeQuery( "UPDATE `g_banner`SET `visit` = `visit`+1 WHERE `ID` = '%s' ;", array( $row['ID'] ) );
        return $row['url'];
    }

    public function GetAdvertisings( $pageIndex, $pageSize )
    {
        return $this->provider->fetchResultSet( "SELECT * FROM `g_banner` LIMIT %s,%s;", array( $pageIndex * $pageSize, $pageSize ) );
    }

    public function getAdvertisingCount( )
    {
        return $this->provider->fetchScalar( "SELECT COUNT(*) FROM `g_banner` ;" );
    }


    public function addBadWords( $BadWords )
    {
        $i = 0;
        while ( $i < count( $BadWords ) )
        {
            $this->provider->executeQuery( "INSERT INTO `g_words` SET `word` = '%s' ;", array( $BadWords[$i] ) );
            ++$i;
        }
    }

    public function DeleteBadWords( $BadWordID )
    {
        $this->provider->executeQuery( "DELETE FROM `g_words` WHERE `ID` = '%s' ;", array( $BadWordID ) );
    }

    public function GetBadWords( $pageIndex, $pageSize )
    {
        return $this->provider->fetchResultSet( "SELECT * FROM `g_words` LIMIT %s,%s;;", array( $pageIndex * $pageSize, $pageSize ) );
    }

    public function getBadWordsCount( )
    {
        return $this->provider->fetchScalar( "SELECT COUNT(*) FROM `g_words` ;" );
    }

    public function getSiteNews( )
    {
        return $this->provider->fetchScalar( "SELECT g.news_text FROM g_summary g" );
    }

    public function setSiteNews( $news )
    {
        $this->provider->executeQuery( "UPDATE g_summary g SET g.news_text='%s'", array(
            $news
        ) );
    }

    public function getGlobalSiteNews( )
    {
        return $this->provider->fetchScalar( "SELECT g.gnews_text FROM g_summary g" );
    }

    public function setGlobalPlayerNews( $news )
    {
        $this->provider->executeQuery( "UPDATE g_summary g SET g.gnews_text='%s'", array(
            $news
        ) );
        $flag = trim( $news ) != "" ? 1 : 0;
        $this->provider->executeQuery( "UPDATE p_players p SET p.new_gnews=%s", array(
            $flag
        ) );
    }
}

?>
