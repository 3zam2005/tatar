<?php

class ControlMemberModel extends ModelBase
{


}

?>
