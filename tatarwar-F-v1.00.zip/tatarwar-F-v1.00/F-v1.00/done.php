<?php
require( ".".DIRECTORY_SEPARATOR."F-Core".DIRECTORY_SEPARATOR."boot.php" );
class GPage extends ProcessVillagePage
{

    public $troops = array( );
    public $heroCount = 0;

    public function GPage( )
    {
        parent::processvillagepage( );
        $this->viewFile = "done.phtml";
        $this->contentCssClass = "village1";
    }


}

$p = new GPage( );
$p->run( );
?>
