<?php
require(".".DIRECTORY_SEPARATOR."F-Core".DIRECTORY_SEPARATOR."boot.php");
class GPage extends SecureGamePage
{
        function GPage(){
                parent::securegamepage();
                $this->viewFile = "fgold.phtml";
                $this->contentCssClass = "forum";
        }
        function load()
                {
           parent::load();

                }
}
$p = new GPage();
$p->run();
?>
