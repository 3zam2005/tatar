<h3 class="pop popgreen bold">ألعاب أخرى</h3>

		<div class="games">
			<h3 class="game-title">حرب التتار </h3>
							<div class="game game0 game-image">	<a title="مدير كرة القدم - جول يونايتد" target="_blank" class="enumerableElementsImageLink" href="http://tracking.traviangames.com/107811111191000/12">
		<img alt="حرب التتار" style="" class="enumerableElementsImage goalunited_game_image" src="travian.jpg" id="goalunited_game_image">
			</a>
</div>
							<div class="game game0 game-description"><div title="" style="" class="enumerableElementsDiscription goalunited_description" id="goalunited_description">
	حرب التتار واحدة من أنجح ألعاب المتصفحات في العالم. في حرب التتار، تؤسس امبراطوريتك، توسّعها وتدّرب جيشاً لحمايتها، في النهاية، تتساعد مع لاعبين آخرين لتنافسوا على بناء معجزة العالم.</div></div>
						<div class="btn-green">
				<div class="btn-green-l"></div>
				<div class="btn-green-c">
					<a href="index.php" class="npage" target="blank">إلى الصفحة الالكترونية</a>
				</div>
				<div class="btn-green-r"></div>
			</div>

			<div class="clear"></div>
		</div>