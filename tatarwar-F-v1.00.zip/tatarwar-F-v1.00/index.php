﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
include('F-v1.00/F-Core/con_ndc/s1.php'); // هنا قم بتعديل المسار ليتصل بمسار الذي يوجد به ملف الكونفق
$db_connect = mysql_connect($AppConfig['db']['host'],$AppConfig['db']['user'],$AppConfig['db']['password']); // لا تعدل شيء هنا
mysql_select_db($AppConfig['db']['database'], $db_connect); // لا تعدل شيء هنا
$query = mysql_query("SELECT * FROM g_summary"); // يقوم بأستعلام من القاعدة لكي يجلب عدد اللاعبين 
$data  = mysql_fetch_array($query); // كود مهم !
$player = $data['players_count']; // متغير لعدد اللاعبين 
$active = $data['active_players_count']; // متغير لعدد اللاعبين النشيطين
require ("indextxt.php"); // يقوم بجلب الكلمات العربية من ملف indextxt.php
// معلومة مهمة !!!
// الصور يقوم بجلبها الملف من سيرفر ترافيان الرسمي بأمكانك جعله لا يجلبها منه
?>
<head>
	<title><?php echo index; ?></title>
	<meta http-equiv="cache-control" content="max-age=0" />
	<meta http-equiv="pragma" content="no-cache" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="shortcut icon" href="favicon.ico" />
    <meta name="description" content="<?php echo des1; ?>" />
	<meta content="<?php echo des2; ?>" name="keywords" />
    <link rel="stylesheet" type="text/css" href="http://www.travian.com.sa/gpack/main_default/lang/sa/compact.css"/> <?php // هنا كود لجلب ملف css ?>
	<meta name="content-language" content="sa"/>
    <meta name="google-site-verification" content="-LGUdlnzgCJ_AUkF2yOWtRCHLfk83Edhtj4rN6xGnIs" /> <?php //كود التحقق الخاص بقوقل للأدوات الخاصة بصاحبي المواقع لنشر مواقعهم بقوقل ?>
	<meta http-equiv="imagetoolbar" content="no"/><style type="text/css" media="screen"></style>
	<script type="text/javascript" src="http://api.recaptcha.net/js/recaptcha_ajax.js"></script>
	<script type="text/javascript" src="crypt.js"></script>
	</head>
<body class=" LTR">
    <div id="backgroundLeft"></div>
    <div id="backgroundRight"></div>
	<div id="background">
		<div id="navigation-wrapper">
	    	<div id="navigation-container">
	        	<div id="country_select">
			<div id="flags"></div>
				</div>
	            <div id="top-nav">
                    <div id="top-nav-menu">
                        <ul id="top-navigation">
                            <li><a href="#tutorial" class="popcon"><?php echo index2; ?></a></li>
                            <li><a target="_blank" href="<?php echo url1; ?>" id="forum"><?php echo index3; ?></a></li>
                            <li><a href="#moregames" class="popcon"><?php echo index4; ?></a></li>
                            <li><a href="#serverRegister" class="popcon" id="registerLink"><?php echo index5; ?></a></li>
						</ul>
                    </div>
	<div id="top-nav-login">
		<div id="login">
			<div class="btn-green">
			  <div class="btn-green-l"></div>
			  <div class="btn-green-c">
				<a class="npage popcon" href="#serverLogin"><?php echo index6; ?></a>			  </div>
			  <div class="btn-green-r"></div>
			  <div class="clear"></div>
			</div>
		</div>
	</div>
</div>	             	<div id="stimeContainer">
	             	<div id="stime" class="stime">
						<div class="content-background-l">&nbsp;</div>
						<div class="content-background-r">&nbsp;</div>
						<div class="content">
							<span class="icn"><?php echo index7; ?></span>&nbsp;<span id="tp1"><script type="text/javascript">
function refrClock() 
{ 
var d=new Date(); 
var s=d.getSeconds(); 
var m=d.getMinutes(); 
var h=d.getHours(); 
var day=d.getDay(); 
var date=d.getDate(); 
var month=d.getMonth(); 
var year=d.getFullYear(); 
var days=new Array("الاحد","الاثنين","الثلاثاء","الاربعاء","الخميس","الجمعة","السبت"); 
var months=new Array("يناير","فبراير","مارس","ابريل","ماي","يونيو","يوليو","اغسطس","سبتمبر","اكتوبر","نوفمبر","ديسمبر"); 
var am_pm; 
if (s<10) {s="0" + s} 
if (m<10) {m="0" + m} 
if (h>12) {h-=12;am_pm = "مساءً"} 
else {am_pm="صباحاً"} 
if (h<10) {h="" + h} 
document.getElementById("tp1").innerHTML= h + ":" + m + ":" + s + " "; 
setTimeout("refrClock()",1000); 
} 
refrClock(); 
</script></span> <span class="timezone"><?php echo index8; ?></span>
					    </div>
					</div>
					</div>
	            </div>
	        </div>


	       <div id="content-container">
	    	<div id="content-menu">
				<div id="statistics">
                   	<div id="stat-top"></div>
                    <div id="stat_bottom"></div>
                    	<h3 class="stat bold grey"><?php echo index33; ?></h3>
                    	<div>
	                    	<div class="stat type"><?php echo index9; ?> </div>
                            <div class="stat value"><?php echo $player ;  // هنا يقوم بجلب المتغير الموجود بالاعلى الخاص بعدد اللاعبين ?></div>
                            <div class="clear"></div>
							<div class="stat type"><?php echo index10; ?> </div>
                            <div class="stat value"><?php echo $active ;  // نفس الشيء يقوم بجلب عدد لاعبين النشيطين للمتغير الموجود بالاعلى ?></div>
							<div class="clear"></div>
                            <div class="stat type"><?php echo index11; ?></div>
                            <div class="stat value"><?php echo number1; ?></div>
							<div class="clear"></div><br />
	                	</div>
                	</div>

                <div id="news">
                    <div id="news-head"></div>
                    <div id="news-content">
                        <h3 class="news bold"><?php echo index34; ?></h3>
                        		                        	<div class="news-items">
										<span class="bold green"><?php echo index12; ?></span>
										<span class="small"><?php echo index13; ?></span>											<div>
										<?php echo index14; ?>
<?php echo index15; ?><br />
										</div>
																					<span class="green"><a target="blank" href="<?php echo url2; ?>" class="more"><?php echo index35; ?></a></span>
																			</div><br /><br />
</div>
                    <div id="news-bottom"> </div>
                </div>



<div id="fb-widget">
<div id="news-head"></div>
<div id="fb-widget-content">
<iframe id="fb-container" src="http://www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com/SmartServs.Official&amp;width=182&amp;colorscheme=light&amp;connections=9&amp;stream=false&amp;header=false&amp;height=260" scrolling="no" frameborder="0"></iframe>
</div> <?php // الكود خاص بصفحة الفيس بوك قم بتغيير  travian-libya لاسم صفحتك المختصر للفيس بوك ?>
<div id="fb-widget-bottom"></div>
</div>
				</div>
	            <div id="content-main">
	            	<div id="wit">
                    	<div id="wit-top"></div>
                        <div id="wit-content" class="with-button">
                        	<div id="hero"></div>
                            <h1 class="wit bold"><?php echo index16; ?></h1>
                            <div class="wit-info">
                            	<?php echo index17; ?>
                            	<div class="playnow playnow-button">
                                	<div class="playnow-start">
                                    	<h1 class="play white bold">
                                        <a id="register" class="popcon play" href="#serverRegister" title="اِلعب الآن مجاناً"><?php echo index18; ?></a>
                                        </h1>
									</div>
                                    <div class="playnow-end"></div>
                                    <div class="clear"></div>
								</div>
							</div>



                            <div id="stage_space"></div>
                            <div id="stage">


            <div id="frame">

                <div class="stage-content stage-content0 shown">
                		<div style="position:absolute; right:15px; top:170px;"><span style="color:black;"><?php echo index22; ?></span></div>
	<div style="position:absolute; right:15px; top:12px;"><span style="color:black;"><?php echo index20; ?></span></div>
                    <div class="stage-arrow stage-arrow-0"></div>
				</div>
                <div class="stage-content stage-content1">
                		<div style="position:absolute; right:15px; top:170px;"><img alt="" class="bbArrow" src="img/x.gif" /> <span style="color:black;"><span style="font-weight:bold;"><?php echo index45; ?></span></span></div>
	<div style="position:absolute; right:15px; top:12px;"><b>كن زعيماً !</b><br />إبني جيوشك وإكتشف الكنوز !</div>
                    <div class="stage-arrow stage-arrow-1"></div>
                </div>
                <div class="stage-content stage-content2">
                		<div style="position:absolute; right:15px; top:170px;"><img alt="" class="bbArrow" src="img/x.gif" /> <span style="color:black;"><span style="font-weight:bold;"><?php echo index44; ?></span></span></div>
	<div style="position:absolute; right:15px; top:12px;"><?php echo index23; ?><br />
<?php echo index24; ?></div>
                    <div class="stage-arrow stage-arrow-2"></div>
                </div>

                <div id="stage-nav">
                    <ul id="buttons">
                        <li class="b0 act0">&nbsp;</li>
                        <li class="b1">&nbsp;</li>
                        <li class="b2">&nbsp;</li>
                    </ul>
                </div>
            </div>
								<div id="stage-bg"></div>
								<div id="stage-fg">
                                	<div class="stage-links">
                                    	<a class="stage-link stage-link1 shown" href="#serverRegister"></a>
                                        <a class="stage-link stage-link2" href="#serverRegister"></a>
                                        <a class="stage-link stage-link3" href="#serverRegister"></a>
									</div>
                                    <div id="stage-nav-click">
                                    	<ul id="buttons-click">
											<li class="b0 act0">&nbsp;</li>
											<li class="b1">&nbsp;</li>
											<li class="b2">&nbsp;</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div id="wit-bottom"></div>
					</div>
					<div id="moreabttravian">
						<div id="find-out-more">
							<div id="strip-head">
                            	<div><?php echo index25; ?></div>
                            </div>
							<div id="strip">
								<ul id="strips">
					                <li class="stip0">&nbsp;</li>
                					<li class="stip1">&nbsp;</li>
                					<li class="stip2">&nbsp;</li>
                					<li class="stip3">&nbsp;</li>
                					<li class="stip4">&nbsp;</li>
                					<li class="stip5">&nbsp;</li>
            					</ul>
    					    </div>
                            <div id="strip-details">
                                <div class="details">
                                    <div class="details-top"></div>
                                    <div class="details-l-top"></div>
                                    <div class="details-r-top"></div>
                                    <div class="details-body">
                                        <div class="details-body-l" id="strip-c1"></div>
                                        <div class="details-body-r">قم برفع مستويات حقول الموارد في قريتك حتى ترفع انتاجية قريتك من هذه الموارد. أنت بحاجة الموارد لترقية مباني قريتك ولتدريب جنودك. <br /><br />
                                            <div class="btn-green">
                                                <div class="btn-green-l"></div>
                                                <div class="btn-green-c"><a class="npage popcon" href="#tutorial">دورة تدريبية</a></div>
                                                <div class="btn-green-r"></div>
                                            </div>
                                        </div>
								</div>
								<div class="details-l-bottom"></div>
								<div class="details-r-bottom"></div>
								<div class="details-bottom"></div>
							</div>
							<div class="details">
								<div class="details-top"></div>
								<div class="details-l-top"></div>
                                <div class="details-r-top"></div>
								<div class="details-body">
									<div class="details-body-l" id="strip-c2"></div>
									<div class="details-body-r">أنشأ المباني في قريتك وحسّنها. المباني تدعم البنية التحتية لقريتك، تزيد انتاجيّة قريتك من الموارد وتتيح لك تدريب وتحسين إمكانيات جنودك. <br /><br />
										<div class="btn-green">
											<div class="btn-green-l"></div>
											<div class="btn-green-c"><a class="npage popcon" href="#tutorial">دورة تدريبية</a></div>
											<div class="btn-green-r"></div>
										</div>
									</div>
								</div>
								<div class="details-l-bottom"></div>
                                <div class="details-r-bottom"></div>
								<div class="details-bottom"></div>
							</div>
							<div class="details">
								<div class="details-top"></div>
								<div class="details-l-top"></div>
                                <div class="details-r-top"></div>
								<div class="details-body">
									<div class="details-body-l" id="strip-c3"></div>
									<div class="details-body-r">راقب الجوار وتفاعل معهم. أحص اصدقاءك وخصومك، احتل الواحات في مربعك لتزيد رقعة امبراطوريتك وتزيد سطوتك في منطقتك. <br /><br />
									<div class="btn-green">
										<div class="btn-green-l"></div>
										<div class="btn-green-c"><a class="npage popcon" href="#tutorial">دورة تدريبية</a></div>
										<div class="btn-green-r"></div>
									</div>
								</div>
							</div>
							<div class="details-l-bottom"></div>
                            <div class="details-r-bottom"></div>
							<div class="details-bottom"></div>
						</div>
						<div class="details">
							<div class="details-top"></div>
							<div class="details-l-top"></div>
                            <div class="details-r-top"></div>
							<div class="details-body">
								<div class="details-body-l" id="strip-c4"></div>
								<div class="details-body-r">تابع تطويرك لقريتك ونجاحاتك في المعارك، وقارن نفسك بالابطال في سيرفرك. حاول أن تنافس على العشرة الأوائل، حاول أن تجني المزيد من الأوسمة.<br /><br />
									<div class="btn-green">
										<div class="btn-green-l"></div>
										<div class="btn-green-c"><a class="npage popcon" href="#tutorial">دورة تدريبية</a></div>
										<div class="btn-green-r"></div>
									</div>
								</div>
							</div>
							<div class="details-l-bottom"></div>
                            <div class="details-r-bottom"></div>
							<div class="details-bottom"></div>
						</div>
						<div class="details">
							<div class="details-top"></div>
							<div class="details-l-top"></div>
                            <div class="details-r-top"></div>
							<div class="details-body">
								<div class="details-body-l" id="strip-c5"></div>
								<div class="details-body-r">تلقَّ تقارير مفصلّة عن مغامراتك، تجاراتك ومعاركك. تاجر مع الجوار وقُد معاركك في ساحات الوغى. لا تفوّت على نفسك متابعة آخر التقارير حول ما يجري في جوارك.<br /><br />
									<div class="btn-green">
										<div class="btn-green-l"></div>
										<div class="btn-green-c"><a class="npage popcon" href="#tutorial">دورة تدريبية</a></div>
										<div class="btn-green-r"></div>
									</div>
								</div>
							</div>
							<div class="details-l-bottom"></div>
                      		<div class="details-r-bottom"></div>
							<div class="details-bottom"></div>
						</div>
						<div class="details">
							<div class="details-top"></div>
							<div class="details-l-top"></div>
                            <div class="details-r-top"></div>
							<div class="details-body">
								<div class="details-body-l" id="strip-c6"></div>
								<div class="details-body-r">تبادل الود والمعلومات والعلاقات الدبلوماسية مع بقية اللاعبين. لا تنسَ: التواصل هو مفتاح النجاح لبناء صداقات جديدة ولحل النزاعات القديمة.<br /><br />
									<div class="btn-green">
										<div class="btn-green-l"></div>
										<div class="btn-green-c"><a class="npage popcon" href="#tutorial">دورة تدريبية</a></div>
										<div class="btn-green-r"></div>
									</div>
								</div>
							</div>
							<div class="details-l-bottom"></div>
                            <div class="details-r-bottom"></div>
							<div class="details-bottom"></div>
						</div>
					</div>
				</div>
			</div>
			<div id="ssc-bg">
				<div id="ss-head">
					<div id="ss-head-left"></div>
					<div id="ss-head-right"></div>
					<h3 class="ss bold white"><?php echo index26; ?></h3>
				</div>
				<div id="ss-container">
					<div id="g-widget">
                    	<a class="browse next"></a>
						<div id="gallery">
							<div id="g-items">
								<img src="img/x.gif" class="screen1" alt="" />
                                <img src="img/x.gif" class="screen2" alt="" />
                                <img src="img/x.gif" class="screen3" alt="" />
                                <img src="img/x.gif" class="screen4" alt="" />
                                <img src="img/x.gif" class="screen5" alt="" />
                                <img src="img/x.gif" class="screen6" alt="" />
                                <img src="img/x.gif" class="screen7" alt="" />
                                <img src="img/x.gif" class="screen8" alt="" />
							</div>
						</div>
						<a class="browse prev"></a>
					</div>
				</div>
			</div>
						<script type="text/javascript">
			window.addEvent('domready', function()
	{
		//stage
		var stagewidget = new stageWidget({
			stagebg:$('stage-bg'),
			stageduration: {
				0:5000,
				1:5000,
				2:5000			},
			stagecon:$$(".stage-content"),
			stagenav:$$("#buttons-click li"),
			stagelink:$$(".stage-link")
		});

		//tooltip
		var tooltipwidget = new tooltipWidget({
			tips: $$("#strips li"),
			details:$$(".details")
		});
		//slider
		var sliderwidget = new sliderWidget({
			container: $$('#g-widget'),
			pimgwidth:520,
			head:$('prev_head'),
			desc:$('prev_desc'),
			prev_bg:$('overlaybg'),
			prev_container:$('preview_container'),
			prev_stage_container:$$('#preview_stage'),
			prev_items:$('preview_items'),
			close:$('close')
		});

		//slideshow [footer]
		$('screenshotp').addEvents(
		{
			'click': function(e) {
				e.stop();
				this.fireEvent('show');
			},
			'show':function(e){
				new sliderWidget({
					container: $$('#g-widget'),
					preview: false,
					inpreview:true,
					pimgwidth:520,
					head:$('prev_head'),
					desc:$('prev_desc'),
					prev_bg:$('overlaybg'),
					prev_container:$('preview_container'),
					prev_stage_container:$$('#preview_stage'),
					prev_items:$('preview_items'),
					close:$('close'),
					directcall:true
				});

			}
		});

		//popup anchor
		var url = new URI();
		var anchor = url.get('fragment');
		if (anchor && anchor == 'screenshots')
		{
			$('screenshotp').fireEvent('show');
		}
	});
</script>				
		</div>
		<div class="clear"></div>
	</div>
	<div id="footer-container">
		<div id="footer">
			<a class="flink popcon" href="#help"><?php echo index47; ?></a>&nbsp;|&nbsp;
            <a target="blank" class="flink" href="#"><?php echo index27; ?></a>&nbsp;|&nbsp;
            <a class="flink popcon" href="#links"><?php echo index28; ?></a>&nbsp;|&nbsp;
            <a target="blank" class="flink" href="#screenshots" id="screenshotp"><?php echo index26; ?></a>&nbsp;|&nbsp;
            <a class="flink popcon" href="#spielregeln"><?php echo index29; ?></a>&nbsp;|&nbsp;
            <a class="flink popcon" href="#agb"><?php echo index30; ?></a>&nbsp;|&nbsp;
            <a class="flink popcon" href="#impressum"><?php echo index31; ?></a>
			<br />
			&copy; 2012  2013	                <a target="blank" class="flink" href="http://www.khwarzmi.com">الخوارزمي للمعلوماتية</a>
	                <?php echo index32; ?>	            </div>
	</div>
	<div id="preview_container">
		<div id="p-top"></div>
		<div id="p-bg"></div>
		<div id="p-bottom"></div>
		<a class="close"></a>
		<div id="p-content">
			<div id="prev_head">
				<h3><?php echo index26; ?></h3>
			</div>
			<div id="preview_stage">
			<a class="browse next"></a>
			<div id="preview_img">
				<div id="preview_items"></div>
			</div>
			<a class="browse prev"></a>
			<div class="clear"></div>
		</div>
		<div id="prev_desc"></div>
	</div>
</div>
<div id="popup">
	<div id="popup-top"><a class="pclose"></a></div>
	<div id="popup-content">
		<div class="loading"></div>
	</div>
	<div id="popup-bottom"></div>
</div>
<div id="overlaybg"></div>
<script type="text/javascript">
	var screenshots = [
		{'img':'screenBig screenBig1','hl':'مركز القرية', 'desc':'هكذا يمكن أن تكون قريتك في البداية قبل أن تصبح إمبراطوية عظيمة، التي يخشا حتى جميع اعدائك النطق بإسمها'},

		{'img':'screenBig screenBig2','hl':'نظرة عامة للقرية', 'desc':'في حرب التتار هناك أربعة أنواع من الموارد: الخشب والطين والحديد والقمح. هذه الموارد .أساسية لتطوير مباني قريتك ولتجهيز آلية الحرب ومعداتها قبل أن تهتم بعمل المباني بقريتك عليك ترقية بعض حقول الموارد الخام.'},
		{'img':'screenBig screenBig3','hl':'البطل', 'desc':'يمكنك إرسال البطل الخاص بك الى الغابات والواحات لشن المغامرات. ويتوفر عليه مواجهة وإجتياز العديد من التحديات الغامضة، وقد يعثر على شيء ما ليحضره معه الى القرية'},
		{'img':'screenBig screenBig4','hl':'معلومات عن المباني', 'desc':'قريتك بحاجة الى العديد من المباني المختلفة في البداية. فكر وادرس الموضوع جيداً قبل بناء مبنى. أختار المبنى الذي ترغب بشيده بحكمة.'},
		{'img':'screenBig screenBig5','hl':'الأراضي المحيطة بك', 'desc':'إستكشف المحيط حولك وما بجوارك. تعرف على جيرانك . إتحد معهم أو تجسس عليهم ، إكتشف قوتهم الدفاعية، لكي تهجوم عليهم وتنهب مواردهم. احتل الواحات المختلفة لتزيد من إنتاج قريتك. لكن كل حذراً من الحيوانات البرية.'},
		{'img':'screenBig screenBig6','hl':'تقرير المعركة', 'desc':'درب مبكراً القوات للدفاع عن مملكتك أو قوات للهجوم على اعدائك. هكذا يمكنك أن تنهب الموارد الخامة لكي تطور في الوقت المناسب القرية الى أمبراطورية عظيمة.'},
		{'img':'screenBig screenBig7','hl':'نظام الأوسمة', 'desc':'كل أسبوع سيتم إختيار افضل 10 لاعبين وأفضل 10 تحالفات في فئات مختلفة. ويتلقى كل منهم وسام كشهادة لمهارتهم.'},
		{'img':'screenBig screenBig8','hl':'نظام المهام', 'desc':'نقدم لك معطي المشورة، رئيس المهمات الذي سيقف بجانبك كمرشد في الساعات الأولى ليساعدك في تطوير قريتك. لتفعيل رئيس المهمات، أنقر فقط على الصورة في يمين الشاشة.'}
	];
</script>
</div>
</body>
</html>