<h3 class="pop popgreen bold">الدعم</h3>
<div id="support">

	<div class="support-row">
		<div class="grlt"></div><div class="grrt"></div>
		<a href="index.php#tutorial" class="support-head spopcon">دورة تدريبية</a>
		دورة تدريبية		<div class="grlb"></div><div class="grrb"></div>
	</div>

	<div class="support-row">
		<div class="grlt"></div><div class="grrt"></div>
		<a href="index.php#spielregeln" class="support-head spopcon">قوانين اللعبة</a>
		هنا يمكنك أن تقرأ قوانين اللعبة		<div class="grlb"></div><div class="grrb"></div>
	</div>
	<div class="support-row">
		<div class="grlt"></div><div class="grrt"></div>
		<a href="index.php#answers" class="support-head" target="blank">أسئلة متكررة</a>
		هنا يمكنك إيجاد جواب للسؤال الذي يدور في خَلَدك حول ترافيان. إضافة إلى إمكانية الاتصال بفريق الدعم في اللعبة، في حال لم تتمكن من إيجاد جواب لسؤالك.		<div class="grlb"></div><div class="grrb"></div>
	</div>

	<div class="support-row">
		<div class="grlt"></div><div class="grrt"></div>
		<a href="" class="support-head" target="blank">المنتدى</a>
		في منتدانا، يمكنك التعرّف والتقرّب من الفريق وبقية اللاعبين.		<div class="grlb"></div><div class="grrb"></div>
	</div>
</div>